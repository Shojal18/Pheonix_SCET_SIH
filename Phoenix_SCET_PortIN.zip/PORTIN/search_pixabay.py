import urllib.request
import urllib.parse
import re

q = urllib.parse.quote('site:pixabay.com/videos "2849"')
url = f"https://html.duckduckgo.com/html/?q={q}"
req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'})
try:
    with urllib.request.urlopen(req) as r:
        content = r.read().decode('utf-8', errors='ignore')
        matches = re.findall(r'pixabay\.com/videos/[a-zA-Z0-9\-]+', content)
        print('Matches:', set(matches))
except Exception as e:
    print('Error:', e)
