import re
import glob

files = glob.glob('frontend/src/**/*.tsx', recursive=True)
pattern = re.compile(r'<div[^>]*class(?:Name)?=[\"\'\`][^\"\'\`]*(?:bg-(?:blue|emerald|purple|indigo|amber|violet|cyan|rose|teal)-(?:50|100|200))[^\"\'\`]*[\"\'\`][^>]*>', re.IGNORECASE)

for f in files:
    with open(f, 'r', encoding='utf-8') as fh:
        lines = fh.readlines()
    matches = []
    for idx, line in enumerate(lines):
        if pattern.search(line):
            matches.append((idx + 1, line.strip()))
    if matches:
        print(f"=== {f} ({len(matches)} matches) ===")
        for lno, text in matches[:5]:
            print(f"  L{lno}: {text}")
