import os

src_dir = r'c:\Users\ASUS\Downloads\jk (1)\jk\frontend\src'

for root, dirs, files in os.walk(src_dir):
    for f in files:
        if f.endswith(('.tsx', '.ts')):
            path = os.path.join(root, f)
            with open(path, 'r', encoding='utf-8') as file:
                content = file.read()
            
            orig = content
            # Fix text color on dark buttons
            content = content.replace("color: '#111827'", "color: '#FFFFFF'")
            content = content.replace("style={{\n            backgroundColor: '#111827',\n            color: '#111827',\n          }}", "className=\"bg-[#111827] hover:bg-[#1F2937] text-white\"")
            content = content.replace("style={{\n                        backgroundColor: '#111827',\n                        color: '#111827',\n                      }}", "className=\"bg-[#111827] hover:bg-[#1F2937] text-white\"")
            content = content.replace("style={{\n                backgroundColor: '#111827',\n                color: '#111827',\n              }}", "className=\"bg-[#111827] hover:bg-[#1F2937] text-white\"")
            content = content.replace("style={{ backgroundColor: '#111827' }}", "")
            
            # Spinners on dark buttons should be white
            content = content.replace('border-[#111827] border-t-transparent', 'border-white border-t-transparent')

            # Ensure all action buttons with bg-[#111827] have text-white
            # Specifically check DecisionTwinPage Run Twin button
            content = content.replace('text-[#111827] flex items-center justify-center gap-1.5 transition-all cursor-pointer shadow-xs hover:opacity-95 active:scale-[0.99] disabled:opacity-50', 'text-white font-bold rounded-[8px] flex items-center justify-center gap-1.5 transition-all cursor-pointer shadow-sm bg-[#111827] hover:bg-[#1F2937] disabled:opacity-50')
            content = content.replace('text-[#111827] flex items-center justify-center gap-2 transition-all cursor-pointer shadow-xs hover:opacity-95 active:scale-[0.99]', 'text-white font-bold rounded-[8px] flex items-center justify-center gap-2 transition-all cursor-pointer shadow-sm bg-[#111827] hover:bg-[#1F2937]')
            
            # Check ReportsPage
            content = content.replace('rounded-xl text-xs font-black tracking-wider uppercase transition-all flex items-center justify-center gap-2 cursor-pointer shadow-sm disabled:opacity-50 mt-2', 'rounded-[8px] text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer shadow-sm disabled:opacity-50 mt-2 bg-[#111827] hover:bg-[#1F2937] text-white')
            
            # Check VesselOptimizerPage
            content = content.replace('px-5 py-2.5 rounded-[8px] text-xs font-black uppercase tracking-wider transition-all duration-150 cursor-pointer shadow-sm active:scale-95 disabled:opacity-60 shrink-0', 'px-5 py-2.5 rounded-[8px] text-xs font-bold text-white bg-[#111827] hover:bg-[#1F2937] transition-all cursor-pointer shadow-sm shrink-0')
            content = content.replace('w-full py-2.5 px-3 rounded-[8px] text-xs font-black uppercase tracking-wider transition-all duration-150 flex items-center justify-center gap-1.5 shadow-sm active:scale-98 cursor-pointer', 'w-full py-2.5 px-3 rounded-[8px] text-xs font-bold text-white bg-[#111827] hover:bg-[#1F2937] transition-all flex items-center justify-center gap-1.5 shadow-sm cursor-pointer')

            if content != orig:
                with open(path, 'w', encoding='utf-8') as file:
                    file.write(content)
                print(f'Fixed button styles in {f}')
