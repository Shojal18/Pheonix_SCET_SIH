import sys
sys.path.insert(0, ".")
from backend.app.services.advisor import DecisionAdvisorService

test_queries = [
    "Which vessel is suitable for 70,000 MT coal from Australia to Paradip?",
    "Can Capesize enter Haldia port?",
    "Should we charter now or wait?",
    "Why choose a 3-voyage COA over spot charter?",
    "Tell me about demurrage and congestion at Paradip",
    "kya panamax ship paradip ja sakta hai"
]

print("="*60)
print("TESTING UPGRADED PORTIN AI DECISION ADVISOR")
print("="*60)

for q in test_queries:
    res = DecisionAdvisorService.answer_query(q)
    print(f"\n[USER QUESTION]: {q}")
    print(f"[CATEGORY]: {res.category} | [CONFIDENCE]: {res.confidence}")
    print(f"[ATTRIBUTION]: {res.source_attribution}")
    print(f"[ANSWER PREVIEW]:\n{res.answer[:280]}...")
    print(f"[FOLLOWUPS]: {res.suggested_followups}")
    print("-" * 50)
