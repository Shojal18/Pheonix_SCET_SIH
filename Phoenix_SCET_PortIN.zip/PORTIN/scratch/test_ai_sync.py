import os
import json
from dotenv import load_dotenv

load_dotenv()

groq_key = os.getenv("GROQ_API_KEY")
print("Groq key loaded:", bool(groq_key))

from openai import OpenAI
client = OpenAI(api_key=groq_key, base_url="https://api.groq.com/openai/v1")

prompt = """You are PortIN Maritime AI Engine. Output a valid JSON object for shipping route: Australia to Paradip Port (Coal, 120,000 MT, Nov 2026).
Respond ONLY with a JSON object:
{
  "ai_recommendation": "Considering the current weather forecast, vessel availability and market conditions, we recommend sailing between 12 Nov 2026 and 14 Nov 2026 for optimal safety and cost efficiency.",
  "recommended_window": "12 Nov 2026 – 14 Nov 2026",
  "key_insights": [
    "Calm weather expected in mid-November",
    "Low cyclone probability (4.2%)",
    "Safe passage through Malacca / Bay of Bengal",
    "Estimated transit duration: 16–18 days",
    "No major port congestion at Paradip (waiting < 2 days)"
  ],
  "alerts": [
    "Moderate sea state in Bay of Bengal (20–24 Nov)",
    "Monsoon residual swell possible before 10 Nov"
  ]
}
"""

resp = client.chat.completions.create(
    model="openai/gpt-oss-120b",
    messages=[{"role": "user", "content": prompt}],
    response_format={"type": "json_object"},
    max_tokens=1200,
    temperature=0.2
)

content = resp.choices[0].message.content
print("AI Result:\n", content)
parsed = json.loads(content)
print("Parsed recommendation:", parsed.get("ai_recommendation"))
