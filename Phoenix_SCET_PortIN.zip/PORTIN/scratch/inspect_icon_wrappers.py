import re, glob

files = glob.glob('frontend/src/pages/*.tsx')
icon_div_pattern = re.compile(r'(<div[^>]*rounded-(?:full|lg|xl|md)[^>]*>(\s*<[A-Z][a-zA-Z0-9]+[^>]*\/>\s*)<\/div>)')

for f in files:
    with open(f, 'r', encoding='utf-8') as fh:
        content = fh.read()
    matches = icon_div_pattern.findall(content)
    if matches:
        print(f"=== {f} ({len(matches)} icon wrapper divs) ===")
        for full, tag in matches[:4]:
            print("  DIV:", full.strip().replace('\n', ' '))
