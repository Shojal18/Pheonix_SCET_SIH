import os
from dotenv import load_dotenv
load_dotenv()

api_key = os.getenv("OPENAI_API_KEY")
model = os.getenv("OPENAI_MODEL", "gpt-4o")

print(f"Testing OpenAI with model: {model}")
try:
    from openai import OpenAI
    client = OpenAI(api_key=api_key)
    print("Testing client.chat.completions.create with gpt-4o...")
    res = client.chat.completions.create(
        model="gpt-4o",
        messages=[
            {"role": "system", "content": "You are a maritime logistics expert for Indian ports."},
            {"role": "user", "content": "Which vessel is best for 70,000 MT coal to Paradip?"}
        ],
        max_tokens=300
    )
    print("SUCCESS with gpt-4o!")
    print("Answer snippet:", res.choices[0].message.content[:200])
except Exception as e:
    print(f"FAILED gpt-4o: {type(e).__name__}: {e}")

try:
    print("\nTesting with model gpt-4o-mini...")
    res2 = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[
            {"role": "user", "content": "Hello"}
        ],
        max_tokens=50
    )
    print("SUCCESS with gpt-4o-mini!")
except Exception as e:
    print(f"FAILED gpt-4o-mini: {type(e).__name__}: {e}")

try:
    print("\nTesting responses API with gpt-5.6...")
    res3 = client.responses.create(
        model="gpt-5.6",
        input="Which vessel is best for 70,000 MT coal to Paradip?"
    )
    print("SUCCESS with gpt-5.6 responses!")
except Exception as e:
    print(f"FAILED responses API: {type(e).__name__}: {e}")
