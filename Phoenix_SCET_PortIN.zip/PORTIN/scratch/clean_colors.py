import os

src_dir = r'c:\Users\ASUS\Downloads\jk (1)\jk\frontend\src'

for root, dirs, files in os.walk(src_dir):
    for f in files:
        if f.endswith(('.tsx', '.ts', '.css')):
            path = os.path.join(root, f)
            with open(path, 'r', encoding='utf-8') as file:
                content = file.read()
            
            orig = content
            content = content.replace("backgroundColor: '#D6A63B'", "backgroundColor: '#111827'")
            content = content.replace("backgroundColor: '#d6a63b'", "backgroundColor: '#111827'")
            content = content.replace("style={{ backgroundColor: '#D6A63B' }}", "className='bg-[#111827] text-white'")
            content = content.replace("style={{ backgroundColor: '#D6A63B', color: '#111827' }}", "className='bg-[#111827] text-white'")
            content = content.replace("style={{ backgroundColor: '#D6A63B', color: '#0F2747' }}", "className='bg-[#111827] text-white'")
            content = content.replace("style={{ backgroundColor: '#F3E3B7', color: '#0F2747' }}", "className='bg-[#F3F4F6] text-[#111827]'")
            content = content.replace("style={{ backgroundColor: '#F3E3B7' }}", "className='bg-[#F3F4F6] text-[#111827]'")
            
            # Replace remaining amber borders and badges
            content = content.replace("bg-[#FEF3C7]", "bg-[#F3F4F6]")
            content = content.replace("bg-[#FEF7EC]", "bg-[#F8F9FA]")
            content = content.replace("border-amber-300", "border-[#E5E7EB]")
            content = content.replace("border-amber-400", "border-[#E5E7EB]")
            content = content.replace("border-amber-500", "border-[#E5E7EB]")
            content = content.replace("border-[#D6A63B]", "border-[#E5E7EB]")
            content = content.replace("border-[#E4E2DC]", "border-[#E5E7EB]")
            content = content.replace("border-[#D98A27]", "border-[#E5E7EB]")
            content = content.replace("text-amber-700", "text-[#4B5563]")
            content = content.replace("text-amber-800", "text-[#4B5563]")
            content = content.replace("text-amber-900", "text-[#111827]")
            content = content.replace("text-[#D97706]", "text-[#4B5563]")
            content = content.replace("text-[#D6A63B]", "text-[#111827]")

            if content != orig:
                with open(path, 'w', encoding='utf-8') as file:
                    file.write(content)
                print(f'Updated: {f}')
