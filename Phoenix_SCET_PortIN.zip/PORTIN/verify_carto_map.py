from playwright.sync_api import sync_playwright

with sync_playwright() as p:
    browser = p.chromium.launch(headless=True)
    page = browser.new_page(viewport={'width': 1440, 'height': 900})
    
    # Login
    page.goto('http://localhost:5173/login')
    page.click("button:has-text('Analyst')")
    page.click("button[type='submit']")
    page.wait_for_url('**/dashboard')
    
    # Go to Route Analysis
    page.goto('http://localhost:5173/route-analysis')
    page.wait_for_selector('text=Global Trade Lanes')
    page.wait_for_timeout(4000)
    
    # Capture map screenshot
    page.screenshot(path='frontend/public/assets/carto_map_verified.png', full_page=False)
    print('Captured Carto map screenshot')
    browser.close()
