@echo off
setlocal enabledelayedexpansion

echo =========================================================================
echo              PortIN - Maritime Freight Intelligence Platform
echo         Smart India Hackathon 2026 - Problem Statement 26006
echo                    Ministry of Steel / SAIL
echo =========================================================================
echo.

:: Detect Python launcher or executable
set "PYTHON_EXE="
where py >nul 2>nul && set "PYTHON_EXE=py"
if not defined PYTHON_EXE (
    where python >nul 2>nul && set "PYTHON_EXE=python"
)
if not defined PYTHON_EXE (
    if exist "%LOCALAPPDATA%\Programs\Python\Python312\python.exe" set "PYTHON_EXE=%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
    if exist "%LOCALAPPDATA%\Programs\Python\Python310\python.exe" set "PYTHON_EXE=%LOCALAPPDATA%\Programs\Python\Python310\python.exe"
    if exist "C:\Users\%USERNAME%\anaconda3\python.exe" set "PYTHON_EXE=C:\Users\%USERNAME%\anaconda3\python.exe"
)

if not defined PYTHON_EXE (
    echo [ERROR] Python was not found in PATH or standard locations.
    echo Please install Python 3.10+ or ensure it is added to your PATH.
    pause
    exit /b 1
)

echo [1/2] Starting PortIN FastAPI Backend on http://localhost:8000 ...
start "PortIN Backend" cmd /k "%PYTHON_EXE% -m uvicorn backend.app.main:app --host 0.0.0.0 --port 8000 --reload"

timeout /t 3 /nobreak >nul

echo [2/2] Starting PortIN React Frontend on http://localhost:5173 ...
cd frontend
start "PortIN Frontend" cmd /k "npm run dev"

echo.
echo =========================================================================
echo Both services launched!
echo - Web Application: http://localhost:5173
echo - API Documentation: http://localhost:8000/api/v1/docs
echo.
echo Demo Credentials:
echo - Analyst: analyst@sail.gov.in / Analyst@PortIN2026
echo - Admin:   admin@portin.sail.gov.in / Admin@PortIN2026
echo =========================================================================
pause
