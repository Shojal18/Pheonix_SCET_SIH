import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  TrendingUp, Ship, FileText, CheckCircle2, ShieldAlert,
  Clock, ArrowRight, RefreshCw, Compass, AlertCircle,
  Layers, MapPin, AlertTriangle, ShieldCheck,
  Bell, LogOut, BarChart2, Activity
} from 'lucide-react';
import {
  ResponsiveContainer, Line, XAxis, YAxis, Tooltip, CartesianGrid, ReferenceLine, ReferenceArea, ComposedChart
} from 'recharts';
import { useAuth } from '../context/AuthContext';
import { apiClient } from '../api/client';
import { KPICard } from '../components/common/KPICard';
import { DataProvenanceBadge } from '../components/common/DataProvenanceBadge';
import { ForecastResponse, AlertItem } from '../types';

interface RouteData {
  id: 'au-paradip' | 'id-vizag' | 'us-dhamra';
  shortLabel: string;
  title: string;
  originPort: string;
  originSub: string;
  distanceNM: string;
  transitDays: string;
  dischargePort: string;
  dischargeSub: string;
  cargoVolume: string;
  recommendedClass: string;
  currentSpot: number;
  lowestForecast: number;
  average90D: number;
  trajectory: string;
  recommendedRate: number;
  savingsPct: string;
  recommendedWindowRange: string;
  recommendedWindowLabel: string;
  recommendedWindowStart: string;
  recommendedWindowEnd: string;
  chartData: {
    date: string;
    forecastRate: number;
    currentSpot: number;
    lowerBound: number;
    upperBound: number;
  }[];
}

const ROUTE_DATA: Record<string, RouteData> = {
  'au-paradip': {
    id: 'au-paradip',
    shortLabel: 'AU → Paradip',
    title: 'Australia (Hay Point) → Paradip Port',
    originPort: 'Australia',
    originSub: 'Queensland, Australia',
    distanceNM: '4,850 NM',
    transitDays: 'Transit ~14d',
    dischargePort: 'Paradip Port',
    dischargeSub: 'Odisha, East Coast',
    cargoVolume: 'Coal - Thermal • 21k MT',
    recommendedClass: 'Supramax',
    currentSpot: 19.72,
    lowestForecast: 18.40,
    average90D: 21.35,
    trajectory: 'Seasonal trough (October)',
    recommendedRate: 18.64,
    savingsPct: 'Save 5.5%',
    recommendedWindowRange: 'Oct 12–26 Window',
    recommendedWindowLabel: 'RECOMMENDED WINDOW - OCT 12–26 ($18.40/MT)',
    recommendedWindowStart: 'Oct 01',
    recommendedWindowEnd: 'Oct 15',
    chartData: [
      { date: 'Aug 05', forecastRate: 19.80, currentSpot: 19.72, lowerBound: 18.30, upperBound: 21.30 },
      { date: 'Aug 19', forecastRate: 19.50, currentSpot: 19.72, lowerBound: 18.00, upperBound: 21.00 },
      { date: 'Sep 02', forecastRate: 19.20, currentSpot: 19.72, lowerBound: 17.70, upperBound: 20.80 },
      { date: 'Sep 16', forecastRate: 18.90, currentSpot: 19.72, lowerBound: 17.40, upperBound: 20.60 },
      { date: 'Oct 01', forecastRate: 18.55, currentSpot: 19.72, lowerBound: 17.20, upperBound: 20.50 },
      { date: 'Oct 15', forecastRate: 18.40, currentSpot: 19.72, lowerBound: 17.10, upperBound: 20.50 },
      { date: 'Nov 01', forecastRate: 19.38, currentSpot: 19.35, lowerBound: 17.48, upperBound: 20.88 },
      { date: 'Nov 15', forecastRate: 19.90, currentSpot: 19.72, lowerBound: 17.90, upperBound: 21.90 },
      { date: 'Dec 01', forecastRate: 20.80, currentSpot: 19.72, lowerBound: 18.60, upperBound: 23.20 },
      { date: 'Dec 15', forecastRate: 21.50, currentSpot: 19.72, lowerBound: 19.20, upperBound: 24.50 },
    ],
  },
  'id-vizag': {
    id: 'id-vizag',
    shortLabel: 'ID → Vizag',
    title: 'Indonesia (Kalimantan) → Visakhapatnam Port',
    originPort: 'Indonesia',
    originSub: 'South Kalimantan',
    distanceNM: '2,420 NM',
    transitDays: 'Transit ~7d',
    dischargePort: 'Visakhapatnam Port',
    dischargeSub: 'Andhra Pradesh, East Coast',
    cargoVolume: 'Thermal Coal • 55k MT',
    recommendedClass: 'Panamax',
    currentSpot: 12.45,
    lowestForecast: 11.20,
    average90D: 13.80,
    trajectory: 'Monsoon recovery (November)',
    recommendedRate: 11.20,
    savingsPct: 'Save 10.0%',
    recommendedWindowRange: 'Nov 04–18 Window',
    recommendedWindowLabel: 'RECOMMENDED WINDOW - NOV 04–18 ($11.20/MT)',
    recommendedWindowStart: 'Oct 15',
    recommendedWindowEnd: 'Nov 01',
    chartData: [
      { date: 'Aug 05', forecastRate: 13.60, currentSpot: 12.45, lowerBound: 12.20, upperBound: 14.80 },
      { date: 'Aug 19', forecastRate: 13.20, currentSpot: 12.45, lowerBound: 11.90, upperBound: 14.40 },
      { date: 'Sep 02', forecastRate: 12.80, currentSpot: 12.45, lowerBound: 11.50, upperBound: 14.10 },
      { date: 'Sep 16', forecastRate: 12.45, currentSpot: 12.45, lowerBound: 11.20, upperBound: 13.80 },
      { date: 'Oct 01', forecastRate: 12.00, currentSpot: 12.45, lowerBound: 10.90, upperBound: 13.40 },
      { date: 'Oct 15', forecastRate: 11.60, currentSpot: 12.45, lowerBound: 10.50, upperBound: 13.00 },
      { date: 'Nov 01', forecastRate: 11.20, currentSpot: 12.45, lowerBound: 10.20, upperBound: 12.60 },
      { date: 'Nov 15', forecastRate: 11.80, currentSpot: 12.45, lowerBound: 10.60, upperBound: 13.20 },
      { date: 'Dec 01', forecastRate: 12.90, currentSpot: 12.45, lowerBound: 11.50, upperBound: 14.50 },
      { date: 'Dec 15', forecastRate: 13.50, currentSpot: 12.45, lowerBound: 12.00, upperBound: 15.20 },
    ],
  },
  'us-dhamra': {
    id: 'us-dhamra',
    shortLabel: 'US → Dhamra',
    title: 'US (Hampton Roads) → Dhamra Port',
    originPort: 'United States',
    originSub: 'Virginia / Baltimore',
    distanceNM: '9,850 NM',
    transitDays: 'Transit ~32d',
    dischargePort: 'Dhamra Port',
    dischargeSub: 'Odisha, East Coast',
    cargoVolume: 'Met Coking Coal • 75k MT',
    recommendedClass: 'Capesize',
    currentSpot: 38.90,
    lowestForecast: 35.60,
    average90D: 41.20,
    trajectory: 'Post-hurricane dip (October)',
    recommendedRate: 35.60,
    savingsPct: 'Save 8.5%',
    recommendedWindowRange: 'Oct 20–Nov 05 Window',
    recommendedWindowLabel: 'RECOMMENDED WINDOW - OCT 20–NOV 05 ($35.60/MT)',
    recommendedWindowStart: 'Oct 01',
    recommendedWindowEnd: 'Oct 15',
    chartData: [
      { date: 'Aug 05', forecastRate: 41.20, currentSpot: 38.90, lowerBound: 37.00, upperBound: 45.00 },
      { date: 'Aug 19', forecastRate: 40.50, currentSpot: 38.90, lowerBound: 36.20, upperBound: 44.50 },
      { date: 'Sep 02', forecastRate: 39.80, currentSpot: 38.90, lowerBound: 35.50, upperBound: 43.80 },
      { date: 'Sep 16', forecastRate: 38.90, currentSpot: 38.90, lowerBound: 34.80, upperBound: 43.00 },
      { date: 'Oct 01', forecastRate: 37.20, currentSpot: 38.90, lowerBound: 33.50, upperBound: 41.50 },
      { date: 'Oct 15', forecastRate: 36.10, currentSpot: 38.90, lowerBound: 32.40, upperBound: 40.20 },
      { date: 'Nov 01', forecastRate: 35.60, currentSpot: 38.90, lowerBound: 32.00, upperBound: 39.80 },
      { date: 'Nov 15', forecastRate: 37.50, currentSpot: 38.90, lowerBound: 33.80, upperBound: 42.00 },
      { date: 'Dec 01', forecastRate: 40.10, currentSpot: 38.90, lowerBound: 36.00, upperBound: 45.50 },
      { date: 'Dec 15', forecastRate: 42.00, currentSpot: 38.90, lowerBound: 37.50, upperBound: 47.20 },
    ],
  },
};



export const DashboardPage: React.FC = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [forecast, setForecast] = useState<ForecastResponse | null>(null);
  const [alerts, setAlerts] = useState<AlertItem[]>([]);
  const [loading, setLoading] = useState(true);

  // Active corridor selection
  const [selectedRouteKey, setSelectedRouteKey] = useState<'au-paradip' | 'id-vizag' | 'us-dhamra'>('au-paradip');
  const activeRoute = ROUTE_DATA[selectedRouteKey];

  const loadData = async () => {
    setLoading(true);
    try {
      const res = await apiClient.post('/forecasts/run', {
        cargo_type: 'Coking Coal',
        cargo_mt: 70000,
        origin_country: 'Australia',
        origin_port: 'Gladstone',
        destination_port: 'Paradip',
        desired_shipment_date: '2026-09-20',
        vessel_class: 'Panamax',
        contract_duration_months: 3,
        num_voyages: 3,
        planning_horizon_days: 90,
      });
      setForecast(res.data);

      const alertRes = await apiClient.get('/alerts');
      setAlerts(alertRes.data);
    } catch (err) {
      console.error('Failed to load dashboard metrics', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  // Custom chart hover tooltip matching clean white/2% grey theme
  const CustomChartTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      const item = payload[0].payload;
      return (
        <div className="p-3 bg-[#FFFFFF] rounded-lg shadow-md border border-[#E5E7EB] text-xs min-w-[190px]">
          <div className="font-bold text-[#111827] pb-1.5 mb-1.5 border-b border-[#E5E7EB] flex items-center gap-1.5">
            <span>{label}, 2026</span>
          </div>
          <div className="space-y-1.5">
            <div className="flex justify-between items-center">
              <span className="text-[#6B7280] font-medium">Forecast Rate Point:</span>
              <span className="font-bold text-[#111827]">${item.forecastRate?.toFixed(2)} / MT</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-[#6B7280] font-medium">95% Bound Points:</span>
              <span className="font-medium text-[#374151]">${item.lowerBound?.toFixed(2)} – ${item.upperBound?.toFixed(2)}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-[#6B7280] font-medium">Spot Baseline Point:</span>
              <span className="font-medium text-[#374151]">${item.currentSpot?.toFixed(2)} / MT</span>
            </div>
          </div>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="space-y-6">
      {/* ========================================================================= */}
      {/* 1. TOP METRICS STRIP: 4 CLEAN KPI CARDS (SIMPLE NON-AI ICONS) */}
      {/* ========================================================================= */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Metric 1: Current Spot */}
        <div className="p-4 rounded-lg bg-white border border-[#E5E7EB] shadow-xs flex items-center justify-between">
          <div>
            <span className="text-[10px] font-bold text-[#6B7280] uppercase tracking-wider block">
              Current Spot Rate
            </span>
            <div className="text-xl font-bold text-[#111827] mt-0.5">
              ${activeRoute.currentSpot.toFixed(2)}{' '}
              <span className="text-xs text-[#6B7280] font-normal">/ MT</span>
            </div>
            <span className="text-[11px] text-[#6B7280] font-medium block mt-0.5">
              {activeRoute.originPort} → {activeRoute.dischargePort}
            </span>
          </div>
          <div className="w-8 h-8 rounded-md bg-[#F3F4F6] border border-[#E5E7EB] text-[#374151] flex items-center justify-center shrink-0">
            <Compass className="w-4 h-4 text-[#374151]" />
          </div>
        </div>

        {/* Metric 2: Lowest Forecast */}
        <div className="p-4 rounded-lg bg-white border border-[#E5E7EB] shadow-xs flex items-center justify-between">
          <div>
            <span className="text-[10px] font-bold text-[#6B7280] uppercase tracking-wider block">
              Lowest Forecast Rate
            </span>
            <div className="text-xl font-bold text-[#16A34A] mt-0.5">
              ${activeRoute.lowestForecast.toFixed(2)}{' '}
              <span className="text-xs text-[#6B7280] font-normal">/ MT</span>
            </div>
            <span className="text-[11px] text-[#16A34A] font-bold block mt-0.5">
              {activeRoute.savingsPct} savings potential
            </span>
          </div>
          <div className="w-8 h-8 rounded-md bg-[#F3F4F6] border border-[#E5E7EB] text-[#374151] flex items-center justify-center shrink-0">
            <TrendingUp className="w-4 h-4 text-[#374151]" />
          </div>
        </div>

        {/* Metric 3: 90-Day Average */}
        <div className="p-4 rounded-lg bg-white border border-[#E5E7EB] shadow-xs flex items-center justify-between">
          <div>
            <span className="text-[10px] font-bold text-[#6B7280] uppercase tracking-wider block">
              90-Day Moving Avg
            </span>
            <div className="text-xl font-bold text-[#111827] mt-0.5">
              ${activeRoute.average90D.toFixed(2)}{' '}
              <span className="text-xs text-[#6B7280] font-normal">/ MT</span>
            </div>
            <span className="text-[11px] text-[#6B7280] font-medium block mt-0.5">
              Historical baseline benchmark
            </span>
          </div>
          <div className="w-8 h-8 rounded-md bg-[#F3F4F6] border border-[#E5E7EB] text-[#374151] flex items-center justify-center shrink-0">
            <BarChart2 className="w-4 h-4 text-[#374151]" />
          </div>
        </div>

        {/* Metric 4: Market Trajectory */}
        <div className="p-4 rounded-lg bg-white border border-[#E5E7EB] shadow-xs flex items-center justify-between">
          <div>
            <span className="text-[10px] font-bold text-[#6B7280] uppercase tracking-wider block">
              Market Trajectory
            </span>
            <div className="text-sm font-bold text-[#111827] mt-1 leading-snug">
              {activeRoute.trajectory}
            </div>
            <span className="text-[11px] text-[#6B7280] font-medium block mt-0.5">
              {activeRoute.recommendedClass} class recommended
            </span>
          </div>
          <div className="w-8 h-8 rounded-md bg-[#F3F4F6] border border-[#E5E7EB] text-[#374151] flex items-center justify-center shrink-0">
            <Activity className="w-4 h-4 text-[#374151]" />
          </div>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 2. MAIN WORKSPACE GRID: 8 COLS (POINTS GRAPH) + 4 COLS (MONITORED CORRIDOR) */}
      {/* ========================================================================= */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
        
        {/* LEFT COLUMN (8 cols): FREIGHT MARKET OVERVIEW - ONLY POINTS GRAPH */}
        <div className="lg:col-span-8 p-5 rounded-lg bg-[#FFFFFF] border border-[#E5E7EB] shadow-xs flex flex-col justify-between space-y-3">
          
          {/* Card Header & Route Selector Tabs */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-2.5 border-b border-[#E5E7EB]">
            <div>
              <h2 className="text-sm sm:text-base font-bold text-[#111827] tracking-wider uppercase">
                Freight Market Overview
              </h2>
              <p className="text-xs text-[#6B7280] mt-0.5 font-medium">
                {activeRoute.title}
              </p>
            </div>

            {/* 3 Corridor Selector Tabs */}
            <div className="flex items-center gap-1.5">
              {(['au-paradip', 'id-vizag', 'us-dhamra'] as const).map((key) => {
                const r = ROUTE_DATA[key];
                const isActive = selectedRouteKey === key;
                return (
                  <button
                    key={key}
                    onClick={() => setSelectedRouteKey(key)}
                    className={`px-3 py-1.5 text-xs font-bold rounded-md transition-all cursor-pointer border ${
                      isActive
                        ? 'bg-[#111827] text-[#FFFFFF] border-[#111827]'
                        : 'bg-[#F9FAFB] text-[#4B5563] border-[#E5E7EB] hover:bg-[#F3F4F6]'
                    }`}
                  >
                    {r.shortLabel}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Legend - Only Points Graph Markers */}
          <div className="flex items-center justify-end gap-5 text-xs text-[#6B7280]">
            <span className="flex items-center gap-1.5 font-medium">
              <span className="w-2.5 h-2.5 rounded-full border-2 border-[#9CA3AF] bg-white inline-block" />
              Spot Baseline Points
            </span>
            <span className="flex items-center gap-1.5 font-medium">
              <span className="w-2.5 h-2.5 rounded-full bg-[#D1D5DB] inline-block" />
              95% Bound Points
            </span>
            <span className="flex items-center gap-1.5 font-bold text-[#111827]">
              <span className="w-3 h-3 rounded-full bg-[#111827] border-2 border-white shadow-xs inline-block" />
              Forecast Rate Points ($/MT)
            </span>
          </div>

          {/* Points Graph (Only Points / Scatter Dots, NO Lines, NO Bars, NO Gradients) */}
          <div className="h-60 sm:h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <ComposedChart
                data={activeRoute.chartData}
                margin={{ top: 15, right: 15, left: -20, bottom: 0 }}
              >
                <CartesianGrid strokeDasharray="2 2" stroke="#E5E7EB" vertical={false} />
                <XAxis
                  dataKey="date"
                  stroke="#9CA3AF"
                  fontSize={11}
                  tickLine={false}
                />
                <YAxis
                  stroke="#9CA3AF"
                  fontSize={11}
                  domain={[
                    selectedRouteKey === 'id-vizag' ? 9 : selectedRouteKey === 'us-dhamra' ? 30 : 16,
                    selectedRouteKey === 'id-vizag' ? 16 : selectedRouteKey === 'us-dhamra' ? 50 : 27,
                  ]}
                  tickFormatter={(v) => `$${v}`}
                  tickLine={false}
                />
                <Tooltip content={<CustomChartTooltip />} />

                {/* Recommended Window Highlight Column - Flat subtle tint */}
                <ReferenceArea
                  x1={activeRoute.recommendedWindowStart}
                  x2={activeRoute.recommendedWindowEnd}
                  fill="#F3F4F6"
                  fillOpacity={0.8}
                  stroke="#E5E7EB"
                  strokeDasharray="2 2"
                />
                <ReferenceLine
                  x={activeRoute.recommendedWindowEnd}
                  stroke="#9CA3AF"
                  strokeDasharray="3 3"
                  label={{
                    value: activeRoute.recommendedWindowLabel,
                    position: 'top',
                    fill: '#111827',
                    fontSize: 10,
                    fontWeight: 'bold',
                  }}
                />

                {/* Upper Bound Points (Dots only - stroke=none) */}
                <Line
                  type="monotone"
                  dataKey="upperBound"
                  stroke="none"
                  dot={{ r: 4, fill: '#CBD5E1', stroke: '#FFFFFF', strokeWidth: 1 }}
                  isAnimationActive={false}
                  name="Upper Bound Point"
                />

                {/* Lower Bound Points (Dots only - stroke=none) */}
                <Line
                  type="monotone"
                  dataKey="lowerBound"
                  stroke="none"
                  dot={{ r: 4, fill: '#CBD5E1', stroke: '#FFFFFF', strokeWidth: 1 }}
                  isAnimationActive={false}
                  name="Lower Bound Point"
                />

                {/* Current Spot Baseline (Dots only - stroke=none) */}
                <Line
                  type="monotone"
                  dataKey="currentSpot"
                  stroke="none"
                  dot={{ r: 4, fill: '#FFFFFF', stroke: '#9CA3AF', strokeWidth: 2 }}
                  isAnimationActive={false}
                  name="Current Spot Baseline Point"
                />

                {/* Forecast Rate Points (Solid Point Markers only - stroke=none) */}
                <Line
                  type="monotone"
                  dataKey="forecastRate"
                  stroke="none"
                  dot={{ r: 5, fill: '#111827', stroke: '#FFFFFF', strokeWidth: 2 }}
                  activeDot={{ r: 7, fill: '#2563EB', stroke: '#FFFFFF', strokeWidth: 2 }}
                  isAnimationActive={false}
                  name="Forecast Rate Point ($/MT)"
                />
              </ComposedChart>
            </ResponsiveContainer>
          </div>

          {/* Footer Links & Note */}
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 text-xs text-[#6B7280] pt-2 border-t border-[#E5E7EB]">
            <span className="flex items-center gap-1.5 text-[11px]">
              <span className="w-1.5 h-1.5 rounded-full bg-[#111827]" />
              Econometric dry bulk forward point observations with SARIMA 95% uncertainty points
            </span>
            <div className="flex items-center gap-4 text-[11px] font-bold">
              <Link to="/market" className="text-[#111827] hover:underline">
                Open Trading Desk
              </Link>
              <Link to="/forecast" className="text-[#111827] hover:underline flex items-center gap-1">
                <span>Create Custom Cargo Forecast</span>
                <ArrowRight className="w-3 h-3 text-[#111827]" />
              </Link>
            </div>
          </div>
        </div>

        {/* RIGHT COLUMN (4 cols): MONITORED CORRIDOR */}
        <div className="lg:col-span-4 p-5 rounded-lg bg-[#FFFFFF] border border-[#E5E7EB] shadow-xs flex flex-col justify-between space-y-4">
          <div className="space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-[#E5E7EB]">
              <div>
                <h3 className="text-xs font-bold text-[#111827] uppercase tracking-wider">
                  Monitored Corridor
                </h3>
                <span className="text-[11px] text-[#6B7280]">
                  High-volume dry bulk route
                </span>
              </div>
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-[#DCFCE7] text-[#15803D] border border-[#BBF7D0]">
                Favorable Entry
              </span>
            </div>

            {/* Origin & Discharge Route Box */}
            <div className="p-3 rounded-md bg-[#F8F9FA] border border-[#E5E7EB]">
              <div className="flex items-center justify-between">
                <div>
                  <span className="text-[9px] font-bold text-[#6B7280] uppercase tracking-wider block">
                    Origin Port
                  </span>
                  <span className="text-sm font-bold text-[#111827] block">
                    {activeRoute.originPort}
                  </span>
                  <span className="text-[10px] text-[#6B7280]">
                    {activeRoute.originSub}
                  </span>
                </div>

                <div className="text-center px-2">
                  <span className="text-[10px] text-[#6B7280] font-bold block">
                    {activeRoute.distanceNM} &rarr;
                  </span>
                  <span className="text-[9px] text-[#6B7280] font-medium">
                    {activeRoute.transitDays}
                  </span>
                </div>

                <div className="text-right">
                  <span className="text-[9px] font-bold text-[#6B7280] uppercase tracking-wider block">
                    Discharge Port
                  </span>
                  <span className="text-sm font-bold text-[#111827] block">
                    {activeRoute.dischargePort}
                  </span>
                  <span className="text-[10px] text-[#6B7280]">
                    {activeRoute.dischargeSub}
                  </span>
                </div>
              </div>
            </div>

            {/* Cargo & Vessel Class Metrics */}
            <div className="grid grid-cols-2 gap-3 text-xs">
              <div className="p-2.5 rounded-md bg-[#F8F9FA] border border-[#E5E7EB]">
                <span className="text-[9px] font-bold text-[#6B7280] uppercase tracking-wider block">
                  Cargo & Volume
                </span>
                <span className="font-bold text-[#111827] mt-0.5 block truncate">
                  {activeRoute.cargoVolume}
                </span>
              </div>
              <div className="p-2.5 rounded-md bg-[#F8F9FA] border border-[#E5E7EB]">
                <span className="text-[9px] font-bold text-[#6B7280] uppercase tracking-wider block">
                  Recommended Class
                </span>
                <span className="font-bold text-[#111827] mt-0.5 block">
                  {activeRoute.recommendedClass}
                </span>
              </div>
            </div>

            {/* Spot vs Recommended Window Box */}
            <div className="p-3 rounded-md bg-[#F8F9FA] border border-[#E5E7EB] flex items-center justify-between">
              <div>
                <span className="text-[9px] font-bold text-[#6B7280] uppercase tracking-wider block">
                  Spot vs Recommended Window
                </span>
                <div className="flex items-baseline gap-1.5 mt-0.5">
                  <span className="line-through text-[#6B7280] text-xs">${activeRoute.currentSpot.toFixed(2)}</span>
                  <span className="text-[#16A34A] font-bold text-base">${activeRoute.recommendedRate.toFixed(2)}</span>
                  <span className="text-[10px] text-[#6B7280] font-medium">/ MT</span>
                </div>
              </div>
              <div className="text-right">
                <span className="inline-block px-2 py-0.5 rounded text-[10px] font-bold bg-[#111827] text-[#FFFFFF]">
                  {activeRoute.savingsPct}
                </span>
                <span className="text-[9px] text-[#6B7280] block font-medium mt-0.5">
                  {activeRoute.recommendedWindowRange}
                </span>
              </div>
            </div>

            {/* Route Summary Note */}
            <div className="text-[11px] text-[#6B7280] leading-relaxed p-2.5 rounded-md bg-[#F8F9FA] border border-[#E5E7EB]">
              Optimal entry identified for {activeRoute.recommendedClass} vessels during the {activeRoute.recommendedWindowRange} offering peak freight savings against forward market projections.
            </div>
          </div>

          {/* Open Decision Matrix Button */}
          <button
            onClick={() => navigate('/decision-twin')}
            className="w-full py-2.5 rounded-[8px] text-xs font-bold text-white flex items-center justify-center gap-1.5 shadow-sm transition-all bg-[#111827] hover:bg-[#1F2937] cursor-pointer"
          >
            <span>Open Decision Matrix</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* LOWER DASHBOARD: VESSEL OPTIMIZATION MATRIX (FULL WIDTH & ORGANIZED) */}
      {/* ========================================================================= */}
      <div className="w-full">
        {/* Vessel Optimizer Comparison Table (Full 12 cols, Clean & Organized) */}
        <div className="w-full p-6 rounded-lg bg-[#FFFFFF] border border-[#E5E7EB] shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-[#E5E7EB]">
            <div>
              <h3 className="text-base font-bold text-[#111827]">
                Vessel Class Optimization Matrix
              </h3>
              <p className="text-xs text-[#6B7280] font-medium mt-0.5">
                Evaluated for a 70,000 MT coking coal parcel discharging at Paradip (Berth CQ-1).
              </p>
            </div>
            <Link 
              to="/vessel-optimizer" 
              className="px-3.5 py-1.5 rounded-[8px] text-xs font-bold text-white flex items-center gap-1.5 transition-all bg-[#111827] hover:bg-[#1F2937] shadow-xs cursor-pointer"
            >
              <span>Open Vessel Optimizer</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </Link>
          </div>

          {/* Clean Organized Comparison Table */}
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="text-[10px] font-bold uppercase tracking-wider text-[#6B7280] bg-[#F8F9FA] border-b border-[#E5E7EB]">
                <tr>
                  <th className="py-3 px-4">Vessel Type</th>
                  <th className="py-3 px-4">Capacity</th>
                  <th className="py-3 px-4">Freight Rate</th>
                  <th className="py-3 px-4">Estimated Cost</th>
                  <th className="py-3 px-4">Compatibility</th>
                  <th className="py-3 px-4">Turnaround</th>
                  <th className="py-3 px-4 text-right">Recommendation</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#E5E7EB]">
                {/* Handysize */}
                <tr className="hover:bg-[#F8F9FA] transition-colors">
                  <td className="py-3 px-4 font-bold text-[#111827]">Handysize</td>
                  <td className="py-3 px-4 text-[#6B7280]">35,000 DWT</td>
                  <td className="py-3 px-4 font-bold text-[#111827]">$19.80/MT</td>
                  <td className="py-3 px-4 font-medium text-[#4B5563]">$1.38M (2 parcels)</td>
                  <td className="py-3 px-4 text-[#16A34A] font-semibold">100% Draft Fit</td>
                  <td className="py-3 px-4 text-[#6B7280]">2.1 Days</td>
                  <td className="py-3 px-4 text-right text-[#9CA3AF]">Sub-optimal</td>
                </tr>

                {/* Supramax */}
                <tr className="hover:bg-[#F8F9FA] transition-colors">
                  <td className="py-3 px-4 font-bold text-[#111827]">Supramax</td>
                  <td className="py-3 px-4 text-[#6B7280]">58,000 DWT</td>
                  <td className="py-3 px-4 font-bold text-[#111827]">$16.50/MT</td>
                  <td className="py-3 px-4 font-medium text-[#4B5563]">$1.15M</td>
                  <td className="py-3 px-4 text-[#16A34A] font-semibold">100% Draft Fit</td>
                  <td className="py-3 px-4 text-[#6B7280]">2.5 Days</td>
                  <td className="py-3 px-4 text-right text-[#4B5563] font-semibold">Backup Plan B</td>
                </tr>

                {/* Panamax — Highlighted with Subtle Clean Neutral State */}
                <tr className="bg-[#F8F9FA] font-semibold">
                  <td className="py-3 px-4 font-bold text-[#111827] flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-[#16A34A]"></span>
                    Panamax
                  </td>
                  <td className="py-3 px-4 text-[#111827]">76,000 DWT</td>
                  <td className="py-3 px-4 font-bold text-[#111827]">$14.15/MT</td>
                  <td className="py-3 px-4 font-bold text-[#111827]">$0.99M</td>
                  <td className="py-3 px-4 text-[#16A34A] font-bold">14.0m Draft (CQ-1 Clr)</td>
                  <td className="py-3 px-4 text-[#111827]">2.8 Days</td>
                  <td className="py-3 px-4 text-right">
                    <span className="inline-block px-2.5 py-1 rounded-[6px] text-[10px] font-bold uppercase tracking-wider bg-[#111827] text-white">
                      BEST CHOICE
                    </span>
                  </td>
                </tr>

                {/* Capesize */}
                <tr className="hover:bg-[#F8F9FA] transition-colors">
                  <td className="py-3 px-4 font-bold text-[#111827]">Capesize</td>
                  <td className="py-3 px-4 text-[#6B7280]">180,000 DWT</td>
                  <td className="py-3 px-4 font-bold text-[#111827]">$11.80/MT</td>
                  <td className="py-3 px-4 font-medium text-[#4B5563]">$0.82M</td>
                  <td className="py-3 px-4 text-[#DC2626] font-semibold">Draft Exceeded (18m)</td>
                  <td className="py-3 px-4 text-[#6B7280]">4.2 Days</td>
                  <td className="py-3 px-4 text-right text-[#DC2626] font-semibold">Lightering Needed</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
