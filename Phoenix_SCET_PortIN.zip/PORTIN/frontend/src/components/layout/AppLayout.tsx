import React, { useState, useEffect } from 'react';
import { Link, useLocation, useNavigate, Outlet } from 'react-router-dom';
import {
  LayoutDashboard, TrendingUp, Ship, MapPin, Compass,
  FileText, ShoppingCart, Sliders, ShieldAlert,
  PieChart, FileDown, History, Settings, ChevronLeft, ChevronRight,
  LogOut, Bell, Shield, Menu, X, CheckCircle2, AlertTriangle, Plus,
  Layers, BarChart2, Anchor, Search, Clock, CloudSun, CalendarCheck, HelpCircle
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { apiClient } from '../../api/client';
import { AlertItem } from '../../types';

interface NavGroup {
  groupName: string;
  items: {
    label: string;
    path: string;
    icon: React.ComponentType<{ className?: string; style?: React.CSSProperties }>;
    badge?: string | number;
  }[];
}

export const AppLayout: React.FC = () => {
  const { user, logout } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();

  const [collapsed, setCollapsed] = useState<boolean>(() => {
    return localStorage.getItem('sidebar_collapsed') === 'true';
  });
  const [mobileOpen, setMobileOpen] = useState(false);
  const [alerts, setAlerts] = useState<AlertItem[]>([]);
  const [showAlertsPopover, setShowAlertsPopover] = useState(false);
  const [currentTime, setCurrentTime] = useState<string>('');

  useEffect(() => {
    localStorage.setItem('sidebar_collapsed', String(collapsed));
  }, [collapsed]);

  // Live Date/Time in IST
  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setCurrentTime(
        now.toLocaleDateString('en-GB', {
          day: '2-digit',
          month: 'short',
          year: 'numeric',
          hour: '2-digit',
          minute: '2-digit',
        }) + ' IST'
      );
    };
    updateTime();
    const timer = setInterval(updateTime, 10000);
    return () => clearInterval(timer);
  }, []);

  // Alerts
  useEffect(() => {
    const loadAlerts = async () => {
      try {
        const res = await apiClient.get('/alerts');
        setAlerts(res.data);
      } catch (e) {
        // Safe fallback
      }
    };
    loadAlerts();
  }, []);

  const navGroups: NavGroup[] = [
    {
      groupName: 'MARKET',
      items: [
        { label: 'Dashboard', path: '/dashboard', icon: LayoutDashboard },
        { label: 'New Forecast', path: '/forecast', icon: TrendingUp },
        { label: 'Booking', path: '/booking', icon: CalendarCheck, badge: 3 },
      ],
    },
    {
      groupName: 'ANALYSIS',
      items: [
        { label: 'Comparison Plan', path: '/decision-twin', icon: BarChart2 },
        { label: 'Vessel Directory', path: '/vessel-optimizer', icon: Ship },
        { label: 'Route Analysis', path: '/route-analysis', icon: Compass },
        { label: 'Reports', path: '/reports', icon: FileDown },
      ],
    },
    {
      groupName: 'MONITORING',
      items: [
        { label: 'Ship Congestion Forecast', path: '/risk-monitor', icon: ShieldAlert, badge: 3 },
        { label: 'Weather Forecasting', path: '/weather-forecasting', icon: CloudSun },
        { label: 'AI Advisor', path: '/ai-advisor', icon: HelpCircle },
        { label: 'History', path: '/history', icon: History },
      ],
    },
    {
      groupName: 'SYSTEM',
      items: [
        { label: 'Settings', path: '/profile', icon: Settings },
        ...(user?.role === 'admin'
          ? [{ label: 'Admin Panel', path: '/admin', icon: Shield }]
          : []),
      ],
    },
  ];

  const unreadAlerts = alerts.filter((a) => !a.is_read).length;

  return (
    <div className="flex h-screen w-screen bg-[#F8F9FA] text-[#111827] overflow-hidden">
      {/* Mobile Drawer Backdrop */}
      {mobileOpen && (
        <div
          className="fixed inset-0 z-40 bg-black/30 backdrop-blur-xs md:hidden"
          onClick={() => setMobileOpen(false)}
        />
      )}

      {/* ========================================================================= */}
      {/* CLEAN WHITE LEFT SIDEBAR WITH 2% GREY TINT BORDER */}
      {/* ========================================================================= */}
      <aside
        className={`fixed md:static inset-y-0 left-0 z-50 flex flex-col transition-all duration-200 shrink-0 bg-[#FFFFFF] border-r border-[#E5E7EB] ${
          collapsed ? 'w-20' : 'w-72'
        } ${mobileOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0'}`}
      >
        {/* Brand Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-[#E5E7EB]">
          <Link to="/dashboard" className="flex items-center gap-3 overflow-hidden focus:outline-none group">
            <div className="p-2 rounded-lg shrink-0 bg-[#F3F4F6] border border-[#E5E7EB] text-[#1F2937]">
              <Anchor className="w-5 h-5 stroke-[1.75]" />
            </div>
            {!collapsed && (
              <div className="leading-tight">
                <span className="text-xl font-bold tracking-tight text-[#111827] flex items-center gap-0.5">
                  Port<span className="text-[#2563EB]">IN</span>
                </span>
                <span className="text-xs uppercase tracking-wider text-[#6B7280] block font-semibold">
                  Maritime Intelligence
                </span>
              </div>
            )}
          </Link>

          <button
            onClick={() => setCollapsed(!collapsed)}
            className="hidden md:flex p-1.5 rounded-md text-[#6B7280] hover:text-[#111827] hover:bg-[#F3F4F6] transition-colors"
            title={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
          >
            {collapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
          </button>
          <button
            onClick={() => setMobileOpen(false)}
            className="md:hidden p-1.5 rounded-md text-[#6B7280] hover:text-[#111827]"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation Groups */}
        <nav className="flex-1 overflow-y-auto px-3 py-3 space-y-4">
          {navGroups.map((group) => (
            <div key={group.groupName} className="space-y-1">
              {!collapsed && (
                <div className="text-xs font-bold uppercase tracking-wider text-[#6B7280] px-3.5 py-1">
                  {group.groupName}
                </div>
              )}
              {group.items.map((item) => {
                const isActive =
                  location.pathname === item.path ||
                  (item.path === '/forecast' && location.pathname === '/new-forecast');
                const Icon = item.icon;

                return (
                  <Link
                    key={item.path}
                    to={item.path}
                    onClick={() => setMobileOpen(false)}
                    className={`flex items-center justify-between px-3.5 py-2.5 rounded-lg text-sm font-semibold transition-all select-none ${
                      isActive
                        ? 'bg-[#F3F4F6] text-[#111827] font-bold border border-[#E5E7EB]'
                        : 'text-[#4B5563] hover:bg-[#F9FAFB] hover:text-[#111827]'
                    }`}
                    title={collapsed ? item.label : undefined}
                  >
                    <div className="flex items-center gap-3.5 min-w-0">
                      <Icon
                        className="w-5 h-5 shrink-0 stroke-[1.75]"
                        style={{ color: isActive ? '#111827' : '#6B7280' }}
                      />
                      {!collapsed && <span className="truncate">{item.label}</span>}
                    </div>

                    {!collapsed && item.badge !== undefined && (
                      <span
                        className={`px-2 py-0.5 rounded text-xs font-bold ${
                          isActive
                            ? 'bg-[#111827] text-[#FFFFFF]'
                            : 'bg-[#E5E7EB] text-[#374151]'
                        }`}
                      >
                        {item.badge}
                      </span>
                    )}
                  </Link>
                );
              })}
            </div>
          ))}
        </nav>

        {/* Status Widget (Near Bottom) - Clean, Non-AI Look */}
        {!collapsed && (
          <div className="mx-3.5 my-2 p-3 rounded-lg bg-[#F8F9FA] border border-[#E5E7EB] space-y-1.5">
            <div className="flex items-center gap-2 font-bold text-[#16A34A] text-xs uppercase tracking-wider">
              <span className="w-2 h-2 rounded-full bg-[#16A34A]" />
              <span>Fleet Optimizer Active</span>
            </div>
            <div className="text-xs text-[#6B7280] flex items-center justify-between font-medium">
              <span>140 corridors</span>
              <span className="text-[#111827] font-bold">Live Analysis</span>
            </div>
          </div>
        )}

        {/* User Profile Bar */}
        <div className="p-3.5 border-t border-[#E5E7EB] bg-[#FAFAFA]">
          <div className={`flex items-center gap-3 ${collapsed ? 'justify-center' : ''}`}>
            <div className="w-9 h-9 rounded-full flex items-center justify-center text-sm font-bold shrink-0 bg-[#E5E7EB] text-[#111827] border border-[#D1D5DB]">
              {location.pathname === '/forecast' ? 'C' : location.pathname === '/risk-monitor' ? 'S' : (location.pathname === '/decision-twin' || location.pathname === '/weather-forecasting') ? 'H' : (user?.full_name?.charAt(0) || 'C')}
            </div>
            {!collapsed && (
              <div className="flex-1 min-w-0">
                <div className="text-sm font-bold text-[#111827] truncate">
                  {location.pathname === '/forecast' ? 'Chief Executive Admin...' : location.pathname === '/risk-monitor' ? 'Senior Chartering Analyst' : (location.pathname === '/decision-twin' || location.pathname === '/weather-forecasting') ? 'Head of Bulk Cargo' : (user?.full_name || 'Capt. Samarth R.')}
                </div>
                <div className="text-xs text-[#6B7280] truncate font-medium">
                  Logistics &amp; Chartering
                </div>
              </div>
            )}
            <button
              onClick={logout}
              title="Sign Out"
              className="p-1.5 text-[#6B7280] hover:text-[#DC2626] hover:bg-[#F3F4F6] rounded-lg transition-colors ml-auto cursor-pointer"
            >
              <LogOut className="w-4.5 h-4.5 stroke-[1.75]" />
            </button>
          </div>
        </div>
      </aside>

      {/* ========================================================================= */}
      {/* MAIN VIEWPORT WITH CLEAN ALL-WHITE / 2% GREY TINT TOP HEADER */}
      {/* ========================================================================= */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden bg-[#F8F9FA]">
        <header className="h-16 shrink-0 flex items-center justify-between px-6 z-30 bg-[#FFFFFF] border-b border-[#E5E7EB]">
          {/* Mobile Menu & Page Title / Breadcrumb / Search */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => setMobileOpen(true)}
              className="p-1.5 rounded-lg text-[#111827] hover:bg-[#F3F4F6] cursor-pointer"
            >
              <Menu className="w-5 h-5 text-[#111827]" />
            </button>

            {location.pathname === '/forecast' ? (
              <div className="relative hidden sm:block w-72 md:w-88">
                <Search className="w-4 h-4 text-[#9CA3AF] absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="Search ports, vessels, routes..."
                  className="w-full pl-9 pr-3.5 py-1.5 rounded-lg bg-[#F9FAFB] border border-[#E5E7EB] text-xs font-medium text-[#111827] placeholder:text-[#9CA3AF] focus:outline-none focus:border-[#111827]"
                />
              </div>
            ) : (
              <div>
                {location.pathname === '/risk-monitor' ? (
                  <div className="text-sm font-bold text-[#111827] flex items-center gap-1.5 leading-tight">
                    <span className="text-[#6B7280] font-medium">Corridor:</span>
                    <span>🇦🇺 Hay Point – 🇮🇳 Paradip Port</span>
                  </div>
                ) : (
                  <>
                    <div className="text-[11px] font-semibold text-[#6B7280] flex items-center gap-1 leading-none">
                      <span>PortIN</span>
                      <span className="text-[#9CA3AF]">&gt;</span>
                      <span className="text-[#111827] font-bold">
                        {location.pathname === '/route-analysis'
                          ? 'Route Analysis'
                          : location.pathname === '/decision-twin'
                            ? 'Comparison Plan'
                            : location.pathname === '/weather-forecasting'
                              ? 'Weather Forecasting'
                              : location.pathname === '/booking' || location.pathname === '/charter-operations'
                                ? 'Smart Booking'
                                : location.pathname === '/dashboard'
                                  ? 'Dashboard'
                                  : location.pathname.replace('/', '').replace('-', ' ').replace(/\b\w/g, (c) => c.toUpperCase())}
                      </span>
                    </div>
                    {location.pathname !== '/decision-twin' && location.pathname !== '/weather-forecasting' && (
                      <h1 className="text-base sm:text-lg font-bold text-[#111827] tracking-tight leading-tight mt-0.5">
                        {location.pathname === '/dashboard' ? 'Maritime Logistics Intelligence' : 'PortIN Freight Cockpit'}
                      </h1>
                    )}
                  </>
                )}
              </div>
            )}
          </div>

          {/* Right Header Controls */}
          <div className="flex items-center gap-2.5 sm:gap-3">
            {location.pathname === '/forecast' ? (
              <>
                {/* Scenario Button */}
                <button
                  type="button"
                  className="hidden md:flex items-center gap-1.5 px-3 py-1 rounded-lg bg-[#F3F4F6] border border-[#E5E7EB] text-[#374151] text-xs font-bold transition-all cursor-pointer hover:bg-[#E5E7EB]"
                >
                  <FileText className="w-3.5 h-3.5 text-[#4B5563]" />
                  <span>Demo Scenario</span>
                </button>

                {/* Last Updated */}
                <div className="hidden lg:flex items-center gap-1.5 text-xs text-[#6B7280] font-medium mr-1">
                  <Clock className="w-3.5 h-3.5 text-[#9CA3AF]" />
                  <span>Last Updated: 07 Sep 2026, 15:20</span>
                </div>

                {/* Notification Bell */}
                <div className="relative">
                  <button
                    onClick={() => setShowAlertsPopover(!showAlertsPopover)}
                    className="relative p-2 rounded-lg text-[#111827] hover:bg-[#F3F4F6] border border-[#E5E7EB] transition-colors cursor-pointer"
                    title="Operational Alerts"
                  >
                    <Bell className="w-4 h-4 text-[#4B5563]" />
                    <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-[#DC2626] text-white text-[9px] font-bold flex items-center justify-center">
                      4
                    </span>
                  </button>
                </div>

                {/* Chief Executive Admin User Badge */}
                <Link
                  to="/profile"
                  className="flex items-center gap-2 px-2.5 py-1 rounded-lg bg-[#FFFFFF] border border-[#E5E7EB] text-[#111827] hover:bg-[#F3F4F6] transition-colors"
                >
                  <div className="w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold text-[#FFFFFF] shrink-0 bg-[#111827]">
                    C
                  </div>
                  <div className="hidden lg:block text-left leading-tight">
                    <div className="text-xs font-bold text-[#111827] truncate max-w-[140px]">
                      Chief Executive Admin
                    </div>
                    <div className="text-[10px] text-[#6B7280]">
                      Logistics Officer
                    </div>
                  </div>
                </Link>
              </>
            ) : location.pathname === '/risk-monitor' ? (
              <>
                <span className="hidden md:inline text-xs font-semibold text-[#6B7280] mr-1">
                  06 Sept 2026, 21:00 IST
                </span>

                {/* NEW FORECAST Button */}
                <Link
                  to="/forecast"
                  className="px-3.5 py-1.5 rounded-lg text-xs font-bold text-white flex items-center gap-1.5 transition-all bg-[#111827] hover:bg-[#1F2937] cursor-pointer"
                >
                  <Compass className="w-3.5 h-3.5" />
                  <span>+ NEW FORECAST</span>
                </Link>

                {/* Notification Bell */}
                <div className="relative">
                  <button
                    onClick={() => setShowAlertsPopover(!showAlertsPopover)}
                    className="relative p-2 rounded-lg text-[#111827] hover:bg-[#F3F4F6] border border-[#E5E7EB] transition-colors cursor-pointer"
                    title="Operational Alerts"
                  >
                    <Bell className="w-4 h-4 text-[#4B5563]" />
                    <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-[#DC2626] text-white text-[9px] font-bold flex items-center justify-center">
                      3
                    </span>
                  </button>
                </div>

                {/* User Profile Badge */}
                <Link
                  to="/profile"
                  className="flex items-center gap-2 px-2.5 py-1 rounded-lg bg-white border border-[#E5E7EB] text-[#111827] hover:bg-[#F3F4F6] transition-colors"
                >
                  <div className="w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold text-[#111827] shrink-0 bg-[#E5E7EB] border border-[#D1D5DB]">
                    S
                  </div>
                  <div className="hidden lg:block text-left leading-tight">
                    <div className="text-xs font-bold text-[#111827] truncate max-w-[140px]">
                      Senior Chartering Analyst
                    </div>
                    <div className="text-[10px] text-[#6B7280]">
                      Logistics &amp; Chartering
                    </div>
                  </div>
                </Link>
              </>
            ) : (
              <>
                <button
                  onClick={() => navigate('/dashboard')}
                  className="hidden sm:block px-3 py-1.5 rounded-lg text-xs font-bold border border-[#E5E7EB] bg-white text-[#111827] hover:bg-[#F3F4F6] transition-colors cursor-pointer"
                >
                  Overview
                </button>

                {/* NEW FORECAST Button */}
                <Link
                  to="/forecast"
                  className="px-3.5 py-1.5 rounded-lg text-xs font-bold text-white flex items-center gap-1.5 transition-all bg-[#111827] hover:bg-[#1F2937] cursor-pointer"
                >
                  <Compass className="w-3.5 h-3.5" />
                  <span>+ NEW FORECAST</span>
                </Link>

                {/* Notification Bell */}
                <div className="relative">
                  <button
                    onClick={() => setShowAlertsPopover(!showAlertsPopover)}
                    className="relative p-2 rounded-lg text-[#111827] hover:bg-[#F3F4F6] border border-[#E5E7EB] transition-colors cursor-pointer"
                    title="Operational Alerts"
                  >
                    <Bell className="w-4 h-4 text-[#4B5563]" />
                    <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-[#DC2626] text-white text-[9px] font-bold flex items-center justify-center">
                      {location.pathname === '/weather-forecasting' ? 2 : 3}
                    </span>
                  </button>

                  {showAlertsPopover && (
                    <div className="absolute right-0 mt-2 w-80 rounded-xl bg-white border border-[#E5E7EB] shadow-lg p-4 z-50 animate-in fade-in duration-150">
                      <div className="flex items-center justify-between pb-2 border-b border-[#E5E7EB] mb-3">
                        <span className="text-xs font-bold uppercase tracking-wider text-[#111827]">
                          Operational Alerts
                        </span>
                        <span className="text-[10px] text-[#6B7280] font-semibold">{alerts.length} Total</span>
                      </div>
                      <div className="space-y-2 max-h-72 overflow-y-auto pr-1">
                        {alerts.map((alert) => (
                          <div
                            key={alert.id}
                            className="p-2.5 rounded-lg bg-[#F9FAFB] border border-[#E5E7EB] text-xs text-[#111827] space-y-1"
                          >
                            <div className="flex items-center justify-between font-bold text-[#111827]">
                              <span>{alert.title}</span>
                              <span className="text-[9px] uppercase px-1.5 py-0.2 rounded bg-amber-100 text-[#111827]">
                                {alert.severity}
                              </span>
                            </div>
                            <p className="text-[11px] text-[#6B7280]">{alert.message}</p>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                {/* User Profile Badge */}
                <Link
                  to="/profile"
                  className="flex items-center gap-2 px-2 py-1 rounded-lg bg-white border border-[#E5E7EB] text-[#111827] hover:bg-[#F3F4F6] transition-colors"
                >
                  <div className="w-7 h-7 rounded-md flex items-center justify-center text-xs font-bold text-[#111827] shrink-0 bg-[#E5E7EB] border border-[#D1D5DB]">
                    {(location.pathname === '/decision-twin' || location.pathname === '/weather-forecasting') ? 'H' : (user?.full_name ? user.full_name.charAt(0) : 'E')}
                  </div>
                  <div className="hidden lg:block text-left leading-tight">
                    <div className="text-xs font-bold text-[#111827] truncate max-w-[130px]">
                      {(location.pathname === '/decision-twin' || location.pathname === '/weather-forecasting') ? 'Head of Bulk Cargo' : (user?.full_name || 'East Coast Traffic & ...')}
                    </div>
                    <div className="text-[10px] text-[#6B7280]">
                      Logistics Officer
                    </div>
                  </div>
                </Link>

                {/* Log out Button */}
                <button
                  onClick={logout}
                  className="px-2.5 py-1.5 rounded-lg text-xs font-bold border border-[#E5E7EB] bg-white text-[#4B5563] hover:text-[#DC2626] hover:bg-[#F3F4F6] transition-colors cursor-pointer"
                >
                  Log out
                </button>
              </>
            )}
          </div>
        </header>

        {/* Page Content Body */}
        <main className="flex-1 overflow-y-auto bg-[#F8F9FA] p-6">
          <Outlet />
        </main>
      </div>
    </div>
  );
};
