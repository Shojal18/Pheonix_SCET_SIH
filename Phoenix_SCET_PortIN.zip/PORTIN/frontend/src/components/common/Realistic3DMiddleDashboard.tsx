import React, { useState, useRef, useEffect } from 'react';
import { Link } from 'react-router-dom';
import {
  Compass, Clock, ArrowRight, Ship, FileText,
  Info, ChevronDown, Sparkles, Navigation, Layers, Shield
} from 'lucide-react';
import {
  ResponsiveContainer, ComposedChart, Area, Line, XAxis, YAxis,
  Tooltip, CartesianGrid, ReferenceLine
} from 'recharts';
import {
  Realistic3DBdiChartIcon,
  Realistic3DShipIcon,
  Realistic3DCurrencyCoinsIcon,
  Realistic3DAnchorIcon,
  Realistic3DAIBrainIcon
} from './Realistic3DIcons';

// Interactive 3D Glass Card Container Wrapper
export const Realistic3DBox: React.FC<{
  children: React.ReactNode;
  className?: string;
  accentGlow?: string;
}> = ({ children, className = '', accentGlow = 'rgba(217, 119, 6, 0.12)' }) => {
  const boxRef = useRef<HTMLDivElement>(null);
  const [rotateX, setRotateX] = useState(0);
  const [rotateY, setRotateY] = useState(0);
  const [glarePos, setGlarePos] = useState({ x: 50, y: 50, opacity: 0 });
  const [isHovered, setIsHovered] = useState(false);

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!boxRef.current) return;
    const rect = boxRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    const centerX = rect.width / 2;
    const centerY = rect.height / 2;

    const rotX = ((y - centerY) / centerY) * -7;
    const rotY = ((x - centerX) / centerX) * 7;

    setRotateX(rotX);
    setRotateY(rotY);
    setGlarePos({
      x: (x / rect.width) * 100,
      y: (y / rect.height) * 100,
      opacity: 0.45,
    });
  };

  const handleMouseEnter = () => setIsHovered(true);
  const handleMouseLeave = () => {
    setIsHovered(false);
    setRotateX(0);
    setRotateY(0);
    setGlarePos((prev) => ({ ...prev, opacity: 0 }));
  };

  return (
    <div style={{ perspective: 1200 }} className="w-full h-full">
      <div
        ref={boxRef}
        onMouseMove={handleMouseMove}
        onMouseEnter={handleMouseEnter}
        onMouseLeave={handleMouseLeave}
        style={{
          transform: `rotateX(${rotateX}deg) rotateY(${rotateY}deg) translateZ(${isHovered ? 8 : 0}px)`,
          transition: isHovered
            ? 'transform 0.08s ease-out, box-shadow 0.2s ease-out'
            : 'transform 0.5s cubic-bezier(0.2, 0.8, 0.2, 1), box-shadow 0.5s ease-out',
          boxShadow: isHovered
            ? `0 24px 45px -10px rgba(15, 39, 71, 0.16), 0 12px 20px -6px rgba(15, 39, 71, 0.09), 0 0 30px ${accentGlow}, inset 0 1.5px 0 rgba(255, 255, 255, 1), inset 0 -2px 6px rgba(15, 39, 71, 0.04)`
            : '0 10px 25px -5px rgba(15, 39, 71, 0.07), 0 4px 6px -2px rgba(15, 39, 71, 0.03), inset 0 1px 0 rgba(255, 255, 255, 0.95), inset 0 -1px 3px rgba(15, 39, 71, 0.02)',
        }}
        className={`relative rounded-2xl p-5 bg-gradient-to-b from-white via-[#FCFCFD] to-[#F8FAFC] border border-slate-200/90 transition-colors flex flex-col justify-between overflow-hidden ${className}`}
      >
        {/* Specular Radial Light Sheen */}
        <div
          aria-hidden="true"
          className="pointer-events-none absolute inset-0 z-10 transition-opacity duration-200"
          style={{
            opacity: glarePos.opacity,
            background: `radial-gradient(circle 240px at ${glarePos.x}% ${glarePos.y}%, rgba(255, 255, 255, 0.7) 0%, rgba(255, 255, 255, 0.1) 50%, transparent 80%)`,
          }}
        />

        {/* Top Gloss Highlight Edge */}
        <div className="absolute top-0 inset-x-0 h-1 bg-gradient-to-r from-transparent via-white to-transparent pointer-events-none" />

        {children}

        {/* Bottom Ambient Occlusion Edge */}
        <div className="absolute bottom-0 inset-x-0 h-1 bg-gradient-to-r from-transparent via-slate-200/40 to-transparent pointer-events-none" />
      </div>
    </div>
  );
};

// 3D Middle Section Component Props
interface Realistic3DMiddleDashboardProps {
  unitMode: 'USD/Day' | 'USD/MT';
  setUnitMode: (mode: 'USD/Day' | 'USD/MT') => void;
  chartData: any[];
}

export const Realistic3DMiddleDashboard: React.FC<Realistic3DMiddleDashboardProps> = ({
  unitMode,
  setUnitMode,
  chartData,
}) => {
  // Moving Vessel Animation State along the route (0% to 100%)
  const [vesselProgress, setVesselProgress] = useState(38);

  useEffect(() => {
    const interval = setInterval(() => {
      setVesselProgress((prev) => (prev >= 98 ? 2 : prev + 0.6));
    }, 120);
    return () => clearInterval(interval);
  }, []);

  // Compute 2D coordinate on quadratic bezier curve for ship: P(t) = (1-t)^2*P0 + 2(1-t)t*P1 + t^2*P2
  const t = vesselProgress / 100;
  // Route from Paradip (85, 75) via mid-ocean (160, 130) to Hay Point (250, 155)
  const p0 = { x: 85, y: 75 };
  const p1 = { x: 160, y: 130 };
  const p2 = { x: 250, y: 155 };
  const shipX = (1 - t) * (1 - t) * p0.x + 2 * (1 - t) * t * p1.x + t * t * p2.x;
  const shipY = (1 - t) * (1 - t) * p0.y + 2 * (1 - t) * t * p1.y + t * t * p2.y;

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 select-none">
      
      {/* ========================================================================= */}
      {/* CARD 1: 3D FREIGHT FORECAST OVERVIEW (5 Columns) */}
      {/* ========================================================================= */}
      <div className="lg:col-span-5">
        <Realistic3DBox accentGlow="rgba(17, 94, 89, 0.15)" className="space-y-4">
          
          {/* Header */}
          <div style={{ transform: 'translateZ(18px)' }} className="flex items-start justify-between gap-2">
            <div>
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-xl bg-[#F3F4F6] border border-[#E5E7EB] text-[#4B5563] shadow-xs">
                  <Realistic3DBdiChartIcon size={20} />
                </div>
                <div>
                  <h3 className="text-sm font-extrabold text-[#111827] tracking-tight">
                    Freight Forecast Overview
                  </h3>
                  <p className="text-[11px] text-slate-500 mt-0.5 font-medium">
                    30-day trend – <span className="inline-flex items-center gap-1 font-bold text-slate-800"><span>🇦🇺</span> Hay Point</span> to <span className="inline-flex items-center gap-1 font-bold text-slate-800"><span>🇮🇳</span> Paradip</span> (Iron Ore, Capesize)
                  </p>
                </div>
              </div>
            </div>

            {/* Currency Unit Switcher (3D Pill) */}
            <div className="relative shrink-0">
              <select
                value={unitMode}
                onChange={(e) => setUnitMode(e.target.value as any)}
                aria-label="Select Freight Rate Currency Unit"
                className="appearance-none pl-3 pr-7 py-1.5 text-xs font-black rounded-xl border border-slate-200 bg-gradient-to-b from-white to-slate-100 text-slate-800 shadow-xs focus:outline-none focus:ring-2 focus:ring-[#E5A93C] cursor-pointer"
                style={{
                  boxShadow: 'inset 0 1px 0 #FFFFFF, 0 2px 4px rgba(15, 39, 71, 0.06)',
                }}
              >
                <option value="USD/Day">USD/Day</option>
                <option value="USD/MT">USD/MT</option>
              </select>
              <ChevronDown className="w-3.5 h-3.5 text-slate-500 absolute right-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            </div>
          </div>

          {/* 3D Legend Pill */}
          <div style={{ transform: 'translateZ(16px)' }} className="flex items-center gap-4 text-xs font-bold text-slate-700 bg-slate-50/90 p-2 rounded-xl border border-slate-200/70">
            <div className="flex items-center gap-2">
              <span className="w-3 h-3 rounded-full bg-[#115E59] shadow-xs" />
              <span>Actual Rate</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="w-3 h-3 rounded-full border-2 border-[#D97706] bg-[#F3F4F6] border-dashed shadow-xs" />
              <span className="text-[#4B5563]">Predicted Rate (AI Model)</span>
            </div>
          </div>

          {/* Interactive 3D Chart Canvas with Acrylic Callout Overlays */}
          <div style={{ transform: 'translateZ(22px)' }} className="h-[210px] w-full relative pt-1">
            <ResponsiveContainer width="100%" height="100%">
              <ComposedChart data={chartData} margin={{ top: 12, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="actual3dGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#115E59" stopOpacity={0.35} />
                    <stop offset="95%" stopColor="#115E59" stopOpacity={0.02} />
                  </linearGradient>
                  <filter id="actualGlow" x="-10%" y="-10%" width="120%" height="120%">
                    <feDropShadow dx="0" dy="3" stdDeviation="2" floodColor="#115E59" floodOpacity="0.3" />
                  </filter>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E2E8F0" opacity={0.6} />
                <XAxis dataKey="date" tick={{ fontSize: 10, fill: '#64748B', fontWeight: 600 }} axisLine={false} tickLine={false} />
                <YAxis
                  domain={unitMode === 'USD/Day' ? [10000, 35000] : [10, 35]}
                  tick={{ fontSize: 10, fill: '#64748B', fontWeight: 600 }}
                  axisLine={false}
                  tickLine={false}
                  tickFormatter={(v) => (unitMode === 'USD/Day' ? `${(v / 1000).toFixed(0)}k` : `${v}`)}
                />
                <Tooltip
                  content={({ active, payload, label }) => {
                    if (active && payload && payload.length) {
                      const data = payload[0].payload;
                      return (
                        <div
                          className="p-3 bg-[#111827]/95 backdrop-blur-md rounded-xl shadow-2xl border border-white/20 text-xs text-white"
                          style={{
                            boxShadow: '0 12px 25px rgba(15, 39, 71, 0.4)',
                          }}
                        >
                          <div className="font-extrabold text-[#E5A93C] mb-1.5 border-b border-white/10 pb-1">{label}</div>
                          {data.predicted && (
                            <div className="text-amber-300 font-bold flex items-center justify-between gap-3">
                              <span>Predicted:</span>
                              <span className="font-mono">{unitMode === 'USD/Day' ? `$${data.predicted.toLocaleString()}` : `$${data.predicted}/MT`}</span>
                            </div>
                          )}
                          {data.actual && (
                            <div className="text-emerald-300 font-bold flex items-center justify-between gap-3 mt-0.5">
                              <span>Actual:</span>
                              <span className="font-mono">{unitMode === 'USD/Day' ? `$${data.actual.toLocaleString()}` : `$${data.actual}/MT`}</span>
                            </div>
                          )}
                        </div>
                      );
                    }
                    return null;
                  }}
                />

                {/* Today Marker Line */}
                <ReferenceLine x="5 Oct" stroke="#111827" strokeWidth={1.5} strokeDasharray="3 3" />

                {/* Actual Area Curve with Glow */}
                <Area
                  type="monotone"
                  dataKey="actual"
                  stroke="#115E59"
                  strokeWidth={2.8}
                  fillOpacity={1}
                  fill="url(#actual3dGradient)"
                  connectNulls={false}
                />

                {/* Predicted Dotted AI Curve */}
                <Line
                  type="monotone"
                  dataKey="predicted"
                  stroke="#D97706"
                  strokeWidth={2.8}
                  strokeDasharray="4 4"
                  dot={{ r: 3.5, fill: '#F59E0B', stroke: '#92400E', strokeWidth: 1 }}
                  connectNulls={false}
                />
              </ComposedChart>
            </ResponsiveContainer>

            {/* 3D Acrylic Floating Callout for 5 Oct Today */}
            <div
              className="absolute top-2 left-[54%] -translate-x-1/2 p-2.5 rounded-xl bg-white/95 backdrop-blur-md border border-slate-200/90 text-[10px] space-y-0.5 pointer-events-none hidden sm:block"
              style={{
                transform: 'translateZ(26px)',
                boxShadow: '0 10px 20px -3px rgba(15, 39, 71, 0.15), 0 4px 6px -2px rgba(15, 39, 71, 0.05), inset 0 1px 0 #FFFFFF',
              }}
            >
              <div className="font-black text-slate-800 text-center pb-1 border-b border-slate-100 flex items-center justify-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-ping" />
                <span>5 Oct 2026</span>
              </div>
              <div className="text-[#4B5563] font-extrabold font-mono pt-0.5">● Predicted: $19,800</div>
              <div className="text-[#115E59] font-extrabold font-mono">● Actual: $18,450</div>
            </div>
          </div>
        </Realistic3DBox>
      </div>

      {/* ========================================================================= */}
      {/* CARD 2: 3D ROUTE INTELLIGENCE (4 Columns) */}
      {/* ========================================================================= */}
      <div className="lg:col-span-4">
        <Realistic3DBox accentGlow="rgba(59, 130, 246, 0.15)" className="space-y-3.5">
          
          {/* Header */}
          <div style={{ transform: 'translateZ(18px)' }}>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-xl bg-blue-500/10 border border-blue-400/30 text-blue-700 shadow-xs">
                  <Realistic3DShipIcon size={20} />
                </div>
                <h3 className="text-sm font-extrabold text-[#111827] tracking-tight">
                  Route Intelligence
                </h3>
              </div>
              <Link to="/route-analysis" className="text-xs font-black text-slate-700 hover:text-[#111827] flex items-center gap-1 hover:underline">
                <span>View Details</span>
                <ArrowRight className="w-3.5 h-3.5 text-[#4B5563]" />
              </Link>
            </div>

            <div className="mt-1">
              <div className="text-xs font-black text-slate-900 flex items-center gap-1.5">
                <span className="flex items-center gap-1"><span>🇦🇺</span> Hay Point, Australia</span>
                <span className="text-[#4B5563] font-bold">➔</span>
                <span className="flex items-center gap-1"><span>🇮🇳</span> Paradip, India</span>
              </div>
              <p className="text-[10px] text-slate-500 font-medium">
                Optimized route based on real-time maritime conditions and AI load model
              </p>
            </div>
          </div>

          {/* 3D Tactile Trade Lane Bridge Box */}
          <div
            style={{
              transform: 'translateZ(20px)',
              boxShadow: 'inset 0 1px 0 #FFFFFF, 0 4px 10px rgba(15, 39, 71, 0.05)',
            }}
            className="p-3 rounded-xl bg-gradient-to-r from-slate-50 via-white to-slate-50 border border-slate-200/90 flex items-center justify-between"
          >
            <div className="flex items-center gap-2.5">
              <span className="text-2xl drop-shadow-sm">🇦🇺</span>
              <div>
                <span className="text-xs font-black text-slate-900 block leading-tight">Hay Point</span>
                <span className="text-[9px] text-slate-500 font-bold uppercase tracking-wider">Australia</span>
              </div>
            </div>
            <div className="p-1.5 rounded-full bg-slate-100 border border-slate-200 text-[#111827] shadow-xs">
              <ArrowRight className="w-3.5 h-3.5" />
            </div>
            <div className="flex items-center gap-2.5 text-right">
              <div>
                <span className="text-xs font-black text-slate-900 block leading-tight">Paradip</span>
                <span className="text-[9px] text-slate-500 font-bold uppercase tracking-wider">India</span>
              </div>
              <span className="text-2xl drop-shadow-sm">🇮🇳</span>
            </div>
          </div>

          {/* 4 Tactile Micro-Chips Grid with 3D Depth */}
          <div style={{ transform: 'translateZ(22px)' }} className="grid grid-cols-2 gap-2">
            
            {/* Tile 1: Distance */}
            <div
              className="p-2.5 rounded-xl bg-gradient-to-br from-white to-slate-50 border border-slate-200/80 shadow-xs flex items-center gap-2.5 hover:border-[#E5A93C] transition-all"
              style={{ boxShadow: 'inset 0 1px 0 #FFFFFF, 0 3px 6px rgba(15, 39, 71, 0.04)' }}
            >
              <div className="p-1.5 rounded-lg bg-blue-50 border border-blue-200/60 text-blue-700">
                <Compass className="w-4 h-4" />
              </div>
              <div>
                <span className="text-[9px] text-slate-400 block uppercase font-black tracking-wider">Distance</span>
                <span className="text-xs font-black text-slate-900 font-mono">5,982 nm</span>
              </div>
            </div>

            {/* Tile 2: Est Voyage Days */}
            <div
              className="p-2.5 rounded-xl bg-gradient-to-br from-white to-slate-50 border border-slate-200/80 shadow-xs flex items-center gap-2.5 hover:border-[#E5A93C] transition-all"
              style={{ boxShadow: 'inset 0 1px 0 #FFFFFF, 0 3px 6px rgba(15, 39, 71, 0.04)' }}
            >
              <div className="p-1.5 rounded-lg bg-[#F8F9FA] border border-[#E5E7EB] text-[#4B5563]">
                <Clock className="w-4 h-4" />
              </div>
              <div>
                <span className="text-[9px] text-slate-400 block uppercase font-black tracking-wider">Est. Voyage</span>
                <span className="text-xs font-black text-slate-900 font-mono">~ 28 days</span>
              </div>
            </div>

            {/* Tile 3: Cargo Type */}
            <div
              className="p-2.5 rounded-xl bg-gradient-to-br from-white to-slate-50 border border-slate-200/80 shadow-xs flex items-center gap-2.5 hover:border-[#E5A93C] transition-all"
              style={{ boxShadow: 'inset 0 1px 0 #FFFFFF, 0 3px 6px rgba(15, 39, 71, 0.04)' }}
            >
              <div className="p-1.5 rounded-lg bg-emerald-50 border border-emerald-200/60 text-emerald-700">
                <FileText className="w-4 h-4" />
              </div>
              <div>
                <span className="text-[9px] text-slate-400 block uppercase font-black tracking-wider">Cargo Type</span>
                <span className="text-xs font-black text-slate-900">Iron Ore</span>
              </div>
            </div>

            {/* Tile 4: Vessel Type */}
            <div
              className="p-2.5 rounded-xl bg-gradient-to-br from-white to-slate-50 border border-slate-200/80 shadow-xs flex items-center gap-2.5 hover:border-[#E5A93C] transition-all"
              style={{ boxShadow: 'inset 0 1px 0 #FFFFFF, 0 3px 6px rgba(15, 39, 71, 0.04)' }}
            >
              <div className="p-1.5 rounded-lg bg-indigo-50 border border-indigo-200/60 text-indigo-700">
                <Ship className="w-4 h-4" />
              </div>
              <div>
                <span className="text-[9px] text-slate-400 block uppercase font-black tracking-wider">Vessel Type</span>
                <span className="text-xs font-black text-slate-900">Capesize</span>
              </div>
            </div>

          </div>

          {/* Landed Cost & Recommended Window Row */}
          <div style={{ transform: 'translateZ(24px)' }} className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-0.5">
            <div
              className="p-2.5 rounded-xl bg-white border border-slate-200/90 shadow-xs"
              style={{ boxShadow: 'inset 0 1px 0 #FFFFFF, 0 3px 8px rgba(15, 39, 71, 0.05)' }}
            >
              <span className="text-[9px] uppercase font-black text-slate-400 flex items-center gap-1 tracking-wider">
                Landed Cost <Info className="w-2.5 h-2.5 text-slate-400" />
              </span>
              <div className="flex items-baseline gap-1 mt-0.5">
                <span className="text-base font-black text-slate-900 font-mono">$98.4</span>
                <span className="text-[10px] font-bold text-slate-500">/MT</span>
              </div>
            </div>

            <div
              className="p-2.5 rounded-xl bg-gradient-to-br from-emerald-50 to-emerald-100/60 border border-emerald-300 text-emerald-950 shadow-xs"
              style={{ boxShadow: 'inset 0 1px 0 rgba(255,255,255,0.8), 0 3px 8px rgba(16, 185, 129, 0.12)' }}
            >
              <span className="text-[9px] uppercase font-black text-emerald-800 flex items-center gap-1 tracking-wider">
                ★ Optimal Window
              </span>
              <span className="text-xs font-black text-emerald-950 block mt-0.5 font-mono">2 – 8 Oct 2026</span>
              <span className="text-[9px] font-semibold text-emerald-700 block">Expected rate trough</span>
            </div>
          </div>

        </Realistic3DBox>
      </div>

      {/* ========================================================================= */}
      {/* CARD 3: 3D REALISTIC ROUTE MAP (3 Columns) */}
      {/* ========================================================================= */}
      <div className="lg:col-span-3">
        <Realistic3DBox accentGlow="rgba(14, 165, 233, 0.18)" className="space-y-3">
          
          {/* Header */}
          <div style={{ transform: 'translateZ(18px)' }} className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="p-2 rounded-xl bg-cyan-500/10 border border-cyan-400/30 text-cyan-700 shadow-xs">
                <Compass className="w-4 h-4 text-[#4B5563]" />
              </div>
              <h3 className="text-sm font-extrabold text-[#111827] tracking-tight">
                Route Map
              </h3>
            </div>
            <Link to="/route-analysis" className="text-xs font-black text-slate-700 hover:text-[#111827] flex items-center gap-1 hover:underline">
              <span>Full Map</span>
              <ArrowRight className="w-3.5 h-3.5 text-[#4B5563]" />
            </Link>
          </div>

          {/* 3D Oceanic Map Canvas with Animated 3D Vessel */}
          <div
            style={{
              transform: 'translateZ(24px)',
              boxShadow: 'inset 0 2px 4px rgba(0,0,0,0.3), 0 8px 20px rgba(15, 39, 71, 0.25)',
            }}
            className="relative w-full h-[225px] rounded-xl overflow-hidden border border-slate-700 bg-gradient-to-br from-[#0F263B] via-[#16364D] to-[#0A1A28] select-none"
          >
            {/* SVG Ocean Topography & Dynamic 3D Maritime Vector Map */}
            <svg viewBox="0 0 300 200" className="w-full h-full object-cover">
              <defs>
                {/* 3D Ocean Gradients */}
                <radialGradient id="oceanBathymetry" cx="50%" cy="50%" r="60%">
                  <stop offset="0%" stopColor="#1E445E" />
                  <stop offset="60%" stopColor="#122E42" />
                  <stop offset="100%" stopColor="#0A1C29" />
                </radialGradient>
                <linearGradient id="landmass3D" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#3E6B82" />
                  <stop offset="100%" stopColor="#254B5E" />
                </linearGradient>
                <linearGradient id="shipRouteGlow" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#F59E0B" />
                  <stop offset="50%" stopColor="#FBBF24" />
                  <stop offset="100%" stopColor="#E5A93C" />
                </linearGradient>
                <filter id="mapGlow" x="-20%" y="-20%" width="140%" height="140%">
                  <feDropShadow dx="0" dy="2" stdDeviation="3" floodColor="#F59E0B" floodOpacity="0.5" />
                </filter>
              </defs>

              {/* Bathymetric Deep Ocean Floor */}
              <rect width="300" height="200" fill="url(#oceanBathymetry)" />

              {/* Maritime Bathymetric Depth Rings */}
              <circle cx="160" cy="110" r="70" fill="none" stroke="#254D66" strokeWidth="0.8" opacity="0.4" strokeDasharray="3 3" />
              <circle cx="160" cy="110" r="110" fill="none" stroke="#254D66" strokeWidth="0.8" opacity="0.25" strokeDasharray="4 4" />

              {/* India Landmass with 3D Bevel Stroke */}
              <path
                d="M70,20 Q85,50 80,75 Q75,90 90,95 Q100,60 110,30 Z"
                fill="url(#landmass3D)"
                stroke="#5A8EA8"
                strokeWidth="1.2"
              />

              {/* Southeast Asia Landmass */}
              <path
                d="M125,70 Q140,85 135,110 Q150,115 160,105 Q170,120 185,115"
                fill="url(#landmass3D)"
                stroke="#5A8EA8"
                strokeWidth="1.2"
              />

              {/* Indonesia Archipelagic Straits */}
              <path d="M130,120 Q160,125 180,130" stroke="#5A8EA8" strokeWidth="4.5" strokeLinecap="round" fill="none" />
              <path d="M190,132 Q210,135 220,133" stroke="#5A8EA8" strokeWidth="4.5" strokeLinecap="round" fill="none" />

              {/* Australia Landmass */}
              <path
                d="M200,140 Q260,135 285,160 Q270,195 220,190 Q195,170 200,140 Z"
                fill="url(#landmass3D)"
                stroke="#5A8EA8"
                strokeWidth="1.2"
              />

              {/* Shipping Trajectory Path (Glowing Gold Dashed Arc) */}
              <path
                d="M85,75 Q160,130 250,155"
                fill="none"
                stroke="url(#shipRouteGlow)"
                strokeWidth="3"
                strokeDasharray="5 4"
                filter="url(#mapGlow)"
              />

              {/* Origin Port: Paradip with Pulsing Radar Ring */}
              <g>
                <circle cx="85" cy="75" r="9" fill="none" stroke="#F59E0B" strokeWidth="1" className="animate-ping opacity-60 origin-center" />
                <circle cx="85" cy="75" r="5" fill="#E5A93C" stroke="#FFFFFF" strokeWidth="1.5" />
                <text x="75" y="65" fill="#FFFFFF" fontSize="9" fontWeight="900" textAnchor="end" filter="drop-shadow(0 1px 2px rgba(0,0,0,0.8))">
                  🇮🇳 Paradip
                </text>
              </g>

              {/* Destination Port: Hay Point with Radar Ring */}
              <g>
                <circle cx="250" cy="155" r="9" fill="none" stroke="#F59E0B" strokeWidth="1" className="animate-ping opacity-60 origin-center" />
                <circle cx="250" cy="155" r="5" fill="#E5A93C" stroke="#FFFFFF" strokeWidth="1.5" />
                <text x="258" y="150" fill="#FFFFFF" fontSize="9" fontWeight="900" filter="drop-shadow(0 1px 2px rgba(0,0,0,0.8))">
                  🇦🇺 Hay Point
                </text>
              </g>

              {/* Live Animated 3D Vessel Symbol Moving Along Sea Arc */}
              <g transform={`translate(${shipX}, ${shipY}) scale(0.9)`}>
                <circle cx="0" cy="0" r="7" fill="#111827" stroke="#38BDF8" strokeWidth="1.8" />
                <circle cx="0" cy="0" r="10" fill="none" stroke="#38BDF8" strokeWidth="1" opacity="0.8" className="animate-ping origin-center" />
                <polygon points="0,-4 3,3 0,1.5 -3,3" fill="#38BDF8" transform="rotate(65)" />
              </g>

              {/* Watermark Topographic Labels */}
              <text x="75" y="135" fill="#42708A" fontSize="9" fontWeight="900" letterSpacing="2" opacity="0.6">
                INDIAN OCEAN
              </text>
              <text x="215" y="178" fill="#42708A" fontSize="8" fontWeight="900" letterSpacing="1.5" opacity="0.6">
                AUSTRALIA
              </text>
            </svg>

            {/* 3D Frosted Glass Distance HUD (Top Right) */}
            <div
              style={{
                transform: 'translateZ(28px)',
                boxShadow: '0 8px 16px rgba(0,0,0,0.35), inset 0 1px 0 rgba(255,255,255,0.2)',
              }}
              className="absolute top-2.5 right-2.5 p-2 rounded-xl bg-[#0B1E36]/90 backdrop-blur-md text-white border border-white/20 text-right space-y-0.5"
            >
              <div className="text-[9px] uppercase font-bold text-slate-400 flex items-center justify-end gap-1">
                <Ship className="w-3 h-3 text-[#E5A93C]" />
                <span>Great Circle</span>
              </div>
              <div className="text-xs font-black text-white font-mono tracking-tight">5,982 nm</div>
              <div className="text-[9px] font-bold text-emerald-400">Est. 28 Days</div>
            </div>

            {/* 3D Interactive Map Zoom Controls (Bottom Right) */}
            <div
              style={{
                transform: 'translateZ(28px)',
                boxShadow: '0 6px 12px rgba(0,0,0,0.3)',
              }}
              className="absolute bottom-2.5 right-2.5 flex flex-col rounded-lg bg-[#111827]/90 backdrop-blur-md border border-white/20 overflow-hidden text-white text-xs font-bold"
            >
              <button
                type="button"
                className="w-6 h-6 flex items-center justify-center hover:bg-white/20 transition-colors border-b border-white/10 cursor-pointer"
                title="Zoom in"
              >
                +
              </button>
              <button
                type="button"
                className="w-6 h-6 flex items-center justify-center hover:bg-white/20 transition-colors cursor-pointer"
                title="Zoom out"
              >
                −
              </button>
            </div>

          </div>

        </Realistic3DBox>
      </div>

    </div>
  );
};
