import React, { useState, useRef, useEffect, useMemo } from 'react';
import { Sparkles, Rotate3d, Layers, Eye, TrendingDown, CheckCircle2, Maximize2, Play, Pause } from 'lucide-react';

export interface TrendDataPoint {
  month: string;
  label?: string;
  rate: number;
  isOptimal?: boolean;
}

interface ThreeDFreightTrendChartProps {
  data: TrendDataPoint[];
  optimalWindowText?: string;
  optimalPointText?: string;
  baseRate?: number;
}

export const ThreeDFreightTrendChart: React.FC<ThreeDFreightTrendChartProps> = ({
  data,
  optimalWindowText = 'Optimal Window (12–24 Nov)',
  optimalPointText = 'Optimal Point: 12 Nov ($13.73)',
  baseRate = 15.00,
}) => {
  const [viewMode, setViewMode] = useState<'ribbon' | 'pillars' | 'mesh'>('ribbon');
  const [isAutoOrbit, setIsAutoOrbit] = useState(false);
  const [hoveredIndex, setHoveredIndex] = useState<number | null>(5); // default to 12 Nov optimal point
  const [rotX, setRotX] = useState(14);
  const [rotY, setRotY] = useState(-18);
  const [isHovered, setIsHovered] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);
  const animationFrameRef = useRef<number | null>(null);

  // Min and max bounds for 3D normalization
  const minRate = 10;
  const maxRate = 20;

  // Auto-orbit cinematic animation loop
  useEffect(() => {
    if (!isAutoOrbit) {
      if (animationFrameRef.current) cancelAnimationFrame(animationFrameRef.current);
      return;
    }

    let angle = 0;
    const animate = () => {
      angle += 0.015;
      setRotY(-18 + Math.sin(angle) * 22);
      setRotX(14 + Math.cos(angle * 0.7) * 8);
      animationFrameRef.current = requestAnimationFrame(animate);
    };
    animationFrameRef.current = requestAnimationFrame(animate);

    return () => {
      if (animationFrameRef.current) cancelAnimationFrame(animationFrameRef.current);
    };
  }, [isAutoOrbit]);

  // Interactive mouse 3D parallax tilt
  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (isAutoOrbit || !containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    const centerX = rect.width / 2;
    const centerY = rect.height / 2;

    const normalizedX = (x - centerX) / centerX; // -1 to 1
    const normalizedY = (y - centerY) / centerY; // -1 to 1

    // Map to tilt angles
    setRotY(Number((-18 + normalizedX * 24).toFixed(1)));
    setRotX(Number((14 - normalizedY * 18).toFixed(1)));
  };

  const handleMouseLeave = () => {
    setIsHovered(false);
    if (!isAutoOrbit) {
      // Return smoothly to default isometric angle
      setRotX(14);
      setRotY(-18);
    }
  };

  // Convert rate to 3D coordinate heights (0px = bottom, 140px = top)
  const chartHeight = 130;
  const chartWidth = 320;
  const pointCount = data.length;

  const points3D = useMemo(() => {
    return data.map((item, idx) => {
      const normalizedRate = Math.max(0, Math.min(1, (item.rate - minRate) / (maxRate - minRate)));
      const x = (idx / (pointCount - 1)) * chartWidth;
      const y = chartHeight - normalizedRate * chartHeight;
      const depthZ = idx * 6; // Slight Z depth separation
      return {
        ...item,
        x,
        y,
        depthZ,
        normalizedRate,
        originalIndex: idx,
      };
    });
  }, [data, pointCount]);

  // Generate SVG Ribbon 3D polygon paths
  const ribbonPath = useMemo(() => {
    if (points3D.length < 2) return '';
    return points3D.reduce((path, pt, idx) => {
      if (idx === 0) return `M ${pt.x},${pt.y}`;
      const prev = points3D[idx - 1];
      const cp1x = prev.x + (pt.x - prev.x) / 2;
      const cp1y = prev.y;
      const cp2x = prev.x + (pt.x - prev.x) / 2;
      const cp2y = pt.y;
      return `${path} C ${cp1x},${cp1y} ${cp2x},${cp2y} ${pt.x},${pt.y}`;
    }, '');
  }, [points3D]);

  // Area under 3D curve
  const ribbonAreaPath = useMemo(() => {
    if (points3D.length < 2) return '';
    const last = points3D[points3D.length - 1];
    const first = points3D[0];
    return `${ribbonPath} L ${last.x},${chartHeight + 15} L ${first.x},${chartHeight + 15} Z`;
  }, [ribbonPath, points3D, chartHeight]);

  // 3D Extruded Ribbon Shadow Path (offset by +8px in Y and +8px in X for 3D depth)
  const ribbonExtrusionPath = useMemo(() => {
    if (points3D.length < 2) return '';
    const topPath = points3D.map((p, i) => `${i === 0 ? 'M' : 'L'} ${p.x},${p.y}`).join(' ');
    const bottomPath = [...points3D].reverse().map(p => `L ${p.x + 4},${p.y + 12}`).join(' ');
    return `${topPath} ${bottomPath} Z`;
  }, [points3D]);

  const activePoint = hoveredIndex !== null ? points3D[hoveredIndex] || points3D[5] : points3D[5];

  return (
    <div className="w-full select-none flex flex-col justify-between">
      {/* 3D Visualizer Scene Container */}
      <div
        ref={containerRef}
        onMouseMove={handleMouseMove}
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={handleMouseLeave}
        className="relative w-full h-[230px] rounded-xl overflow-hidden bg-gradient-to-b from-[#09172A] via-[#0E2038] to-[#071322] border border-slate-700/60 shadow-inner flex items-center justify-center cursor-crosshair transition-all"
        style={{ perspective: 900 }}
      >
        {/* Subtle Ambient Radial Lighting in 3D scene */}
        <div
          className="absolute inset-0 pointer-events-none opacity-40 transition-transform duration-300"
          style={{
            background: `radial-gradient(circle at ${50 + rotY * 1.5}% ${50 - rotX * 1.5}%, rgba(37, 99, 235, 0.45), transparent 70%)`,
          }}
        />

        {/* TOP CONTROLS: 3D MODE PILLS & ORBIT BUTTON */}
        <div className="absolute top-2 left-2 right-2 z-30 flex items-center justify-between">
          <div className="flex items-center gap-1 bg-slate-900/80 backdrop-blur-md p-1 rounded-lg border border-white/10 shadow-md">
            <button
              type="button"
              onClick={() => setViewMode('ribbon')}
              className={`px-2 py-0.5 rounded text-[9px] font-bold transition-all cursor-pointer ${
                viewMode === 'ribbon'
                  ? 'bg-gradient-to-r from-blue-600 to-cyan-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              📐 3D Ribbon
            </button>
            <button
              type="button"
              onClick={() => setViewMode('pillars')}
              className={`px-2 py-0.5 rounded text-[9px] font-bold transition-all cursor-pointer ${
                viewMode === 'pillars'
                  ? 'bg-gradient-to-r from-blue-600 to-cyan-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              🏢 3D Pillars
            </button>
            <button
              type="button"
              onClick={() => setViewMode('mesh')}
              className={`px-2 py-0.5 rounded text-[9px] font-bold transition-all cursor-pointer ${
                viewMode === 'mesh'
                  ? 'bg-gradient-to-r from-blue-600 to-cyan-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              📈 3D Wave
            </button>
          </div>

          <div className="flex items-center gap-1">
            <button
              type="button"
              onClick={() => setIsAutoOrbit(prev => !prev)}
              className={`px-2 py-1 rounded-lg text-[9px] font-bold transition-all flex items-center gap-1 backdrop-blur-md border shadow-md cursor-pointer ${
                isAutoOrbit
                  ? 'bg-cyan-500 text-slate-950 border-cyan-300 ring-1 ring-cyan-400/50'
                  : 'bg-slate-900/80 text-slate-300 border-white/10 hover:text-white'
              }`}
              title="Toggle 3D Orbit Animation"
            >
              <Rotate3d className={`w-3 h-3 ${isAutoOrbit ? 'animate-spin' : ''}`} />
              <span>{isAutoOrbit ? 'Orbiting' : '3D Orbit'}</span>
            </button>
          </div>
        </div>

        {/* 3D ISOMETRIC STAGE TRANSFORM WRAPPER */}
        <div
          className="relative w-[340px] h-[175px] transition-transform duration-100 ease-out"
          style={{
            transform: `rotateX(${rotX}deg) rotateY(${rotY}deg) rotateZ(1deg) scale(0.96)`,
            transformStyle: 'preserve-3d',
          }}
        >
          {/* 1. 3D FLOOR GRID & ISOMETRIC PLANES */}
          <div
            className="absolute inset-0 rounded-lg pointer-events-none border border-cyan-500/20"
            style={{
              transform: 'translateZ(-25px)',
              background: `
                linear-gradient(90deg, rgba(56, 189, 248, 0.07) 1px, transparent 1px),
                linear-gradient(rgba(56, 189, 248, 0.07) 1px, transparent 1px)
              `,
              backgroundSize: '34px 28px',
              boxShadow: '0 20px 40px -15px rgba(2, 132, 199, 0.3)',
            }}
          />

          {/* 2. 3D VOLUMETRIC OPTIMAL BOOKING SLAB (12 Nov – 24 Nov) */}
          <div
            className="absolute top-2 bottom-3 left-[170px] w-[65px] rounded-lg pointer-events-none transition-all duration-300"
            style={{
              transform: 'translateZ(10px)',
              background: 'linear-gradient(180deg, rgba(16, 185, 129, 0.28) 0%, rgba(5, 150, 105, 0.08) 100%)',
              border: '1px solid rgba(52, 211, 153, 0.5)',
              boxShadow: '0 0 20px rgba(16, 185, 129, 0.25), inset 0 0 15px rgba(52, 211, 153, 0.15)',
            }}
          >
            <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-1.5 py-0.5 rounded bg-emerald-500/90 text-white text-[7.5px] font-black tracking-wider uppercase shadow whitespace-nowrap">
              ★ Optimal Fix
            </div>
          </div>

          {/* 3. 3D SVG CURVES & RIBBON LAYER */}
          {viewMode !== 'pillars' ? (
            <svg
              viewBox={`0 0 ${chartWidth} ${chartHeight + 20}`}
              className="absolute inset-0 w-full h-full overflow-visible"
              style={{ transform: 'translateZ(25px)' }}
            >
              <defs>
                {/* 3D Top Ribbon Gradient */}
                <linearGradient id="neonRibbonGrad" x1="0%" y1="0%" x2="100%" y2="0%">
                  <stop offset="0%" stopColor="#38BDF8" />
                  <stop offset="50%" stopColor="#10B981" />
                  <stop offset="100%" stopColor="#3B82F6" />
                </linearGradient>

                {/* 3D Side Extrusion Gradient */}
                <linearGradient id="extrusionGrad" x1="0%" y1="0%" x2="0%" y2="100%">
                  <stop offset="0%" stopColor="rgba(56, 189, 248, 0.5)" />
                  <stop offset="100%" stopColor="rgba(15, 23, 42, 0.1)" />
                </linearGradient>

                {/* 3D Volumetric Area Fill */}
                <linearGradient id="volumetricFillGrad" x1="0%" y1="0%" x2="0%" y2="100%">
                  <stop offset="0%" stopColor="rgba(14, 165, 233, 0.35)" />
                  <stop offset="60%" stopColor="rgba(16, 185, 129, 0.15)" />
                  <stop offset="100%" stopColor="rgba(15, 23, 42, 0.0)" />
                </linearGradient>

                {/* Glow Filter */}
                <filter id="ribbon3DGlow" x="-20%" y="-20%" width="140%" height="140%">
                  <feGaussianBlur stdDeviation="3" result="blur" />
                  <feComposite in="SourceGraphic" in2="blur" operator="over" />
                </filter>
              </defs>

              {/* Volumetric Under-Curve Area */}
              <path d={ribbonAreaPath} fill="url(#volumetricFillGrad)" opacity={0.8} />

              {/* 3D Ribbon Extrusion Thickness */}
              <path d={ribbonExtrusionPath} fill="url(#extrusionGrad)" opacity={0.65} />

              {/* 3D Mesh Wireframe grid lines if Wave Mode */}
              {viewMode === 'mesh' && (
                <g stroke="rgba(56, 189, 248, 0.25)" strokeWidth="1" strokeDasharray="3 3">
                  {points3D.map((p, idx) => (
                    <line key={`mesh-${idx}`} x1={p.x} y1={p.y} x2={p.x} y2={chartHeight + 15} />
                  ))}
                  <line x1={0} y1={chartHeight * 0.3} x2={chartWidth} y2={chartHeight * 0.3} />
                  <line x1={0} y1={chartHeight * 0.6} x2={chartWidth} y2={chartHeight * 0.6} />
                </g>
              )}

              {/* Foreground Neon Glowing 3D Ribbon */}
              <path
                d={ribbonPath}
                fill="none"
                stroke="url(#neonRibbonGrad)"
                strokeWidth={4}
                filter="url(#ribbon3DGlow)"
                strokeLinecap="round"
              />

              {/* Floating 3D Data Nodes */}
              {points3D.map((pt, idx) => {
                const isSelected = hoveredIndex === idx;
                const isOpt = pt.isOptimal;

                return (
                  <g
                    key={idx}
                    className="cursor-pointer transition-transform hover:scale-125"
                    onClick={() => setHoveredIndex(idx)}
                    onMouseEnter={() => setHoveredIndex(idx)}
                  >
                    {/* Vertical 3D Laser Projection Line */}
                    {isSelected && (
                      <line
                        x1={pt.x}
                        y1={pt.y}
                        x2={pt.x}
                        y2={chartHeight + 15}
                        stroke="#38BDF8"
                        strokeWidth="1.5"
                        strokeDasharray="3 3"
                        opacity={0.85}
                      />
                    )}

                    {/* Node Circle Outer Glow */}
                    <circle
                      cx={pt.x}
                      cy={pt.y}
                      r={isOpt ? 8 : isSelected ? 6 : 4}
                      fill={isOpt ? '#10B981' : isSelected ? '#38BDF8' : '#111827'}
                      stroke={isOpt ? '#34D399' : '#FFFFFF'}
                      strokeWidth={isOpt ? 2.5 : 1.5}
                      className={isOpt ? 'animate-pulse' : ''}
                    />

                    {/* Inner Core */}
                    <circle
                      cx={pt.x}
                      cy={pt.y}
                      r={isOpt ? 3.5 : 2}
                      fill="#FFFFFF"
                    />
                  </g>
                );
              })}
            </svg>
          ) : (
            /* 4. 3D ISOMETRIC PILLARS VISUALIZATION MODE */
            <div
              className="absolute inset-0 flex items-end justify-between px-2 pb-2"
              style={{ transform: 'translateZ(30px)' }}
            >
              {points3D.map((pt, idx) => {
                const isSelected = hoveredIndex === idx;
                const isOpt = pt.isOptimal;
                const pillarHeightPx = Math.round(pt.normalizedRate * 105) + 20;

                return (
                  <div
                    key={idx}
                    onClick={() => setHoveredIndex(idx)}
                    onMouseEnter={() => setHoveredIndex(idx)}
                    className="relative flex flex-col items-center cursor-pointer group"
                    style={{ transform: 'translateZ(15px)' }}
                  >
                    {/* Floating Rate Label on Top */}
                    <span
                      className={`text-[8px] font-mono font-black mb-1 transition-all ${
                        isOpt
                          ? 'text-emerald-400 scale-110'
                          : isSelected
                            ? 'text-cyan-300'
                            : 'text-slate-400 group-hover:text-white'
                      }`}
                    >
                      ${pt.rate.toFixed(1)}
                    </span>

                    {/* 3D Extruded Pillar Body */}
                    <div
                      className={`w-6 rounded-t-sm transition-all duration-300 ${
                        isOpt
                          ? 'bg-gradient-to-t from-emerald-700 via-emerald-500 to-teal-300 shadow-[0_0_15px_rgba(16,185,129,0.6)] border-t-2 border-white'
                          : isSelected
                            ? 'bg-gradient-to-t from-blue-700 via-sky-500 to-cyan-300 shadow-[0_0_12px_rgba(56,189,248,0.5)] border-t border-white'
                            : 'bg-gradient-to-t from-slate-800 via-slate-700 to-slate-600 opacity-80 hover:opacity-100 hover:brightness-125'
                      }`}
                      style={{
                        height: `${pillarHeightPx}px`,
                        transform: `rotateX(10deg) ${isSelected ? 'scaleY(1.05)' : ''}`,
                        boxShadow: '0 8px 16px rgba(0,0,0,0.5)',
                      }}
                    />

                    {/* X-Axis Date Pill */}
                    <span className="text-[7.5px] text-slate-400 font-bold mt-1 tracking-tight truncate max-w-[32px]">
                      {pt.month.replace(' 2026', '')}
                    </span>
                  </div>
                );
              })}
            </div>
          )}

          {/* 5. FLOATING 3D GLASS TOOLTIP PROBE */}
          {activePoint && (
            <div
              className="absolute z-40 pointer-events-none transition-all duration-200"
              style={{
                left: `${Math.min(220, Math.max(20, activePoint.x - 55))}px`,
                top: `${Math.max(10, activePoint.y - 65)}px`,
                transform: 'translateZ(65px)',
              }}
            >
              <div className="px-3 py-2 rounded-xl bg-slate-900/95 backdrop-blur-xl border border-cyan-400/50 shadow-[0_12px_30px_rgba(0,0,0,0.8)] text-white text-xs font-mono">
                <div className="flex items-center justify-between gap-2 border-b border-white/10 pb-1 mb-1 font-sans">
                  <span className="font-black text-slate-200 text-[10px]">
                    {activePoint.month}
                  </span>
                  {activePoint.isOptimal && (
                    <span className="px-1.5 py-0.2 rounded bg-emerald-500/20 text-emerald-400 border border-emerald-400/40 text-[8px] font-bold">
                      Optimal Target
                    </span>
                  )}
                </div>
                <div className="text-cyan-400 font-black text-xs flex items-center gap-1">
                  <span>Rate:</span>
                  <span className="text-white text-sm font-black">${activePoint.rate.toFixed(2)}</span>
                  <span className="text-slate-400 text-[9px]">/ MT</span>
                </div>
                {activePoint.isOptimal && (
                  <div className="text-[8.5px] text-emerald-400 font-bold mt-0.5 font-sans">
                    ✨ Saves $1.27/MT (-8.5%) vs spot
                  </div>
                )}
              </div>
            </div>
          )}
        </div>

        {/* 3D Interactive HUD Instruction Badge (Bottom Left) */}
        <div className="absolute bottom-2 left-2.5 z-30 flex items-center gap-1.5 text-[8.5px] text-slate-300 bg-slate-900/80 backdrop-blur-md px-2 py-0.8 rounded-md border border-white/10">
          <Sparkles className="w-2.5 h-2.5 text-cyan-400" />
          <span>Interactive 3D • Move cursor to tilt & explore</span>
        </div>

        {/* 3D Rotation Angle Readout (Bottom Right) */}
        <div className="absolute bottom-2 right-2.5 z-30 text-[8px] font-mono text-cyan-400/80 bg-slate-950/70 backdrop-blur-md px-1.5 py-0.5 rounded border border-cyan-500/20">
          Rx: {rotX}° | Ry: {rotY}°
        </div>
      </div>

      {/* FOOTER METRICS (Sync with Image 2) */}
      <div className="pt-2.5 mt-2 border-t border-slate-100 flex items-center justify-between text-[10px] text-slate-500 font-medium">
        <span>Rate ($/MT) Axis: 10–20</span>
        <span className="text-[#059669] font-bold font-mono">
          {optimalPointText}
        </span>
      </div>
    </div>
  );
};
