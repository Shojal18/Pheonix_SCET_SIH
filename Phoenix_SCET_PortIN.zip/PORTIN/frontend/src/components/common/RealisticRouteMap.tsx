import React, { useState, useEffect, useMemo, useRef, useCallback } from 'react';
import { MapContainer, TileLayer, Polyline, Marker, Tooltip, useMap, Circle } from 'react-leaflet';
import L from 'leaflet';
import {
  CloudSun, Waves, Wind, AlertTriangle, Compass, Layers,
  Maximize2, RotateCcw, Navigation, Anchor, Ship, Eye, Info, Sparkles,
  MousePointer, Radio, Crosshair
} from 'lucide-react';

// Fix Leaflet default icon paths in Vite
delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png',
  iconUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
});

// Port Coordinates Registry
const PORT_COORDINATES: Record<string, [number, number]> = {
  // Australia
  'Australia (Hay Point / Dalrymple Bay)': [-21.29, 149.30],
  'Hay Point': [-21.29, 149.30],
  'Newcastle': [-32.93, 151.78],
  'Gladstone': [-23.84, 151.25],
  'Port Hedland': [-20.31, 118.58],
  'Dampier': [-20.66, 116.71],
  'Abbot Point': [-19.88, 148.08],

  // Indonesia
  'Indonesia (Taboneo Anchorage)': [-3.75, 114.45],
  'Taboneo': [-3.75, 114.45],
  'Balikpapan': [-1.27, 116.83],
  'Samarinda': [-0.58, 117.25],
  'Tarahan': [-5.52, 105.33],

  // South Africa & Mozambique
  'South Africa (Richards Bay)': [-28.80, 32.03],
  'Richards Bay': [-28.80, 32.03],
  'Durban': [-29.87, 31.02],
  'Mozambique (Maputo)': [-25.97, 32.57],
  'Maputo': [-25.97, 32.57],
  'Beira': [-19.84, 34.84],

  // United States & Russia
  'USA (Baltimore / Hampton Roads)': [36.96, -76.32],
  'Baltimore': [39.28, -76.58],
  'Houston': [29.76, -95.36],
  'Russia (Ust-Luga / Vostochny)': [43.12, 131.89],
  'Vostochny': [43.12, 131.89],

  // Indian East Coast
  'Paradip Port (Odisha)': [20.26, 86.67],
  'Paradip': [20.26, 86.67],
  'Dhamra Port (Odisha)': [20.80, 86.97],
  'Dhamra': [20.80, 86.97],
  'Haldia Dock Complex (West Bengal)': [22.02, 88.06],
  'Haldia': [22.02, 88.06],
  'Visakhapatnam Port (Andhra Pradesh)': [17.68, 83.28],
  'Visakhapatnam': [17.68, 83.28],
  'Gopalpur Port (Odisha)': [19.26, 84.97],
  'Gopalpur': [19.26, 84.97],
  'Chennai Port (Tamil Nadu)': [13.08, 80.29],
  'Chennai': [13.08, 80.29],
  'Kamarajar Port / Ennore (Tamil Nadu)': [13.25, 80.33],
  'Ennore': [13.25, 80.33],
  'Krishnapatnam Port (Andhra Pradesh)': [14.25, 80.12],
  'Krishnapatnam': [14.25, 80.12],
  'Kakinada Deep Water Port (Andhra Pradesh)': [16.98, 82.27],
  'Kakinada': [16.98, 82.27],
  'Gangavaram Port (Andhra Pradesh)': [17.61, 83.23],
  'Gangavaram': [17.61, 83.23],
  'Karaikal Port (Puducherry)': [10.84, 79.84],
  'Karaikal': [10.84, 79.84],
  'V.O. Chidambaranar / Tuticorin (Tamil Nadu)': [8.75, 78.18],
  'Tuticorin': [8.75, 78.18],

  // Indian West Coast
  'Hazira (Gujarat)': [21.10, 72.63],
  'Hazira': [21.10, 72.63],
  'Mumbai Port Trust (Maharashtra)': [18.95, 72.84],
  'Mumbai': [18.95, 72.84],
  'Jawaharlal Nehru Port Trust / JNPT (Maharashtra)': [18.95, 72.95],
  'JNPT': [18.95, 72.95],
  'Deendayal Port / Kandla (Gujarat)': [23.01, 70.22],
  'Kandla': [23.01, 70.22],
  'Mundra Port (Gujarat)': [22.75, 69.70],
  'Mundra': [22.75, 69.70],
  'Pipavav Port (Gujarat)': [20.91, 71.51],
  'Pipavav': [20.91, 71.51],
  'Dahej Port (Gujarat)': [21.70, 72.53],
  'Dahej': [21.70, 72.53],
  'Mormugao Port (Goa)': [15.42, 73.80],
  'Mormugao': [15.42, 73.80],
  'New Mangalore Port (Karnataka)': [12.92, 74.81],
  'New Mangalore': [12.92, 74.81],
  'Cochin Port (Kerala)': [9.97, 76.27],
  'Cochin': [9.97, 76.27],
  'Jaigarh Port (Maharashtra)': [17.30, 73.20],
  'Jaigarh': [17.30, 73.20],
};

function getPortCoords(name: string, isOrigin: boolean): [number, number] {
  if (PORT_COORDINATES[name]) return PORT_COORDINATES[name];
  for (const [key, coords] of Object.entries(PORT_COORDINATES)) {
    if (name.toLowerCase().includes(key.toLowerCase()) || key.toLowerCase().includes(name.toLowerCase())) {
      return coords;
    }
  }
  return isOrigin ? [-21.29, 149.30] : [20.26, 86.67];
}

// Generate realistic maritime route avoiding landmasses
function generateMaritimeRoute(originCoords: [number, number], destCoords: [number, number], originName: string, destName: string): [number, number][] {
  const isDomestic = originName.includes('India') || (originCoords[0] > 5 && originCoords[0] < 30 && originCoords[1] > 65 && originCoords[1] < 95);
  const isWestCoastDest = destCoords[1] < 78;
  const isEastCoastDest = destCoords[1] >= 78;

  if (isDomestic) {
    const isWestCoastOrigin = originCoords[1] < 78;
    if (isWestCoastOrigin && isEastCoastDest) {
      return [
        originCoords,
        [originCoords[0] - 2.5, originCoords[1] - 0.8],
        [15.0, 73.0],
        [10.5, 75.2],
        [7.2, 77.5],
        [5.8, 80.5],
        [8.2, 82.2],
        [14.0, 82.8],
        destCoords
      ];
    } else if (!isWestCoastOrigin && isWestCoastDest) {
      return [
        originCoords,
        [16.5, 84.0],
        [10.0, 82.5],
        [5.8, 80.5],
        [7.2, 77.5],
        [12.0, 74.0],
        [17.5, 72.0],
        destCoords
      ];
    } else {
      const midLat = (originCoords[0] + destCoords[0]) / 2;
      const midLon = (originCoords[1] + destCoords[1]) / 2 + (isEastCoastDest ? 1.5 : -1.5);
      return [originCoords, [midLat, midLon], destCoords];
    }
  }

  // Australia to India
  if (originName.includes('Australia') || originCoords[1] > 110) {
    if (originCoords[1] > 140) {
      return [
        originCoords,
        [-10.6, 142.4], // Torres Strait
        [-8.8, 126.5],  // Timor Sea
        [-8.4, 115.8],  // Lombok / Bali
        [-2.0, 98.0],   // North Indian Ocean
        [6.5, 87.0],    // Bay of Bengal entrance
        [14.0, 86.5],   // Central Bay of Bengal
        destCoords
      ];
    } else {
      return [
        originCoords,
        [-15.5, 108.0],
        [-7.5, 96.0],
        [3.0, 90.0],
        [12.0, 87.0],
        destCoords
      ];
    }
  }

  // Indonesia to India
  if (originName.includes('Indonesia') || (originCoords[0] > -10 && originCoords[0] < 5 && originCoords[1] > 95 && originCoords[1] < 125)) {
    return [
      originCoords,
      [-5.8, 106.0],
      [-6.0, 104.5],
      [0.0, 95.0],
      [6.0, 93.0],
      [13.5, 88.5],
      destCoords
    ];
  }

  // South Africa / Mozambique to India
  if (originName.includes('Africa') || originName.includes('Mozambique') || originCoords[1] < 50) {
    return [
      originCoords,
      [-16.0, 43.0],
      [-2.0, 58.0],
      [5.5, 75.0],
      [12.0, 83.0],
      destCoords
    ];
  }

  const midLat = (originCoords[0] + destCoords[0]) / 2 - 3.0;
  const midLon = (originCoords[1] + destCoords[1]) / 2;
  return [originCoords, [midLat, midLon], destCoords];
}

// Custom Leaflet Icons
const createPortPinIcon = (isDestination: boolean, portName: string, countryTag: string) => {
  const cleanName = portName.split(' (')[0].replace('Port', '').trim();
  const bgColor = isDestination ? '#10B981' : '#2563EB';
  const ringColor = isDestination ? 'rgba(16, 185, 129, 0.4)' : 'rgba(37, 99, 235, 0.4)';

  return L.divIcon({
    className: 'custom-realistic-port-pin',
    iconSize: [120, 60],
    iconAnchor: [60, 42],
    html: `
      <div style="display: flex; flex-direction: column; align-items: center; cursor: pointer;">
        <div style="
          position: relative;
          width: 32px;
          height: 32px;
          background: ${bgColor};
          border: 2.5px solid #FFFFFF;
          border-radius: 50%;
          box-shadow: 0 0 0 5px ${ringColor}, 0 4px 12px rgba(0,0,0,0.5);
          display: flex;
          align-items: center;
          justify-content: center;
          color: #FFFFFF;
          font-size: 14px;
        ">
          ${isDestination ? '⚓' : '🚢'}
        </div>
        <div style="
          margin-top: 4px;
          background: rgba(15, 23, 42, 0.92);
          backdrop-filter: blur(6px);
          border: 1px solid rgba(255, 255, 255, 0.2);
          box-shadow: 0 4px 10px rgba(0,0,0,0.4);
          padding: 2px 8px;
          border-radius: 6px;
          color: #FFFFFF;
          font-size: 10px;
          font-weight: 800;
          font-family: system-ui, sans-serif;
          white-space: nowrap;
          text-align: center;
        ">
          <div>${cleanName}</div>
          <div style="font-size: 8px; color: ${isDestination ? '#34D399' : '#93C5FD'}; font-weight: 700; text-transform: uppercase;">
            ${isDestination ? '🇮🇳 Discharge Port' : `${countryTag} Loading Hub`}
          </div>
        </div>
      </div>
    `,
  });
};

const createShipAisIcon = (shipName: string, speedKts: number, headingDeg: number) => {
  return L.divIcon({
    className: 'custom-realistic-vessel-pin',
    iconSize: [140, 70],
    iconAnchor: [70, 35],
    html: `
      <div style="display: flex; flex-direction: column; align-items: center; cursor: pointer;">
        <div style="position: relative; width: 36px; height: 36px; display: flex; align-items: center; justify-content: center;">
          <div style="
            position: absolute;
            inset: 0;
            border-radius: 50%;
            background: rgba(14, 165, 233, 0.25);
            animation: ping 2s cubic-bezier(0, 0, 0.2, 1) infinite;
          "></div>
          <div style="
            width: 32px;
            height: 32px;
            background: #0284C7;
            border: 2px solid #FFFFFF;
            border-radius: 8px;
            box-shadow: 0 4px 14px rgba(2, 132, 199, 0.6);
            display: flex;
            align-items: center;
            justify-content: center;
            color: #FFFFFF;
            font-size: 16px;
            transform: rotate(${headingDeg}deg);
            transition: transform 0.4s ease;
          ">
            🚢
          </div>
        </div>
        <div style="
          margin-top: 3px;
          background: rgba(10, 25, 47, 0.95);
          backdrop-filter: blur(8px);
          border: 1px solid #38BDF8;
          box-shadow: 0 4px 12px rgba(0,0,0,0.6);
          padding: 3px 8px;
          border-radius: 6px;
          color: #F0F9FF;
          font-family: system-ui, sans-serif;
          white-space: nowrap;
          text-align: center;
        ">
          <div style="font-size: 9.5px; font-weight: 900; color: #38BDF8; letter-spacing: 0.5px;">${shipName}</div>
          <div style="font-size: 8px; color: #94A3B8; font-weight: 600;">AIS Live • ${speedKts} kts • ${headingDeg}° NW</div>
        </div>
      </div>
    `,
  });
};

const createWaypointWeatherIcon = (name: string, temp: number, wind: number, wave: number, iconEmoji: string) => {
  return L.divIcon({
    className: 'custom-weather-waypoint',
    iconSize: [90, 45],
    iconAnchor: [45, 22],
    html: `
      <div style="
        background: rgba(15, 23, 42, 0.88);
        backdrop-filter: blur(6px);
        border: 1px solid rgba(148, 163, 184, 0.3);
        border-radius: 6px;
        padding: 2px 6px;
        color: #F8FAFC;
        font-family: system-ui, sans-serif;
        box-shadow: 0 2px 8px rgba(0,0,0,0.4);
        display: flex;
        align-items: center;
        gap: 4px;
        cursor: pointer;
      ">
        <span style="font-size: 13px;">${iconEmoji}</span>
        <div style="line-height: 1.1;">
          <div style="font-size: 8.5px; font-weight: 800; color: #E2E8F0;">${name}</div>
          <div style="font-size: 7.5px; color: #38BDF8; font-family: monospace;">${temp}°C | ${wind}kt | ${wave}m</div>
        </div>
      </div>
    `,
  });
};

// Map View Bounds Auto-Fitter
function MapBoundsUpdater({ waypoints }: { waypoints: [number, number][] }) {
  const map = useMap();
  useEffect(() => {
    if (waypoints && waypoints.length >= 2) {
      const bounds = L.latLngBounds(waypoints.map(w => L.latLng(w[0], w[1])));
      map.fitBounds(bounds, { padding: [40, 40], maxZoom: 5, animate: true });
    }
  }, [waypoints, map]);
  return null;
}

// Interactive Cursor-Follow Dynamic Pan Controller
function CursorMotionController({
  enabled,
  onCursorCoordinates,
}: {
  enabled: boolean;
  onCursorCoordinates: (coords: { lat: number; lng: number; region: string } | null) => void;
}) {
  const map = useMap();
  const lastPanTime = useRef<number>(0);

  useEffect(() => {
    const container = map.getContainer();

    const handleMouseMove = (e: MouseEvent) => {
      const rect = container.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;

      // Extract geographic coordinates under cursor
      const point = L.point(x, y);
      const latlng = map.containerPointToLatLng(point);

      // Determine regional sea label based on coordinates
      let region = 'International Oceanic Waters';
      if (latlng.lat > 5 && latlng.lat < 23 && latlng.lng > 80 && latlng.lng < 95) {
        region = 'Bay of Bengal (Monsoon Swell Sector)';
      } else if (latlng.lat > 8 && latlng.lat < 25 && latlng.lng > 60 && latlng.lng < 78) {
        region = 'Arabian Sea (West Coast Corridor)';
      } else if (latlng.lat > -10 && latlng.lat < 10 && latlng.lng > 95 && latlng.lng < 110) {
        region = 'Malacca & Andaman Sea Transit';
      } else if (latlng.lat < -10 && latlng.lng > 110) {
        region = 'Western Pacific / Australian Coral Sea';
      } else if (latlng.lat < 5 && latlng.lng > 60 && latlng.lng < 100) {
        region = 'Equatorial Indian Ocean';
      }

      onCursorCoordinates({
        lat: Number(latlng.lat.toFixed(3)),
        lng: Number(latlng.lng.toFixed(3)),
        region,
      });

      // Smooth cursor-follow motion pan
      if (!enabled) return;

      const now = performance.now();
      if (now - lastPanTime.current < 25) return; // 40 FPS throttle for butter-smooth motion
      lastPanTime.current = now;

      const centerX = rect.width / 2;
      const centerY = rect.height / 2;
      const dx = (x - centerX) / centerX; // -1 to +1
      const dy = (y - centerY) / centerY; // -1 to +1

      // Deadzone in the center (15%) to prevent unwanted drift when hovering center
      const deadzone = 0.15;
      const magnitude = Math.sqrt(dx * dx + dy * dy);

      if (magnitude > deadzone) {
        const panSpeed = (magnitude - deadzone) * 4.5;
        const panX = dx * panSpeed;
        const panY = dy * panSpeed;
        map.panBy([panX, panY], { animate: false });
      }
    };

    const handleMouseLeave = () => {
      onCursorCoordinates(null);
    };

    container.addEventListener('mousemove', handleMouseMove);
    container.addEventListener('mouseleave', handleMouseLeave);

    return () => {
      container.removeEventListener('mousemove', handleMouseMove);
      container.removeEventListener('mouseleave', handleMouseLeave);
    };
  }, [map, enabled, onCursorCoordinates]);

  return null;
}

// Map Custom Zoom & View Controller
function MapControls({
  waypoints,
  cursorFollow,
  setCursorFollow,
}: {
  waypoints: [number, number][];
  cursorFollow: boolean;
  setCursorFollow: React.Dispatch<React.SetStateAction<boolean>>;
}) {
  const map = useMap();

  const handleZoomIn = (e: React.MouseEvent) => {
    e.stopPropagation();
    map.zoomIn();
  };

  const handleZoomOut = (e: React.MouseEvent) => {
    e.stopPropagation();
    map.zoomOut();
  };

  const handleRecenter = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (waypoints && waypoints.length >= 2) {
      const bounds = L.latLngBounds(waypoints.map(w => L.latLng(w[0], w[1])));
      map.fitBounds(bounds, { padding: [40, 40], maxZoom: 5, animate: true });
    }
  };

  return (
    <div className="absolute bottom-12 right-2.5 flex flex-col gap-1.5 z-[400]">
      {/* Cursor Follow Motion Toggle Button */}
      <button
        type="button"
        onClick={(e) => {
          e.stopPropagation();
          setCursorFollow(prev => !prev);
        }}
        className={`w-7 h-7 rounded-lg font-black text-xs flex items-center justify-center border shadow-md backdrop-blur-md transition-all hover:scale-105 cursor-pointer ${
          cursorFollow
            ? 'bg-cyan-500 text-slate-950 border-cyan-300 ring-2 ring-cyan-400/50 shadow-cyan-500/30'
            : 'bg-slate-900/90 text-slate-400 border-white/20 hover:text-white'
        }`}
        title={cursorFollow ? 'Cursor Motion Pan Active (Click to Pause)' : 'Enable Cursor Motion Pan'}
      >
        <MousePointer className="w-3.5 h-3.5" />
      </button>

      <button
        type="button"
        onClick={handleZoomIn}
        className="w-7 h-7 rounded-lg bg-slate-900/90 hover:bg-slate-800 text-white font-black text-sm flex items-center justify-center border border-white/20 shadow-md backdrop-blur-md transition-all hover:scale-105 cursor-pointer"
        title="Zoom In"
      >
        +
      </button>
      <button
        type="button"
        onClick={handleZoomOut}
        className="w-7 h-7 rounded-lg bg-slate-900/90 hover:bg-slate-800 text-white font-black text-sm flex items-center justify-center border border-white/20 shadow-md backdrop-blur-md transition-all hover:scale-105 cursor-pointer"
        title="Zoom Out"
      >
        -
      </button>
      <button
        type="button"
        onClick={handleRecenter}
        className="w-7 h-7 rounded-lg bg-slate-900/90 hover:bg-slate-800 text-cyan-400 font-black text-xs flex items-center justify-center border border-white/20 shadow-md backdrop-blur-md transition-all hover:scale-105 cursor-pointer"
        title="Fit Full Route"
      >
        <RotateCcw className="w-3.5 h-3.5" />
      </button>
    </div>
  );
}

interface RealisticRouteMapProps {
  originPort: string;
  destPort: string;
  weatherMapLayer: 'weather' | 'waves' | 'wind' | 'cyclone' | 'current';
  onLayerChange: (layer: 'weather' | 'waves' | 'wind' | 'cyclone' | 'current') => void;
}

export const RealisticRouteMap: React.FC<RealisticRouteMapProps> = ({
  originPort,
  destPort,
  weatherMapLayer,
  onLayerChange,
}) => {
  const [mapStyle, setMapStyle] = useState<'dark' | 'satellite' | 'voyager'>('dark');
  const [cursorFollow, setCursorFollow] = useState(true);
  const [cursorTelemetry, setCursorTelemetry] = useState<{ lat: number; lng: number; region: string } | null>(null);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  // Derive coordinates and clean names
  const originCoords = useMemo(() => getPortCoords(originPort, true), [originPort]);
  const destCoords = useMemo(() => getPortCoords(destPort, false), [destPort]);
  
  const originCountryTag = useMemo(() => {
    if (originPort.includes('Australia')) return '🇦🇺 Australia';
    if (originPort.includes('Indonesia')) return '🇮🇩 Indonesia';
    if (originPort.includes('South Africa')) return '🇿🇦 South Africa';
    if (originPort.includes('Mozambique')) return '🇲🇿 Mozambique';
    if (originPort.includes('USA') || originPort.includes('United States')) return '🇺🇸 USA';
    if (originPort.includes('Russia')) return '🇷🇺 Russia';
    return '🇮🇳 India Coastal';
  }, [originPort]);

  // Compute realistic route coordinates
  const waypoints = useMemo(() => {
    return generateMaritimeRoute(originCoords, destCoords, originPort, destPort);
  }, [originCoords, destCoords, originPort, destPort]);

  // Interpolate vessel position (approx 45% along the voyage)
  const shipPosition = useMemo((): [number, number] => {
    if (waypoints.length < 2) return originCoords;
    const midIdx = Math.floor(waypoints.length / 2);
    const p1 = waypoints[midIdx - 1] || waypoints[0];
    const p2 = waypoints[midIdx] || waypoints[waypoints.length - 1];
    return [
      (p1[0] + p2[0]) / 2,
      (p1[1] + p2[1]) / 2
    ];
  }, [waypoints, originCoords]);

  // Waypoint weather points along route
  const weatherWaypoints = useMemo(() => {
    if (waypoints.length <= 2) return [];
    return [
      {
        id: 'wp-dep',
        name: 'Departure Sector',
        coords: waypoints[1] || waypoints[0],
        temp: 26,
        wind: 14,
        wave: 1.4,
        emoji: '🌤️',
        condition: 'Calm Trade Winds',
      },
      {
        id: 'wp-mid',
        name: 'Oceanic Mid-Route',
        coords: shipPosition,
        temp: 28,
        wind: 22,
        wave: 2.8,
        emoji: '🌊',
        condition: 'Moderate Swell',
      },
      {
        id: 'wp-arr',
        name: 'Approach Outer Anchor',
        coords: waypoints[waypoints.length - 2] || destCoords,
        temp: 29,
        wind: 18,
        wave: 2.1,
        emoji: '⛅',
        condition: 'Favorable Coastal Current',
      },
    ];
  }, [waypoints, shipPosition, destCoords]);

  // Dynamic storm / swell regions based on destination & route
  const cycloneCenter: [number, number] = useMemo(() => {
    return [15.5, 87.2]; // Bay of Bengal depression zone
  }, []);

  const toggleFullscreen = () => {
    setIsFullscreen(prev => !prev);
  };

  return (
    <div
      ref={containerRef}
      className={`relative w-full rounded-xl overflow-hidden bg-[#0A192F] border border-slate-700/60 transition-all duration-300 shadow-lg group ${
        isFullscreen ? 'fixed inset-4 z-[9999] h-[calc(100vh-2rem)] rounded-2xl' : 'h-[330px]'
      }`}
    >
      {/* 1. Leaflet Interactive Marine Map */}
      <MapContainer
        center={originCoords}
        zoom={3}
        zoomControl={false}
        scrollWheelZoom={true}
        doubleClickZoom={true}
        touchZoom={true}
        dragging={true}
        className="h-full w-full z-10"
        style={{ background: '#08172b', cursor: cursorFollow ? 'crosshair' : 'grab' }}
      >
        {/* Clean, Watermark-Free High-Resolution Marine Tile Providers */}
        {mapStyle === 'satellite' ? (
          <TileLayer
            attribution='&copy; <a href="https://www.esri.com/">Esri World Imagery</a>'
            url="https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}"
            maxZoom={14}
          />
        ) : mapStyle === 'voyager' ? (
          <>
            <TileLayer
              attribution='&copy; <a href="https://www.esri.com/">Esri Ocean Basemap</a>'
              url="https://server.arcgisonline.com/ArcGIS/rest/services/Ocean/World_Ocean_Base/MapServer/tile/{z}/{y}/{x}"
              maxZoom={13}
            />
            <TileLayer
              attribution='&copy; <a href="https://www.esri.com/">Esri Ocean Reference</a>'
              url="https://server.arcgisonline.com/ArcGIS/rest/services/Ocean/World_Ocean_Reference/MapServer/tile/{z}/{y}/{x}"
              maxZoom={13}
            />
          </>
        ) : (
          <>
            <TileLayer
              attribution='&copy; <a href="https://www.esri.com/">Esri Dark Canvas</a>'
              url="https://server.arcgisonline.com/ArcGIS/rest/services/Canvas/World_Dark_Gray_Base/MapServer/tile/{z}/{y}/{x}"
              maxZoom={14}
            />
            <TileLayer
              attribution='&copy; <a href="https://www.esri.com/">Esri Dark Reference</a>'
              url="https://server.arcgisonline.com/ArcGIS/rest/services/Canvas/World_Dark_Gray_Reference/MapServer/tile/{z}/{y}/{x}"
              maxZoom={14}
            />
          </>
        )}

        {/* Auto fit bounds when route changes */}
        <MapBoundsUpdater waypoints={waypoints} />

        {/* Interactive Smooth Cursor-Follow Motion Engine */}
        <CursorMotionController
          enabled={cursorFollow}
          onCursorCoordinates={setCursorTelemetry}
        />

        {/* Custom navigation & zoom buttons */}
        <MapControls
          waypoints={waypoints}
          cursorFollow={cursorFollow}
          setCursorFollow={setCursorFollow}
        />

        {/* 2. DYNAMIC WEATHER OVERLAYS ACCORDING TO ACTIVE LAYER */}
        
        {/* Layer A: Cyclone Risk (Bay of Bengal / Indian Ocean Alert Radar) */}
        {weatherMapLayer === 'cyclone' && (
          <>
            <Circle
              center={cycloneCenter}
              radius={450000}
              pathOptions={{
                fillColor: '#EF4444',
                fillOpacity: 0.22,
                color: '#EF4444',
                weight: 2,
                dashArray: '6, 6',
              }}
            >
              <Tooltip direction="top" offset={[0, -10]} permanent>
                <div className="text-[10px] font-black text-rose-600 bg-white/95 px-2 py-1 rounded shadow">
                  ⚠️ Tropical Low-Pressure Warning (Est. 38 kts)
                </div>
              </Tooltip>
            </Circle>
            <Circle
              center={cycloneCenter}
              radius={220000}
              pathOptions={{
                fillColor: '#DC2626',
                fillOpacity: 0.35,
                color: '#B91C1C',
                weight: 2.5,
              }}
            />
          </>
        )}

        {/* Layer B: Wave Height & Swell Hotspots */}
        {weatherMapLayer === 'waves' && (
          <>
            <Circle
              center={[-6.0, 92.0]}
              radius={600000}
              pathOptions={{
                fillColor: '#0284C7',
                fillOpacity: 0.25,
                color: '#38BDF8',
                weight: 1.5,
                dashArray: '4, 4',
              }}
            >
              <Tooltip direction="top" offset={[0, -10]}>
                <div className="text-[10px] font-bold text-sky-600">
                  🌊 Oceanic Swell Zone: 2.8m – 3.4m | Period: 11s
                </div>
              </Tooltip>
            </Circle>
            <Circle
              center={[10.5, 86.0]}
              radius={450000}
              pathOptions={{
                fillColor: '#059669',
                fillOpacity: 0.22,
                color: '#10B981',
                weight: 1.5,
              }}
            >
              <Tooltip direction="top" offset={[0, -10]}>
                <div className="text-[10px] font-bold text-emerald-600">
                  🌊 Moderate Swell: 1.8m – 2.2m (Favorable)
                </div>
              </Tooltip>
            </Circle>
          </>
        )}

        {/* Layer C: Wind Speed Vectors */}
        {weatherMapLayer === 'wind' && (
          <>
            <Circle
              center={[-12.0, 102.0]}
              radius={700000}
              pathOptions={{
                fillColor: '#0EA5E9',
                fillOpacity: 0.20,
                color: '#38BDF8',
                weight: 1.5,
                dashArray: '5, 5',
              }}
            >
              <Tooltip direction="top" offset={[0, -10]}>
                <div className="text-[10px] font-bold text-cyan-600">
                  💨 Trade Wind Field: 20–25 kts (ESE)
                </div>
              </Tooltip>
            </Circle>
          </>
        )}

        {/* Layer D: Sea Currents */}
        {weatherMapLayer === 'current' && (
          <>
            <Circle
              center={[2.0, 88.0]}
              radius={550000}
              pathOptions={{
                fillColor: '#10B981',
                fillOpacity: 0.22,
                color: '#34D399',
                weight: 2,
                dashArray: '8, 4',
              }}
            >
              <Tooltip direction="top" offset={[0, -10]}>
                <div className="text-[10px] font-bold text-emerald-600">
                  🧭 Equatorial Counter Current: +1.8 kts Favorable Drift
                </div>
              </Tooltip>
            </Circle>
          </>
        )}

        {/* Layer E: General Weather / Cloud Isobars */}
        {weatherMapLayer === 'weather' && (
          <>
            <Circle
              center={[-4.0, 100.0]}
              radius={500000}
              pathOptions={{
                fillColor: '#38BDF8',
                fillOpacity: 0.18,
                color: '#0284C7',
                weight: 1.5,
              }}
            />
            <Circle
              center={[14.0, 86.5]}
              radius={400000}
              pathOptions={{
                fillColor: '#10B981',
                fillOpacity: 0.18,
                color: '#059669',
                weight: 1.5,
              }}
            />
          </>
        )}

        {/* 3. VOYAGE ROUTE POLYLINE (GLOWING MARITIME TRACK) */}
        {/* Background Glow */}
        <Polyline
          positions={waypoints}
          pathOptions={{
            color: '#0284C7',
            weight: 6,
            opacity: 0.45,
          }}
        />
        {/* Foreground Dashed Navigation Route */}
        <Polyline
          positions={waypoints}
          pathOptions={{
            color: '#FFFFFF',
            weight: 2.5,
            dashArray: '8, 6',
            opacity: 0.95,
          }}
        />

        {/* 4. ORIGIN & DESTINATION PORT MARKERS */}
        <Marker
          position={originCoords}
          icon={createPortPinIcon(false, originPort, originCountryTag)}
        >
          <Tooltip direction="top" offset={[0, -25]}>
            <div className="text-xs font-bold text-[#111827]">
              {originPort}
              <div className="text-[10px] text-slate-500 font-normal">Loading Terminal • Origin Hub</div>
            </div>
          </Tooltip>
        </Marker>

        <Marker
          position={destCoords}
          icon={createPortPinIcon(true, destPort, 'India')}
        >
          <Tooltip direction="top" offset={[0, -25]}>
            <div className="text-xs font-bold text-[#111827]">
              {destPort}
              <div className="text-[10px] text-slate-500 font-normal">Discharge Terminal • Draft: 14.5m–18.2m</div>
            </div>
          </Tooltip>
        </Marker>

        {/* 5. LIVE AIS VESSEL BEACON */}
        <Marker
          position={shipPosition}
          icon={createShipAisIcon('MV SAIL VOYAGER', 14.2, 305)}
        >
          <Tooltip direction="top" offset={[0, -20]}>
            <div className="text-xs font-bold text-[#111827]">
              🚢 MV SAIL VOYAGER (Capesize / Panamax)
              <div className="text-[10px] text-slate-500 font-normal">
                Speed: 14.2 knots • Heading: 305° NW • ETA: 12 Nov 2026
              </div>
            </div>
          </Tooltip>
        </Marker>

        {/* 6. WEATHER WAYPOINTS ALONG ROUTE */}
        {weatherWaypoints.map((wp) => (
          <Marker
            key={wp.id}
            position={wp.coords}
            icon={createWaypointWeatherIcon(wp.name, wp.temp, wp.wind, wp.wave, wp.emoji)}
          >
            <Tooltip direction="top" offset={[0, -15]}>
              <div className="text-[10px] font-bold text-[#111827]">
                {wp.name}
                <div className="text-slate-500 font-normal">{wp.condition}</div>
                <div className="text-sky-600 font-mono mt-0.5">
                  Temp: {wp.temp}°C | Wind: {wp.wind} kts | Wave: {wp.wave}m
                </div>
              </div>
            </Tooltip>
          </Marker>
        ))}
      </MapContainer>

      {/* TOP LEFT: MAP STYLE SWITCHER & CURSOR FOLLOW INDICATOR */}
      <div className="absolute top-2.5 left-2.5 z-[400] flex items-center gap-1.5 bg-slate-900/90 backdrop-blur-md p-1 rounded-lg border border-white/15 shadow-md">
        <button
          type="button"
          onClick={() => setMapStyle('dark')}
          className={`px-2 py-0.5 rounded text-[9.5px] font-bold transition-all cursor-pointer ${
            mapStyle === 'dark' ? 'bg-[#2563EB] text-white shadow' : 'text-slate-300 hover:text-white'
          }`}
        >
          🗺️ Dark
        </button>
        <button
          type="button"
          onClick={() => setMapStyle('satellite')}
          className={`px-2 py-0.5 rounded text-[9.5px] font-bold transition-all cursor-pointer ${
            mapStyle === 'satellite' ? 'bg-[#2563EB] text-white shadow' : 'text-slate-300 hover:text-white'
          }`}
        >
          🛰️ Satellite
        </button>
        <button
          type="button"
          onClick={() => setMapStyle('voyager')}
          className={`px-2 py-0.5 rounded text-[9.5px] font-bold transition-all cursor-pointer ${
            mapStyle === 'voyager' ? 'bg-[#2563EB] text-white shadow' : 'text-slate-300 hover:text-white'
          }`}
        >
          🧭 Nautical
        </button>
        <button
          type="button"
          onClick={toggleFullscreen}
          className="p-1 text-slate-300 hover:text-white transition-colors ml-0.5"
          title={isFullscreen ? 'Exit Fullscreen' : 'Fullscreen'}
        >
          <Maximize2 className="w-3 h-3" />
        </button>
      </div>

      {/* TOP RIGHT: WEATHER LAYER SWITCHER PILLS */}
      <div className="absolute top-2.5 right-2.5 z-[400] flex flex-col gap-1">
        {[
          { key: 'weather' as const, label: 'Weather', icon: CloudSun },
          { key: 'waves' as const, label: 'Wave Height', icon: Waves },
          { key: 'wind' as const, label: 'Wind Speed', icon: Wind },
          { key: 'cyclone' as const, label: 'Cyclone Risk', icon: AlertTriangle },
          { key: 'current' as const, label: 'Sea Current', icon: Compass },
        ].map((layer) => {
          const IconComp = layer.icon;
          const isActive = weatherMapLayer === layer.key;
          return (
            <button
              key={layer.key}
              type="button"
              onClick={() => onLayerChange(layer.key)}
              className={`px-2.5 py-1 rounded-md text-[9.5px] font-bold transition-all flex items-center gap-1.5 shadow-md backdrop-blur-md cursor-pointer ${
                isActive
                  ? 'bg-[#2563EB] text-white border border-blue-400/50 ring-1 ring-blue-400/40'
                  : 'bg-slate-900/85 hover:bg-slate-800 text-slate-300 border border-white/10'
              }`}
            >
              <IconComp className={`w-3 h-3 ${isActive ? 'text-white' : 'text-slate-400'}`} />
              <span>{layer.label}</span>
            </button>
          );
        })}
      </div>

      {/* DYNAMIC CURSOR TELEMETRY HUD BAR (Shows when mouse hovers over map) */}
      {cursorTelemetry && (
        <div className="absolute top-12 left-2.5 z-[400] flex items-center gap-2 bg-slate-950/85 backdrop-blur-md px-2.5 py-1 rounded-md border border-cyan-500/30 shadow-lg text-[9px] text-cyan-300 font-mono animate-fadeIn pointer-events-none">
          <Crosshair className="w-3 h-3 text-cyan-400 animate-spin-slow" />
          <span>
            {cursorTelemetry.lat > 0 ? `${cursorTelemetry.lat}°N` : `${Math.abs(cursorTelemetry.lat)}°S`},{' '}
            {cursorTelemetry.lng > 0 ? `${cursorTelemetry.lng}°E` : `${Math.abs(cursorTelemetry.lng)}°W`}
          </span>
          <span className="text-slate-500">•</span>
          <span className="text-slate-300 font-sans font-semibold truncate max-w-[200px]">
            {cursorTelemetry.region}
          </span>
        </div>
      )}

      {/* BOTTOM OVERLAY: REALISTIC MARITIME WEATHER LEGEND & AIS LIVE STATUS */}
      <div className="absolute bottom-2 left-2 right-12 z-[400] flex flex-wrap items-center justify-between text-[9px] text-white/90 bg-slate-950/90 backdrop-blur-md px-2.5 py-1.5 rounded-lg border border-white/15 shadow-lg gap-2">
        <div className="flex items-center gap-3">
          {/* Wind Gradient */}
          <div className="flex items-center gap-1.5">
            <span className="text-slate-400 font-medium">Wind:</span>
            <div className="w-10 h-1.5 rounded-full bg-gradient-to-r from-cyan-400 via-amber-400 to-rose-500" />
            <span className="font-mono font-bold text-slate-200">0–50 kt</span>
          </div>

          {/* Wave Height Gradient */}
          <div className="flex items-center gap-1.5">
            <span className="text-slate-400 font-medium">Wave:</span>
            <div className="w-10 h-1.5 rounded-full bg-gradient-to-r from-emerald-400 via-yellow-400 to-rose-600" />
            <span className="font-mono font-bold text-slate-200">0–5m+</span>
          </div>
        </div>

        {/* Live Status Tag */}
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1 text-[8.5px] text-slate-300">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
            <span className="font-bold text-emerald-400">
              {cursorFollow ? '🖱️ Cursor Pan ON' : 'AIS Tracking'}
            </span>
            <span className="text-slate-500">|</span>
            <span className="font-mono text-slate-300">Great-Circle Nav</span>
          </div>
        </div>
      </div>
    </div>
  );
};
