import React, { useMemo, useEffect } from 'react';
import { MapContainer, TileLayer, Polyline, Marker, Tooltip, useMap, Circle } from 'react-leaflet';
import L from 'leaflet';
import { Sparkles, Ship, Anchor, Waves, Wind, RotateCcw } from 'lucide-react';

// Fix Leaflet default icon paths in Vite
delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png',
  iconUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
});

// Port Coordinates Registry
const PORT_COORDS: Record<string, [number, number]> = {
  // Australia
  'Australia (Hay Point / Dalrymple Bay)': [-21.29, 149.30],
  'Australia': [-21.29, 149.30],
  'Hay Point': [-21.29, 149.30],
  'Newcastle': [-32.93, 151.78],
  'Gladstone': [-23.84, 151.25],
  'Port Hedland': [-20.31, 118.58],

  // Indonesia
  'Indonesia (Taboneo Anchorage)': [-3.75, 114.45],
  'Indonesia': [-3.75, 114.45],
  'Taboneo': [-3.75, 114.45],

  // South Africa & Mozambique
  'South Africa (Richards Bay)': [-28.80, 32.03],
  'South Africa': [-28.80, 32.03],
  'Mozambique (Maputo)': [-25.97, 32.57],
  'Mozambique': [-25.97, 32.57],

  // USA & Russia
  'USA': [36.96, -76.32],
  'Russia': [43.12, 131.89],

  // Indian Ports
  'Paradip Port (Odisha)': [20.26, 86.67],
  'Paradip Port': [20.26, 86.67],
  'Paradip': [20.26, 86.67],
  'Dhamra Port (Odisha)': [20.80, 86.97],
  'Dhamra': [20.80, 86.97],
  'Haldia Dock Complex (West Bengal)': [22.02, 88.06],
  'Haldia': [22.02, 88.06],
  'Visakhapatnam Port (Andhra Pradesh)': [17.68, 83.28],
  'Visakhapatnam': [17.68, 83.28],
  'Chennai Port (Tamil Nadu)': [13.08, 80.29],
  'Hazira (Gujarat)': [21.10, 72.63],
  'Hazira': [21.10, 72.63],
  'Mumbai Port Trust (Maharashtra)': [18.95, 72.84],
  'Mumbai': [18.95, 72.84],
  'JNPT': [18.95, 72.95],
  'Mundra': [22.75, 69.70],
  'Kandla': [23.01, 70.22],
};

function getCoords(name: string, isOrigin: boolean): [number, number] {
  if (PORT_COORDS[name]) return PORT_COORDS[name];
  for (const [key, coords] of Object.entries(PORT_COORDS)) {
    if (name.toLowerCase().includes(key.toLowerCase()) || key.toLowerCase().includes(name.toLowerCase())) {
      return coords;
    }
  }
  return isOrigin ? [-21.29, 149.30] : [20.26, 86.67];
}

function computeWaypoints(originCoords: [number, number], destCoords: [number, number]): [number, number][] {
  // Australia to Indian East Coast
  if (originCoords[1] > 140) {
    return [
      originCoords,
      [-10.6, 142.4], // Torres Strait
      [-8.8, 126.5],  // Timor Sea
      [-8.4, 115.8],  // Lombok
      [-2.0, 98.0],   // Indian Ocean
      [6.5, 87.0],    // Bay of Bengal entrance
      [14.0, 86.5],   // Central Bay of Bengal
      destCoords
    ];
  }
  // Indonesia
  if (originCoords[1] > 100 && originCoords[1] <= 140) {
    return [
      originCoords,
      [-5.8, 106.0],
      [-6.0, 104.5],
      [0.0, 95.0],
      [6.0, 93.0],
      [13.5, 88.5],
      destCoords
    ];
  }
  // Default ocean arc
  const midLat = (originCoords[0] + destCoords[0]) / 2 - 2.5;
  const midLon = (originCoords[1] + destCoords[1]) / 2;
  return [originCoords, [midLat, midLon], destCoords];
}

const createMiniPortPin = (isDestination: boolean, name: string) => {
  const cleanName = name.split(' (')[0].replace('Port', '').trim();
  return L.divIcon({
    className: 'mini-port-pin',
    iconSize: [80, 40],
    iconAnchor: [40, 24],
    html: `
      <div style="display: flex; flex-direction: column; align-items: center;">
        <div style="
          width: 22px;
          height: 22px;
          background: ${isDestination ? '#EF4444' : '#F59E0B'};
          border: 2px solid #FFFFFF;
          border-radius: 50%;
          box-shadow: 0 0 0 3px ${isDestination ? 'rgba(239,68,68,0.3)' : 'rgba(245,158,11,0.3)'}, 0 2px 8px rgba(0,0,0,0.5);
          display: flex;
          align-items: center;
          justify-content: center;
          color: #FFFFFF;
          font-size: 11px;
        ">
          ${isDestination ? '⚓' : '📍'}
        </div>
        <div style="
          margin-top: 2px;
          background: rgba(15, 23, 42, 0.9);
          border: 1px solid rgba(255, 255, 255, 0.2);
          padding: 1px 5px;
          border-radius: 4px;
          color: #FFFFFF;
          font-size: 8.5px;
          font-weight: 800;
          font-family: system-ui, sans-serif;
          white-space: nowrap;
        ">
          ${cleanName}
        </div>
      </div>
    `,
  });
};

const createMiniVesselPin = () => {
  return L.divIcon({
    className: 'mini-vessel-pin',
    iconSize: [90, 45],
    iconAnchor: [45, 22],
    html: `
      <div style="display: flex; flex-direction: column; align-items: center; cursor: pointer;">
        <div style="position: relative; width: 26px; height: 26px; display: flex; align-items: center; justify-content: center;">
          <div style="
            position: absolute;
            inset: 0;
            border-radius: 50%;
            background: rgba(56, 189, 248, 0.3);
            animation: ping 2s cubic-bezier(0, 0, 0.2, 1) infinite;
          "></div>
          <div style="
            width: 22px;
            height: 22px;
            background: #0284C7;
            border: 1.5px solid #FFFFFF;
            border-radius: 6px;
            box-shadow: 0 2px 8px rgba(2, 132, 199, 0.6);
            display: flex;
            align-items: center;
            justify-content: center;
            color: #FFFFFF;
            font-size: 12px;
            transform: rotate(-35deg);
          ">
            🚢
          </div>
        </div>
        <div style="
          margin-top: 1px;
          background: rgba(10, 25, 47, 0.95);
          border: 1px solid #38BDF8;
          padding: 1px 5px;
          border-radius: 4px;
          color: #38BDF8;
          font-size: 7.5px;
          font-weight: 900;
          white-space: nowrap;
          font-family: system-ui, sans-serif;
        ">
          14.2 kts • In Transit
        </div>
      </div>
    `,
  });
};

function MiniMapBoundsUpdater({ waypoints }: { waypoints: [number, number][] }) {
  const map = useMap();
  useEffect(() => {
    if (waypoints && waypoints.length >= 2) {
      const bounds = L.latLngBounds(waypoints.map(w => L.latLng(w[0], w[1])));
      map.fitBounds(bounds, { padding: [25, 25], maxZoom: 4, animate: true });
    }
  }, [waypoints, map]);
  return null;
}

interface RealisticMiniRouteWeatherMapProps {
  originPort: string;
  destPort: string;
  originCountry: string;
  cleanDest: string;
  etaDate?: string;
  windSpeedText?: string;
  waveHeightText?: string;
  riskStatusText?: string;
}

export const RealisticMiniRouteWeatherMap: React.FC<RealisticMiniRouteWeatherMapProps> = ({
  originPort,
  destPort,
  originCountry,
  cleanDest,
  etaDate = '12 Nov 2026 (ETA)',
  windSpeedText = 'Wind: 8–12 kts',
  waveHeightText = 'Wave: 0.8m',
  riskStatusText = 'Low Risk',
}) => {
  const originCoords = useMemo(() => getCoords(originPort || originCountry, true), [originPort, originCountry]);
  const destCoords = useMemo(() => getCoords(destPort || cleanDest, false), [destPort, cleanDest]);
  const waypoints = useMemo(() => computeWaypoints(originCoords, destCoords), [originCoords, destCoords]);

  const shipCoords = useMemo((): [number, number] => {
    if (waypoints.length < 2) return originCoords;
    const midIdx = Math.floor(waypoints.length / 2);
    const p1 = waypoints[midIdx - 1] || waypoints[0];
    const p2 = waypoints[midIdx] || waypoints[waypoints.length - 1];
    return [(p1[0] + p2[0]) / 2, (p1[1] + p2[1]) / 2];
  }, [waypoints, originCoords]);

  return (
    <div className="relative rounded-xl overflow-hidden bg-[#0A192F] border border-slate-700 h-52 flex flex-col justify-between shadow-lg group">
      {/* 1. Interactive Real Marine Leaflet Map Container */}
      <MapContainer
        center={originCoords}
        zoom={3}
        zoomControl={false}
        scrollWheelZoom={false}
        doubleClickZoom={false}
        touchZoom={true}
        dragging={true}
        className="absolute inset-0 w-full h-full z-0"
        style={{ background: '#08172b', cursor: 'grab' }}
      >
        {/* Esri Dark Canvas (Watermark-Free) */}
        <TileLayer
          attribution='&copy; <a href="https://www.esri.com/">Esri</a>'
          url="https://server.arcgisonline.com/ArcGIS/rest/services/Canvas/World_Dark_Gray_Base/MapServer/tile/{z}/{y}/{x}"
          maxZoom={12}
        />
        <TileLayer
          attribution='&copy; <a href="https://www.esri.com/">Esri</a>'
          url="https://server.arcgisonline.com/ArcGIS/rest/services/Canvas/World_Dark_Gray_Reference/MapServer/tile/{z}/{y}/{x}"
          maxZoom={12}
        />

        <MiniMapBoundsUpdater waypoints={waypoints} />

        {/* Favorable swell circle */}
        <Circle
          center={[12.0, 86.0]}
          radius={400000}
          pathOptions={{
            fillColor: '#10B981',
            fillOpacity: 0.2,
            color: '#10B981',
            weight: 1,
            dashArray: '4, 4',
          }}
        />

        {/* Great-Circle Glowing Voyage Path */}
        <Polyline
          positions={waypoints}
          pathOptions={{
            color: '#0284C7',
            weight: 5,
            opacity: 0.4,
          }}
        />
        <Polyline
          positions={waypoints}
          pathOptions={{
            color: '#38BDF8',
            weight: 2,
            dashArray: '6, 5',
            opacity: 0.95,
          }}
        />

        {/* Origin Port Marker */}
        <Marker position={originCoords} icon={createMiniPortPin(false, originCountry || originPort)}>
          <Tooltip direction="top" offset={[0, -15]}>
            <span className="text-[10px] font-bold">{originCountry}</span>
          </Tooltip>
        </Marker>

        {/* Destination Port Marker */}
        <Marker position={destCoords} icon={createMiniPortPin(true, cleanDest || destPort)}>
          <Tooltip direction="top" offset={[0, -15]}>
            <span className="text-[10px] font-bold">{cleanDest}</span>
          </Tooltip>
        </Marker>

        {/* Dynamic AIS Vessel Marker */}
        <Marker position={shipCoords} icon={createMiniVesselPin()}>
          <Tooltip direction="top" offset={[0, -15]}>
            <span className="text-[10px] font-bold">MV SAIL BHARAT • 14.2 kts</span>
          </Tooltip>
        </Marker>
      </MapContainer>

      {/* 2. Top floating badge with ETA & Weather Stats */}
      <div className="flex items-center justify-between gap-2 z-10 p-2.5 pointer-events-none">
        <div className="px-2 py-0.5 rounded-md bg-slate-950/85 backdrop-blur-md text-[10px] font-mono font-bold text-[#FCD34D] border border-white/15 shadow">
          {etaDate}
        </div>
        <div className="flex items-center gap-1.5 text-[9.5px]">
          <span className="px-1.5 py-0.5 rounded bg-slate-950/85 backdrop-blur-md text-slate-200 border border-white/10 font-mono">
            {windSpeedText}
          </span>
          <span className="px-1.5 py-0.5 rounded bg-slate-950/85 backdrop-blur-md text-slate-200 border border-white/10 font-mono">
            {waveHeightText}
          </span>
          <span className="px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-bold border border-emerald-500/40 backdrop-blur-md">
            {riskStatusText}
          </span>
        </div>
      </div>

      {/* 3. Sea Conditions bottom gradient bar */}
      <div className="z-10 p-2 bg-slate-950/85 backdrop-blur-md border-t border-white/10 flex items-center justify-between text-[9px] text-slate-300">
        <span className="font-bold flex items-center gap-1">
          <Waves className="w-3 h-3 text-cyan-400" />
          <span>Sea Conditions</span>
        </span>
        <div className="flex items-center gap-1.5">
          <span className="text-emerald-400 font-bold">Calm</span>
          <div className="w-24 h-1.5 rounded-full bg-gradient-to-r from-emerald-400 via-amber-400 to-red-500" />
          <span className="text-red-400 font-bold">Rough</span>
        </div>
      </div>
    </div>
  );
};
