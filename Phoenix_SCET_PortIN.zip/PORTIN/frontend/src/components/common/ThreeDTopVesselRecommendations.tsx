import React, { useState, useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import {
  Ship, Calendar, ArrowRight, RotateCw, Trophy,
  Coins, CheckCircle2, Waves, Compass, Play, Pause
} from 'lucide-react';

interface VesselItem {
  name: string;
  dwt: string;
  rate: number;
  totalCost?: number;
  image: string;
  eta: string;
  compatibility: number;
  badge?: string;
  isBestMatch?: boolean;
}

interface ThreeDTopVesselRecommendationsProps {
  vesselClasses?: VesselItem[];
  onSelectVessel?: (vessel: VesselItem) => void;
  className?: string;
}

export const ThreeDTopVesselRecommendations: React.FC<ThreeDTopVesselRecommendationsProps> = ({
  vesselClasses,
  onSelectVessel,
  className = ''
}) => {
  // Store continuous rotation angle for each vessel
  const [rotations, setRotations] = useState<{ [key: string]: number }>({});
  // Store auto-spin state for each vessel
  const [spinningVessels, setSpinningVessels] = useState<{ [key: string]: boolean }>({});
  const [hoveredCard, setHoveredCard] = useState<string | null>(null);

  // Mouse drag tracking
  const isDraggingRef = useRef<boolean>(false);
  const startXRef = useRef<number>(0);
  const activeVesselRef = useRef<string | null>(null);
  const startAngleRef = useRef<number>(0);

  const defaultVessels: VesselItem[] = [
    {
      name: 'Handysize',
      dwt: '35,000 MT',
      rate: 20.42,
      image: '/assets/vessels/handysize.jpg',
      eta: '12 Nov 2026',
      compatibility: 100,
      badge: 'Best Match',
      isBestMatch: true,
    },
    {
      name: 'Supramax',
      dwt: '58,000 MT',
      rate: 17.46,
      image: '/assets/vessels/supramax.jpg',
      eta: '16 Nov 2026',
      compatibility: 100,
    },
    {
      name: 'Panamax',
      dwt: '76,000 MT',
      rate: 14.80,
      image: '/assets/vessels/panamax.jpg',
      eta: '14 Nov 2026',
      compatibility: 92.1,
    },
    {
      name: 'Capesize',
      dwt: '180,000 MT',
      rate: 12.14,
      image: '/assets/vessels/capesize.jpg',
      eta: '20 Nov 2026',
      compatibility: 38.9,
    },
  ];

  const vessels: VesselItem[] = defaultVessels.map((def, idx) => {
    if (vesselClasses && vesselClasses[idx]) {
      return {
        ...def,
        ...vesselClasses[idx],
        isBestMatch: idx === 0 || vesselClasses[idx].badge?.includes('Best') || def.isBestMatch,
      };
    }
    return def;
  });

  // Smooth continuous animation frame loop for auto-spinning vessels
  useEffect(() => {
    let animFrame: number;
    const updateSpin = () => {
      setRotations(prev => {
        let changed = false;
        const next = { ...prev };
        Object.keys(spinningVessels).forEach(name => {
          if (spinningVessels[name]) {
            changed = true;
            next[name] = ((next[name] || 0) + 1.2) % 360;
          }
        });
        return changed ? next : prev;
      });
      animFrame = requestAnimationFrame(updateSpin);
    };

    animFrame = requestAnimationFrame(updateSpin);
    return () => cancelAnimationFrame(animFrame);
  }, [spinningVessels]);

  // Toggle 360 auto spin
  const toggle360Spin = (e: React.MouseEvent, vesselName: string) => {
    e.stopPropagation();
    setSpinningVessels(prev => {
      const isCurrentlySpinning = !!prev[vesselName];
      if (!isCurrentlySpinning) {
        // If not spinning, start spinning from current angle
        return { ...prev, [vesselName]: true };
      } else {
        // Stop spinning
        return { ...prev, [vesselName]: false };
      }
    });
  };

  // Drag interaction handlers for interactive manual 360 rotating
  const handleMouseDown = (e: React.MouseEvent, vesselName: string) => {
    isDraggingRef.current = true;
    startXRef.current = e.clientX;
    activeVesselRef.current = vesselName;
    startAngleRef.current = rotations[vesselName] || 0;
    // Pause auto-spin during manual drag
    if (spinningVessels[vesselName]) {
      setSpinningVessels(prev => ({ ...prev, [vesselName]: false }));
    }
  };

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (!isDraggingRef.current || !activeVesselRef.current) return;
      const dx = e.clientX - startXRef.current;
      const vName = activeVesselRef.current;
      const newAngle = (startAngleRef.current + dx * 0.9 + 3600) % 360;
      setRotations(prev => ({ ...prev, [vName]: newAngle }));
    };

    const handleMouseUp = () => {
      isDraggingRef.current = false;
      activeVesselRef.current = null;
    };

    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mouseup', handleMouseUp);
    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
    };
  }, []);

  return (
    <div className={`p-5 sm:p-7 rounded-[24px] bg-gradient-to-b from-white via-[#F8FAFC] to-[#F1F5F9] border border-slate-200/90 shadow-[0_12px_40px_rgba(0,0,0,0.04)] space-y-6 ${className}`}>
      {/* HEADER SECTION (Matching Image 2) */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200/80">
        <div className="flex items-start gap-3.5">
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-[#111827] to-[#1E3A8A] flex items-center justify-center text-white shadow-md shadow-blue-950/15 ring-2 ring-blue-100/60 shrink-0 mt-0.5">
            <Ship className="w-5 h-5 text-cyan-300" />
          </div>
          <div>
            <h2 className="text-xl sm:text-2xl font-black text-[#111827] tracking-tight flex items-center gap-1.5">
              <span>Top Vessel</span>
              <span className="text-[#2563EB]">Recommendations</span>
            </h2>
            <p className="text-xs sm:text-[13px] text-slate-500 font-medium mt-0.5">
              Based on forecasted rate, route suitability and vessel availability
            </p>
          </div>
        </div>

        {/* View All Vessels Button */}
        <Link
          to="/vessel-optimizer"
          className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-blue-50/80 hover:bg-blue-100/80 border border-blue-200/70 text-[#2563EB] font-bold text-xs transition-all shadow-xs self-start sm:self-auto group"
        >
          <span>View All Vessels</span>
          <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 transition-transform" />
        </Link>
      </div>

      {/* 4 3D VESSEL CARDS GRID */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-5">
        {vessels.map((vessel) => {
          const rotation = rotations[vessel.name] || 0;
          const isSpinning = !!spinningVessels[vessel.name];
          const isHovered = hoveredCard === vessel.name;

          // Compute perspective lighting and shadow based on angle
          const rad = (rotation * Math.PI) / 180;
          const shadowX = Math.sin(rad) * 16;
          const shadowBlur = 10 + Math.abs(Math.cos(rad)) * 8;
          const scale3D = 0.94 + Math.cos(rad) * 0.08; // subtle perspective depth

          return (
            <div
              key={vessel.name}
              onMouseEnter={() => setHoveredCard(vessel.name)}
              onMouseLeave={() => setHoveredCard(null)}
              className={`group relative rounded-[22px] bg-white border transition-all duration-300 flex flex-col justify-between overflow-hidden cursor-default ${
                isHovered
                  ? 'border-blue-400 shadow-[0_16px_40px_rgba(37,99,235,0.12)] -translate-y-1.5'
                  : 'border-slate-200/80 shadow-[0_4px_20px_rgba(0,0,0,0.03)] hover:border-slate-300'
              }`}
            >
              {/* TOP: 3D VESSEL SHOWCASE ON METALLIC CIRCULAR DAIS */}
              <div
                onMouseDown={(e) => handleMouseDown(e, vessel.name)}
                className="relative w-full h-44 bg-gradient-to-b from-[#EBF3FC] via-[#DEEDFA] to-[#D0E5F7] p-2 flex items-center justify-center overflow-hidden cursor-grab active:cursor-grabbing select-none"
                title="Drag left/right or click 360° to rotate vessel in 3D"
              >
                {/* Background Atmospheric World Map Pattern */}
                <div
                  className="absolute inset-0 opacity-25 pointer-events-none bg-center bg-no-repeat bg-contain"
                  style={{
                    backgroundImage: `radial-gradient(circle at 50% 40%, rgba(37, 99, 235, 0.18) 0%, transparent 70%)`
                  }}
                />

                {/* 3D Stepped Circular Dais (SVG Platform) */}
                <svg
                  viewBox="0 0 240 120"
                  className="absolute bottom-1 w-[88%] h-auto overflow-visible pointer-events-none drop-shadow-md"
                >
                  <defs>
                    <radialGradient id={`dais-glow-${vessel.name}`} cx="50%" cy="50%" r="50%">
                      <stop offset="0%" stopColor="#38BDF8" stopOpacity="0.45" />
                      <stop offset="60%" stopColor="#0284C7" stopOpacity="0.2" />
                      <stop offset="100%" stopColor="#0284C7" stopOpacity="0" />
                    </radialGradient>

                    <linearGradient id={`dais-top-${vessel.name}`} x1="0%" y1="0%" x2="0%" y2="100%">
                      <stop offset="0%" stopColor="#FFFFFF" />
                      <stop offset="50%" stopColor="#E0F2FE" />
                      <stop offset="100%" stopColor="#BAE6FD" />
                    </linearGradient>

                    <linearGradient id={`dais-rim-${vessel.name}`} x1="0%" y1="0%" x2="0%" y2="100%">
                      <stop offset="0%" stopColor="#7DD3FC" />
                      <stop offset="100%" stopColor="#0284C7" />
                    </linearGradient>
                  </defs>

                  {/* Water Reflection / Glow */}
                  <ellipse cx="120" cy="85" rx="105" ry="24" fill={`url(#dais-glow-${vessel.name})`} />

                  {/* Base Ring / Bottom Rim */}
                  <ellipse cx="120" cy="80" rx="98" ry="22" fill="#0369A1" />
                  <path d="M 22,80 A 98,22 0 0,0 218,80 L 218,88 A 98,22 0 0,1 22,88 Z" fill="#075985" />

                  {/* Tier 2 Step Rim */}
                  <ellipse cx="120" cy="74" rx="90" ry="20" fill={`url(#dais-rim-${vessel.name})`} />
                  <path d="M 30,74 A 90,20 0 0,0 210,74 L 210,80 A 90,20 0 0,1 30,80 Z" fill="#0284C7" />

                  {/* Tier 1 Main Platform Top Plate */}
                  <ellipse
                    cx="120"
                    cy="68"
                    rx="82"
                    ry="18"
                    fill={`url(#dais-top-${vessel.name})`}
                    stroke="#FFFFFF"
                    strokeWidth="1.5"
                  />
                  {/* Rotating Compass Tick Marks on Platform */}
                  <ellipse
                    cx="120"
                    cy="68"
                    rx="68"
                    ry="14"
                    fill="none"
                    stroke="#38BDF8"
                    strokeWidth="1"
                    strokeDasharray="4 3"
                    strokeDashoffset={rotation * 0.4}
                    strokeOpacity="0.8"
                  />
                </svg>

                {/* Vessel Photo with Pure 3D Orbit Physics */}
                <div
                  className="relative z-10 w-full h-full flex items-center justify-center transition-transform"
                  style={{
                    perspective: '1000px',
                    transformStyle: 'preserve-3d',
                  }}
                >
                  <img
                    src={vessel.image}
                    alt={vessel.name}
                    draggable={false}
                    className="max-h-[105px] w-auto object-contain transition-all"
                    style={{
                      transform: `rotateY(${rotation}deg) scale(${scale3D * (isHovered ? 1.05 : 1)}) translateY(${isHovered ? '-4px' : '0px'})`,
                      filter: `drop-shadow(${shadowX}px 12px ${shadowBlur}px rgba(15,23,42,0.38)) brightness(${0.9 + Math.cos(rad) * 0.15})`,
                      transformOrigin: 'center center',
                    }}
                  />
                </div>

                {/* BEST MATCH BADGE (Matching Image 2 on Handysize) */}
                {vessel.isBestMatch && (
                  <div className="absolute top-2.5 right-2.5 z-20 flex items-center gap-1 bg-gradient-to-r from-emerald-500 to-teal-600 text-white px-2.5 py-1 rounded-full text-[10.5px] font-black shadow-md shadow-emerald-600/30 border border-emerald-300/40 animate-pulse pointer-events-none">
                    <Trophy className="w-3 h-3 text-yellow-300 shrink-0" />
                    <span>Best Match</span>
                  </div>
                )}

                {/* 360° LIVE ANGLE ORBIT INDICATOR (When Rotating) */}
                {isSpinning && (
                  <div className="absolute top-2.5 left-2.5 z-20 flex items-center gap-1 bg-blue-900/80 text-cyan-300 px-2 py-0.5 rounded-full text-[9.5px] font-mono font-bold backdrop-blur-xs border border-cyan-400/30 shadow-xs pointer-events-none">
                    <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-ping" />
                    <span>{Math.round(rotation)}°</span>
                  </div>
                )}

                {/* 360° VIEW BUTTON PILL (Click to Auto-Spin / Pause) */}
                <button
                  type="button"
                  onClick={(e) => toggle360Spin(e, vessel.name)}
                  className={`absolute bottom-2 z-20 flex items-center gap-1.5 px-3 py-1 rounded-full text-[10px] font-bold shadow-md backdrop-blur-xs transition-all hover:scale-105 active:scale-95 cursor-pointer ${
                    isSpinning
                      ? 'bg-gradient-to-r from-blue-600 to-cyan-600 text-white border border-cyan-300/60 ring-2 ring-cyan-400/40'
                      : 'bg-white/95 hover:bg-white text-[#111827] border border-slate-200/90 shadow-blue-900/10'
                  }`}
                  title={isSpinning ? 'Click to Pause 360° Rotation' : 'Click for continuous 360° Rotation'}
                >
                  <RotateCw className={`w-3 h-3 ${isSpinning ? 'animate-spin text-white' : 'text-[#2563EB]'}`} />
                  <span>{isSpinning ? 'Rotating 360°' : '360° View'}</span>
                </button>
              </div>

              {/* CARD BODY CONTENT */}
              <div className="p-4 space-y-3">
                {/* Name & DWT Line */}
                <div className="flex items-center justify-between">
                  <h3 className="text-base sm:text-lg font-black text-[#111827] tracking-tight">
                    {vessel.name}
                  </h3>
                  <span className="text-xs font-semibold text-slate-500 font-sans">
                    {vessel.dwt}
                  </span>
                </div>

                {/* Price Line (Coins Icon + $Rate + / MT) */}
                <div className="flex items-center gap-2">
                  <div className="w-6 h-6 rounded-lg bg-blue-50 border border-blue-100 flex items-center justify-center text-[#2563EB] shrink-0">
                    <Coins className="w-3.5 h-3.5" />
                  </div>
                  <div className="flex items-baseline gap-1">
                    <span className="text-base sm:text-lg font-black text-[#2563EB] font-sans">
                      ${vessel.rate.toFixed(2)}
                    </span>
                    <span className="text-xs font-semibold text-slate-400">
                      / MT
                    </span>
                  </div>
                </div>

                {/* ETA Line (Calendar Icon + ETA Date) */}
                <div className="flex items-center gap-2 text-xs font-medium text-slate-600">
                  <Calendar className="w-4 h-4 text-slate-400 shrink-0" />
                  <span>
                    ETA: <strong className="text-[#111827] font-bold">{vessel.eta}</strong>
                  </span>
                </div>

                {/* Compatibility Line & Progress Bar */}
                <div className="space-y-1.5 pt-1">
                  <div className="flex items-center justify-between text-xs font-bold">
                    <span className="text-slate-500 font-medium">Compatibility:</span>
                    <span className="text-emerald-600 font-bold">{vessel.compatibility}%</span>
                  </div>
                  <div className="w-full h-2 rounded-full bg-slate-100 overflow-hidden p-0.5 border border-slate-200/50">
                    <div
                      className="h-full rounded-full bg-gradient-to-r from-emerald-500 to-teal-400 transition-all duration-700 shadow-xs"
                      style={{ width: `${vessel.compatibility}%` }}
                    />
                  </div>
                </div>

                {/* View Details Button */}
                <div className="pt-2">
                  <button
                    type="button"
                    onClick={() => onSelectVessel && onSelectVessel(vessel)}
                    className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-[#2563EB] to-[#1D4ED8] hover:from-[#1D4ED8] hover:to-[#1E40AF] text-white font-bold text-xs transition-all shadow-md shadow-blue-600/20 hover:shadow-lg hover:shadow-blue-600/30 flex items-center justify-center gap-2 cursor-pointer group"
                  >
                    <span>View Details</span>
                    <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* FOOTER MARITIME BANNER */}
      <div className="pt-3 border-t border-slate-200/80 flex items-center justify-center gap-3 text-[10px] font-bold tracking-widest text-slate-400 uppercase">
        <div className="w-16 sm:w-28 h-px bg-slate-200" />
        <div className="flex items-center gap-2 text-slate-500">
          <Ship className="w-3.5 h-3.5 text-[#2563EB]" />
          <span>Smarter Shipping Decisions for a Brighter Tomorrow</span>
        </div>
        <div className="w-16 sm:w-28 h-px bg-slate-200" />
      </div>
    </div>
  );
};
