import React from 'react';
import { DataProvenanceBadge } from './DataProvenanceBadge';

interface Props {
  title: string;
  value: string | number;
  subtext?: string;
  trend?: 'up' | 'down' | 'neutral';
  trendText?: string;
  icon: React.ReactNode;
  sourceType?: string;
  sourceName?: string;
  badgeText?: string;
  badgeVariant?: 'success' | 'warning' | 'danger' | 'info';
}

export const KPICard: React.FC<Props> = ({
  title,
  value,
  subtext,
  trend,
  trendText,
  icon,
  sourceType = 'OFFICIAL STATIC',
  sourceName,
  badgeText,
  badgeVariant = 'info',
}) => {
  let badgeClasses = 'bg-[#F3F4F6] text-[#111827] border-[#E5E7EB]';
  if (badgeVariant === 'success') badgeClasses = 'bg-[#DCFCE7] text-[#15803D] border-[#BBF7D0]';
  if (badgeVariant === 'warning') badgeClasses = 'bg-[#F3F4F6] text-[#4B5563] border-[#E5E7EB]';
  if (badgeVariant === 'danger') badgeClasses = 'bg-[#FEE2E2] text-[#B91C1C] border-[#FECACA]';

  return (
    <div className="bg-[#FFFFFF] border border-[#E5E7EB] rounded-lg p-4 shadow-xs hover:border-[#D1D5DB] transition-all relative">
      <div className="flex items-center justify-between gap-2 mb-2">
        <span className="text-[11px] font-bold text-[#6B7280] uppercase tracking-wider">{title}</span>
        <div className="flex items-center gap-1.5">
          {badgeText && (
            <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded border ${badgeClasses}`}>
              {badgeText}
            </span>
          )}
          <div className="p-1.5 rounded-md bg-[#F8F9FA] text-[#4B5563] border border-[#E5E7EB]">
            {icon}
          </div>
        </div>
      </div>

      <div className="text-xl sm:text-2xl font-bold text-[#111827] tracking-tight my-1">
        {value}
      </div>

      <div className="flex items-center justify-between mt-2 pt-2 border-t border-[#E5E7EB]">
        <div className="text-[11px] text-[#6B7280] flex items-center gap-1">
          {trend && (
            <span className={trend === 'up' ? 'text-[#DC2626] font-bold' : trend === 'down' ? 'text-[#16A34A] font-bold' : 'text-[#6B7280]'}>
              {trend === 'up' ? '▲' : trend === 'down' ? '▼' : '●'} {trendText}
            </span>
          )}
          {subtext && !trend && <span>{subtext}</span>}
        </div>
        <DataProvenanceBadge sourceType={sourceType} sourceName={sourceName} />
      </div>
    </div>
  );
};
