import React, { useState } from 'react';
import { Ship, TrendingUp, Compass, ArrowLeftRight, Gauge, Layers, Info } from 'lucide-react';

interface VesselData {
  name: string;
  dwt: string;
  rate: number;
  totalCost: number;
  image: string;
  dwtRange: string;
  lengthRange: string;
  speedRange: string;
  number: string;
}

interface ThreeDVesselCostComparisonProps {
  vesselClasses?: Array<{
    name: string;
    dwt: string;
    rate: number;
    totalCost: number;
    image: string;
  }>;
  cargoVolume?: number;
}

export const ThreeDVesselCostComparison: React.FC<ThreeDVesselCostComparisonProps> = ({
  vesselClasses,
  cargoVolume = 120000
}) => {
  const [hoveredIdx, setHoveredIdx] = useState<number | null>(null);

  // Default fallback data accurately matching Image 2
  const defaultVessels: VesselData[] = [
    {
      number: '01',
      name: 'Handysize',
      dwt: '35,000 MT',
      rate: 20.42,
      totalCost: 2450400,
      image: '/assets/vessels/handysize.jpg',
      dwtRange: '28–40K',
      lengthRange: '180–200 m',
      speedRange: '12–14 kt',
    },
    {
      number: '02',
      name: 'Supramax',
      dwt: '58,000 MT',
      rate: 17.46,
      totalCost: 2095200,
      image: '/assets/vessels/supramax.jpg',
      dwtRange: '40–60K',
      lengthRange: '200–230 m',
      speedRange: '12–14 kt',
    },
    {
      number: '03',
      name: 'Panamax',
      dwt: '76,000 MT',
      rate: 14.80,
      totalCost: 1776000,
      image: '/assets/vessels/panamax.jpg',
      dwtRange: '60–85K',
      lengthRange: '225–250 m',
      speedRange: '13–15 kt',
    },
    {
      number: '04',
      name: 'Capesize',
      dwt: '180,000 MT',
      rate: 12.14,
      totalCost: 1456800,
      image: '/assets/vessels/capesize.jpg',
      dwtRange: '100–200K',
      lengthRange: '260–330 m',
      speedRange: '14–16 kt',
    },
  ];

  // Merge provided props if available while preserving the rich metadata
  const vessels: VesselData[] = defaultVessels.map((def, idx) => {
    if (vesselClasses && vesselClasses[idx]) {
      return {
        ...def,
        rate: vesselClasses[idx].rate,
        totalCost: vesselClasses[idx].totalCost || Math.round(cargoVolume * vesselClasses[idx].rate),
        image: vesselClasses[idx].image || def.image,
      };
    }
    return def;
  });

  // Color themes for the 4 3D isometric blocks (matching Image 2)
  const blockThemes = [
    {
      // 01 Handysize: Deep Midnight / Dark Navy
      top: '#1E3A8A',
      left: '#111827',
      right: '#0B1A2C',
      glow: 'rgba(15, 39, 71, 0.4)',
      height: 98,
    },
    {
      // 02 Supramax: Vibrant Royal Blue
      top: '#3B82F6',
      left: '#2563EB',
      right: '#1D4ED8',
      glow: 'rgba(37, 99, 235, 0.4)',
      height: 78,
    },
    {
      // 03 Panamax: Bright Dodger Blue
      top: '#60A5FA',
      left: '#3B82F6',
      right: '#2563EB',
      glow: 'rgba(59, 130, 246, 0.4)',
      height: 58,
    },
    {
      // 04 Capesize: Sky / Ice Blue
      top: '#93C5FD',
      left: '#60A5FA',
      right: '#3B82F6',
      glow: 'rgba(96, 165, 250, 0.4)',
      height: 38,
    },
  ];

  return (
    <div className="p-5 sm:p-7 rounded-[24px] bg-gradient-to-b from-white via-[#F8FAFC] to-[#F1F5F9] border border-slate-200/90 shadow-[0_12px_40px_rgba(0,0,0,0.04)] space-y-6 transition-all duration-300">
      {/* HEADER SECTION (Matching Image 2) */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-200/80">
        <div className="flex items-start gap-3.5">
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-[#111827] to-[#1E3A8A] flex items-center justify-center text-white shadow-md shadow-blue-950/15 ring-2 ring-blue-100/60 shrink-0 mt-0.5">
            <Ship className="w-5 h-5 text-cyan-300" />
          </div>
          <div>
            <h2 className="text-xl sm:text-2xl font-black text-[#111827] tracking-tight flex items-center gap-1.5">
              <span>Vessel Cost</span>
              <span className="text-[#2563EB]">Comparison</span>
            </h2>
            <p className="text-xs sm:text-[13px] text-slate-500 font-medium mt-0.5">
              Compare estimated freight cost across different vessel classes for your route and cargo.
            </p>
          </div>
        </div>

        {/* Right Info Badge (Matching Image 2) */}
        <div className="flex items-center gap-3 bg-blue-50/70 border border-blue-200/60 px-4 py-2.5 rounded-2xl shadow-xs self-start md:self-auto backdrop-blur-xs">
          <div className="w-8 h-8 rounded-xl bg-blue-600/10 flex items-center justify-center text-[#2563EB] shrink-0">
            <TrendingUp className="w-4 h-4 text-[#2563EB]" />
          </div>
          <div>
            <div className="text-xs font-black text-[#111827]">
              Bigger vessels. Lower cost per ton.
            </div>
            <div className="text-[11px] text-slate-500 font-semibold">
              Optimize your shipping strategy.
            </div>
          </div>
        </div>
      </div>

      {/* 4 3D VESSEL CARDS GRID (Matching Image 2) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-5">
        {vessels.map((vessel, idx) => {
          const theme = blockThemes[idx] || blockThemes[0];
          const isHovered = hoveredIdx === idx;
          const barHeight = theme.height;

          return (
            <div
              key={vessel.name}
              onMouseEnter={() => setHoveredIdx(idx)}
              onMouseLeave={() => setHoveredIdx(null)}
              className={`group relative rounded-[22px] bg-white border transition-all duration-300 flex flex-col justify-between overflow-hidden cursor-default ${
                isHovered
                  ? 'border-blue-400 shadow-[0_16px_40px_rgba(37,99,235,0.12)] -translate-y-1.5'
                  : 'border-slate-200/80 shadow-[0_4px_20px_rgba(0,0,0,0.03)] hover:border-slate-300'
              }`}
            >
              {/* TOP SECTION: Price & Number Badge */}
              <div className="p-4 pb-0 flex items-start justify-between">
                <div>
                  <div className="text-2xl font-black text-[#111827] font-sans tracking-tight">
                    ${vessel.rate.toFixed(2)}
                  </div>
                  <div className="text-[11px] font-semibold text-slate-400 mt-0.5">
                    / MT
                  </div>
                </div>

                {/* Number Badge (01, 02, 03, 04) */}
                <div className="w-7 h-7 rounded-full bg-blue-50/90 border border-blue-100 flex items-center justify-center text-[11px] font-black text-[#2563EB] shadow-xs">
                  {vessel.number}
                </div>
              </div>

              {/* 3D ISOMETRIC BAR & FLOATING PEDESTAL (Exact 3D render matching Image 2) */}
              <div className="relative h-44 w-full flex items-center justify-center px-4 overflow-visible">
                <svg
                  viewBox="0 0 200 160"
                  className="w-full h-full max-w-[190px] overflow-visible drop-shadow-sm transition-transform duration-300"
                  style={{
                    transform: isHovered ? 'scale(1.05) translateY(-4px)' : 'scale(1)',
                  }}
                >
                  <defs>
                    {/* Pedestal Drop Shadow */}
                    <radialGradient id={`pedestal-shadow-${idx}`} cx="50%" cy="50%" r="50%">
                      <stop offset="0%" stopColor="#64748B" stopOpacity="0.28" />
                      <stop offset="100%" stopColor="#64748B" stopOpacity="0" />
                    </radialGradient>

                    {/* Pedestal Top Gradient */}
                    <linearGradient id={`ped-top-${idx}`} x1="0%" y1="0%" x2="100%" y2="100%">
                      <stop offset="0%" stopColor="#FFFFFF" />
                      <stop offset="100%" stopColor="#EEF2F6" />
                    </linearGradient>

                    {/* 3D Block Top Gloss */}
                    <linearGradient id={`block-top-${idx}`} x1="0%" y1="0%" x2="100%" y2="100%">
                      <stop offset="0%" stopColor={theme.top} stopOpacity="1" />
                      <stop offset="100%" stopColor={theme.left} stopOpacity="0.85" />
                    </linearGradient>

                    {/* 3D Block Left Face */}
                    <linearGradient id={`block-left-${idx}`} x1="0%" y1="0%" x2="0%" y2="100%">
                      <stop offset="0%" stopColor={theme.left} />
                      <stop offset="100%" stopColor={theme.right} />
                    </linearGradient>
                  </defs>

                  {/* 1. Ambient Glow under block */}
                  <ellipse
                    cx="100"
                    cy="142"
                    rx="68"
                    ry="16"
                    fill={`url(#pedestal-shadow-${idx})`}
                  />

                  {/* 2. Floating 3D White Pedestal (Hexagonal / Beveled Platform) */}
                  {/* Pedestal Bottom Rim / Shadow */}
                  <polygon
                    points="38,133 100,147 162,133 162,137 100,151 38,137"
                    fill="#CBD5E1"
                  />
                  {/* Pedestal Left Edge */}
                  <polygon
                    points="38,133 100,147 100,151 38,137"
                    fill="#E2E8F0"
                  />
                  {/* Pedestal Right Edge */}
                  <polygon
                    points="100,147 162,133 162,137 100,151"
                    fill="#CBD5E1"
                  />
                  {/* Pedestal Top Face Plate */}
                  <polygon
                    points="100,121 162,133 100,147 38,133"
                    fill={`url(#ped-top-${idx})`}
                    stroke="#FFFFFF"
                    strokeWidth="1.2"
                  />

                  {/* Pedestal Inner Glow Bevel */}
                  <polygon
                    points="100,124 154,134 100,145 46,134"
                    fill="none"
                    stroke="#F1F5F9"
                    strokeWidth="1"
                  />

                  {/* 3. 3D Isometric Pillar Block (Height proportional to cost) */}
                  {(() => {
                    const cx = 100;
                    const baseY = 134; // Base resting on the pedestal
                    const h = barHeight;
                    const w = 28; // half width
                    const d = 14; // isometric depth

                    // Pillar Base Points
                    const bTop = baseY - d;
                    const bBottom = baseY + d;
                    const bLeft = cx - w;
                    const bRight = cx + w;

                    // Pillar Top Points (offset upwards by height h)
                    const tCenter = baseY - h;
                    const tTop = tCenter - d;
                    const tBottom = tCenter + d;
                    const tLeft = cx - w;
                    const tRight = cx + w;

                    return (
                      <g className="transition-all duration-500 ease-out">
                        {/* Shadow of pillar on pedestal */}
                        <ellipse
                          cx={cx}
                          cy={baseY}
                          rx={w + 2}
                          ry={d + 1}
                          fill="rgba(15, 23, 42, 0.18)"
                        />

                        {/* Pillar Left Face */}
                        <polygon
                          points={`${tLeft},${tCenter} ${cx},${tBottom} ${cx},${baseY} ${bLeft},${baseY - d / 2}`}
                          fill={`url(#block-left-${idx})`}
                        />

                        {/* Pillar Right Face (Shadow Face) */}
                        <polygon
                          points={`${cx},${tBottom} ${tRight},${tCenter} ${bRight},${baseY - d / 2} ${cx},${baseY}`}
                          fill={theme.right}
                        />

                        {/* Pillar Top Face (Highlight Face) */}
                        <polygon
                          points={`${cx},${tTop} ${tRight},${tCenter} ${cx},${tBottom} ${tLeft},${tCenter}`}
                          fill={`url(#block-top-${idx})`}
                          stroke="#FFFFFF"
                          strokeWidth="0.8"
                          strokeOpacity="0.4"
                        />

                        {/* Specular Highlight Line on Front Center Ridge */}
                        <line
                          x1={cx}
                          y1={tBottom}
                          x2={cx}
                          y2={baseY}
                          stroke="#FFFFFF"
                          strokeWidth="0.9"
                          strokeOpacity="0.35"
                        />
                      </g>
                    );
                  })()}
                </svg>
              </div>

              {/* VESSEL REAL PHOTO (Matching Image 2) */}
              <div className="px-4">
                <div className="relative w-full h-24 sm:h-28 rounded-xl overflow-hidden border border-slate-200/90 bg-slate-100 shadow-inner group-hover:shadow-md transition-all">
                  <img
                    src={vessel.image}
                    alt={vessel.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  {/* Subtle vignette/water reflection gradient */}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/20 via-transparent to-transparent pointer-events-none" />
                </div>
              </div>

              {/* VESSEL NAME */}
              <div className="pt-3 pb-2 text-center">
                <h3 className="text-base sm:text-lg font-black text-[#111827] tracking-tight">
                  {vessel.name}
                </h3>
              </div>

              {/* 3 SPEC BADGES ROW (DWT, Length, Speed - Matching Image 2) */}
              <div className="px-3 pb-3">
                <div className="grid grid-cols-3 gap-1.5 pt-2 border-t border-slate-100 text-center">
                  {/* DWT */}
                  <div className="flex flex-col items-center justify-center p-1 rounded-lg bg-slate-50 border border-slate-100/80">
                    <div className="flex items-center gap-1 text-[10px] font-bold text-[#111827]">
                      <Layers className="w-2.5 h-2.5 text-blue-600 shrink-0" />
                      <span>{vessel.dwtRange}</span>
                    </div>
                    <span className="text-[8px] font-semibold text-slate-400 uppercase tracking-tight">
                      DWT
                    </span>
                  </div>

                  {/* Length */}
                  <div className="flex flex-col items-center justify-center p-1 rounded-lg bg-slate-50 border border-slate-100/80">
                    <div className="flex items-center gap-1 text-[10px] font-bold text-[#111827]">
                      <ArrowLeftRight className="w-2.5 h-2.5 text-blue-600 shrink-0" />
                      <span>{vessel.lengthRange}</span>
                    </div>
                    <span className="text-[8px] font-semibold text-slate-400 uppercase tracking-tight">
                      Length
                    </span>
                  </div>

                  {/* Speed */}
                  <div className="flex flex-col items-center justify-center p-1 rounded-lg bg-slate-50 border border-slate-100/80">
                    <div className="flex items-center gap-1 text-[10px] font-bold text-[#111827]">
                      <Gauge className="w-2.5 h-2.5 text-blue-600 shrink-0" />
                      <span>{vessel.speedRange}</span>
                    </div>
                    <span className="text-[8px] font-semibold text-slate-400 uppercase tracking-tight">
                      Speed
                    </span>
                  </div>
                </div>
              </div>

              {/* BOTTOM TOTAL COST STRIP (Matching Image 2) */}
              <div className="p-3 bg-gradient-to-r from-slate-50 to-blue-50/40 border-t border-slate-100 flex items-center justify-between">
                <span className="text-[11px] font-semibold text-slate-500">
                  Total Cost:
                </span>
                <span className="text-sm sm:text-base font-black text-[#2563EB] font-sans tracking-tight">
                  ${vessel.totalCost.toLocaleString()}
                </span>
              </div>
            </div>
          );
        })}
      </div>

      {/* FOOTER MARITIME BANNER (Exact text & layout from Image 2) */}
      <div className="pt-3 border-t border-slate-200/80 flex flex-col sm:flex-row items-center justify-between gap-2 text-[10px] font-bold tracking-widest text-slate-400 uppercase">
        <div className="flex items-center gap-2">
          <div className="w-12 h-px bg-slate-200" />
          <Compass className="w-3.5 h-3.5 text-[#2563EB]" />
          <span>Different Vessels. A Brighter Supply Chain.</span>
          <div className="w-12 h-px bg-slate-200" />
        </div>

        <div className="flex items-center gap-2">
          <div className="w-8 h-px bg-slate-200" />
          <span className="text-slate-500 font-extrabold">Move More. Go Further.</span>
        </div>
      </div>
    </div>
  );
};
