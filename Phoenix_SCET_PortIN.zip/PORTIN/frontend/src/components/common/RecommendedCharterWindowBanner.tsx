import React from 'react';
import {
  Calendar, CheckCircle2, TrendingDown, CloudSun, Sparkles,
  ShieldCheck, ArrowRight, DollarSign, Waves, Wind, Activity, Zap
} from 'lucide-react';

interface RecommendedCharterWindowBannerProps {
  day30Prediction?: number;
  day90Prediction?: number;
  bestCharterDate?: string;
  optimalBookingWindow?: string;
  explanation?: string;
  potentialSavings?: number;
  savingsPct?: string | number;
  onBookNow?: () => void;
}

export const RecommendedCharterWindowBanner: React.FC<RecommendedCharterWindowBannerProps> = ({
  day30Prediction = 14.57,
  day90Prediction = 13.73,
  bestCharterDate = '12 Nov 2026',
  optimalBookingWindow = '12–24 Nov 2026',
  explanation = 'Lowest forecasted forward index, calm sea window (<1.4m), high coastal fleet liquidity.',
  potentialSavings = 579600,
  savingsPct = '40.5',
  onBookNow
}) => {
  return (
    <div className="relative overflow-hidden rounded-[22px] bg-gradient-to-b from-white via-[#F8FAFC] to-[#F1F5F9] border border-slate-200/90 shadow-[0_10px_35px_rgba(0,0,0,0.04)] p-4 sm:p-6 space-y-4 transition-all">
      {/* Ambient background glow */}
      <div className="absolute top-0 right-0 w-80 h-32 bg-gradient-to-l from-blue-500/5 to-transparent rounded-full blur-2xl pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-80 h-32 bg-gradient-to-r from-emerald-500/5 to-transparent rounded-full blur-2xl pointer-events-none" />

      {/* HEADER ROW */}
      <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-3 pb-3.5 border-b border-slate-200/80">
        <div className="flex items-start gap-3">
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-[#111827] to-[#1E3A8A] flex items-center justify-center text-white shadow-md shadow-blue-950/15 ring-2 ring-blue-100/60 shrink-0">
            <Calendar className="w-5 h-5 text-cyan-300" />
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h2 className="text-base sm:text-lg font-black text-[#111827] tracking-tight">
                Recommended Charter Window
              </h2>
              <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-black bg-emerald-100/80 text-emerald-800 border border-emerald-300/60 shadow-xs">
                <Sparkles className="w-3 h-3 text-emerald-600 animate-pulse" />
                <span>AI OPTIMAL FIXING SIGNAL</span>
              </span>
            </div>
            <p className="text-xs text-slate-500 font-medium mt-0.5">
              Based on forward freight FFA curve, vessel open capacity and MetOcean routing intelligence.
            </p>
          </div>
        </div>

        {/* Action / Quick Window pill */}
        <div className="flex items-center gap-2 self-start md:self-auto">
          <div className="hidden lg:flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-50/80 border border-emerald-200/80 text-emerald-800 text-xs font-bold shadow-xs">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
            <span>Optimal Window: <strong>{optimalBookingWindow}</strong></span>
          </div>
          {onBookNow && (
            <button
              type="button"
              onClick={onBookNow}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-[#111827] hover:bg-[#1A365D] text-white text-xs font-bold shadow-xs hover:shadow-md transition-all cursor-pointer"
            >
              <span>Lock Rate</span>
              <ArrowRight className="w-3.5 h-3.5 text-cyan-300" />
            </button>
          )}
        </div>
      </div>

      {/* 4 MODERN TELEMETRY CARDS GRID */}
      <div className="relative z-10 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5 sm:gap-4">
        
        {/* CARD 1: BEST CHARTER DATE (HERO EMERALD CARD) */}
        <div className="group relative p-4 rounded-2xl bg-gradient-to-br from-[#ECFDF5] via-[#E6F9F0] to-[#D1FAE5] border border-emerald-300/90 shadow-sm hover:shadow-md hover:border-emerald-400 transition-all flex flex-col justify-between overflow-hidden">
          {/* Subtle decorative glow ring */}
          <div className="absolute -top-10 -right-10 w-24 h-24 bg-emerald-400/20 rounded-full blur-xl pointer-events-none" />

          <div>
            <div className="flex items-center justify-between gap-2 mb-1.5">
              <div className="flex items-center gap-1.5 text-xs font-black text-emerald-900">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>Best Charter Date</span>
              </div>
              <span className="px-2 py-0.5 rounded-full text-[9px] font-black uppercase tracking-wider bg-emerald-600 text-white shadow-xs">
                Recommended
              </span>
            </div>

            <div className="text-2xl sm:text-[26px] font-black text-[#111827] tracking-tight font-mono mt-1">
              {bestCharterDate}
            </div>

            <div className="flex items-center gap-1.5 mt-1.5 text-[10.5px] font-bold text-emerald-800">
              <span className="bg-white/80 px-2 py-0.5 rounded-md border border-emerald-200/60 font-mono">
                ${day90Prediction.toFixed(2)} / MT
              </span>
              <span>Bottom Rate</span>
            </div>
          </div>

          <div className="pt-2.5 mt-2.5 border-t border-emerald-200/80 text-[10.5px] text-emerald-900/90 font-medium leading-relaxed">
            <span className="font-bold text-emerald-950">Driver: </span>
            {explanation}
          </div>
        </div>

        {/* CARD 2: EXPECTED RATE (T + 30 DAYS) */}
        <div className="group relative p-4 rounded-2xl bg-white border border-slate-200/90 hover:border-blue-300 hover:shadow-md transition-all flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between text-[10.5px] font-bold uppercase tracking-wider text-slate-500 mb-1">
              <span>Expected Rate (T + 30D)</span>
              <span className="px-1.5 py-0.2 rounded text-[9px] font-mono bg-blue-50 text-blue-700 font-bold border border-blue-100">
                90% P50
              </span>
            </div>

            <div className="text-2xl sm:text-[26px] font-black text-[#111827] font-mono tracking-tight mt-1">
              ${day30Prediction.toFixed(2)}{' '}
              <span className="text-xs font-bold text-slate-400 font-sans">/ MT</span>
            </div>

            <div className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-600 bg-emerald-50/80 px-2 py-0.5 rounded-md border border-emerald-200/60 mt-2">
              <TrendingDown className="w-3.5 h-3.5" />
              <span>▼ -3.2% vs current</span>
            </div>
          </div>

          <div className="pt-2.5 mt-2.5 border-t border-slate-100 text-[10.5px] text-slate-500 font-medium flex items-center justify-between">
            <span>Forward Delta</span>
            <strong className="text-slate-700 font-mono">-$0.48 / MT</strong>
          </div>
        </div>

        {/* CARD 3: EXPECTED RATE (T + 90 DAYS) */}
        <div className="group relative p-4 rounded-2xl bg-white border border-slate-200/90 hover:border-blue-300 hover:shadow-md transition-all flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between text-[10.5px] font-bold uppercase tracking-wider text-slate-500 mb-1">
              <span>Expected Rate (T + 90D)</span>
              <span className="px-1.5 py-0.2 rounded text-[9px] font-mono bg-emerald-50 text-emerald-700 font-bold border border-emerald-100">
                Cycle Low
              </span>
            </div>

            <div className="text-2xl sm:text-[26px] font-black text-[#111827] font-mono tracking-tight mt-1">
              ${day90Prediction.toFixed(2)}{' '}
              <span className="text-xs font-bold text-slate-400 font-sans">/ MT</span>
            </div>

            <div className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-600 bg-emerald-50/80 px-2 py-0.5 rounded-md border border-emerald-200/60 mt-2">
              <TrendingDown className="w-3.5 h-3.5" />
              <span>▼ -8.5% vs current</span>
            </div>
          </div>

          <div className="pt-2.5 mt-2.5 border-t border-slate-100 text-[10.5px] text-slate-500 font-medium flex items-center justify-between">
            <span>Projected Savings</span>
            <strong className="text-emerald-700 font-mono font-black">-$1.27 / MT</strong>
          </div>
        </div>

        {/* CARD 4: WEATHER & METOCEAN SUITABILITY */}
        <div className="group relative p-4 rounded-2xl bg-white border border-slate-200/90 hover:border-slate-300 hover:shadow-md transition-all flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between text-[10.5px] font-bold uppercase tracking-wider text-slate-500 mb-1">
              <div className="flex items-center gap-1 text-slate-600">
                <CloudSun className="w-3.5 h-3.5 text-amber-500" />
                <span>Weather Suitability</span>
              </div>
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
            </div>

            <div className="flex items-baseline gap-2 mt-1">
              <div className="text-2xl sm:text-[26px] font-black text-[#111827] tracking-tight">
                Good
              </div>
              <span className="text-xs font-bold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-100">
                Calm Seas
              </span>
            </div>

            <div className="flex items-center gap-2 mt-2 text-[10.5px] text-slate-600 font-medium">
              <span className="flex items-center gap-1">
                <Waves className="w-3 h-3 text-cyan-600" /> Swell: 0.5–1.4m
              </span>
              <span>•</span>
              <span className="flex items-center gap-1">
                <Wind className="w-3 h-3 text-blue-500" /> 11 kts NE
              </span>
            </div>
          </div>

          <div className="pt-2.5 mt-2.5 border-t border-slate-100 text-[10.5px] text-slate-500 font-medium flex items-center justify-between">
            <span>Monsoon Risk</span>
            <strong className="text-emerald-600 font-bold">Zero Hazards (Calm)</strong>
          </div>
        </div>

      </div>
    </div>
  );
};
