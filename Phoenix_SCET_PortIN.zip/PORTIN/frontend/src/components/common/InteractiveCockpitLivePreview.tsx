import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import {
  TrendingUp, TrendingDown, Ship, Compass, MapPin, BarChart3,
  Sparkles, Layers, RefreshCw, ChevronRight, Activity, Shield,
  ArrowRight, CheckCircle2, AlertTriangle, Play, Zap, Info,
  Sliders, Calendar, Anchor, Database, Maximize2, ExternalLink, FileText
} from 'lucide-react';
import {
  ResponsiveContainer,
  ComposedChart,
  Area,
  Line,
  XAxis,
  YAxis,
  Tooltip
} from 'recharts';
import {
  Realistic3DBdiChartIcon,
  Realistic3DShipIcon,
  Realistic3DFuelBarrelIcon,
  Realistic3DCurrencyCoinsIcon,
  Realistic3DAnchorIcon,
  Realistic3DAIBrainIcon
} from './Realistic3DIcons';

interface TradeLaneData {
  id: string;
  name: string;
  origin: string;
  dest: string;
  cargo: string;
  currentRate: number;
  predictedRate: number;
  deltaPercent: string;
  vessel: string;
  vesselCapacity: string;
  signal: 'MONITOR' | 'LOCK COA' | 'BUY SPOT';
  signalWindow: string;
  riskScore: number;
  riskLevel: string;
  durationDays: number;
  distanceNM: number;
  forecast7d: { date: string; expected: number; lower: number; upper: number }[];
  forecast30d: { date: string; expected: number; lower: number; upper: number }[];
  forecast90d: { date: string; expected: number; lower: number; upper: number }[];
  marketInsight: string;
}

const TRADE_LANES: Record<string, TradeLaneData> = {
  'gladstone-paradip': {
    id: 'gladstone-paradip',
    name: 'Gladstone (Australia) → Paradip CQ-1 (East Coast India)',
    origin: 'Gladstone, Australia',
    dest: 'Paradip CQ-1, India',
    cargo: '70,000 MT Coking Coal',
    currentRate: 14.80,
    predictedRate: 14.37,
    deltaPercent: '-2.9%',
    vessel: 'Panamax',
    vesselCapacity: '70,000 MT • 14.5m Draft',
    signal: 'MONITOR',
    signalWindow: 'Next 14-21 Days',
    riskScore: 24.5,
    riskLevel: 'Low Risk',
    durationDays: 14.5,
    distanceNM: 5200,
    forecast7d: [
      { date: '21 Sep', expected: 14.80, lower: 14.60, upper: 15.00 },
      { date: '23 Sep', expected: 14.88, lower: 14.55, upper: 15.20 },
      { date: '25 Sep', expected: 14.75, lower: 14.30, upper: 15.15 },
      { date: '27 Sep', expected: 14.62, lower: 14.10, upper: 15.10 },
      { date: '28 Sep', expected: 14.55, lower: 14.00, upper: 15.05 },
    ],
    forecast30d: [
      { date: '21 Sep', expected: 14.80, lower: 14.60, upper: 15.00 },
      { date: '28 Sep', expected: 14.92, lower: 14.40, upper: 15.45 },
      { date: '05 Oct', expected: 14.85, lower: 14.15, upper: 15.55 },
      { date: '12 Oct', expected: 14.62, lower: 13.80, upper: 15.40 },
      { date: '19 Oct', expected: 14.45, lower: 13.50, upper: 15.35 },
      { date: '26 Oct', expected: 14.37, lower: 13.30, upper: 15.40 },
    ],
    forecast90d: [
      { date: 'Sep 26', expected: 14.80, lower: 14.50, upper: 15.10 },
      { date: 'Oct 26', expected: 14.37, lower: 13.30, upper: 15.40 },
      { date: 'Nov 26', expected: 13.95, lower: 12.80, upper: 15.10 },
      { date: 'Dec 26', expected: 14.20, lower: 12.90, upper: 15.50 },
    ],
    marketInsight: 'Pre-monsoon restocking by Indian integrated steel plants and firming VLSFO bunker benchmarks at Singapore/Fujairah.'
  },
  'haypoint-vizag': {
    id: 'haypoint-vizag',
    name: 'Hay Point (Australia) → Visakhapatnam (East Coast India)',
    origin: 'Hay Point, Australia',
    dest: 'Visakhapatnam, India',
    cargo: '150,000 MT Capesize Hard Coking Coal',
    currentRate: 18.25,
    predictedRate: 17.60,
    deltaPercent: '-3.6%',
    vessel: 'Capesize',
    vesselCapacity: '150,000 MT • 18.2m Draft',
    signal: 'BUY SPOT',
    signalWindow: 'Next 5-10 Days',
    riskScore: 28.0,
    riskLevel: 'Moderate',
    durationDays: 13.8,
    distanceNM: 4980,
    forecast7d: [
      { date: '21 Sep', expected: 18.25, lower: 17.90, upper: 18.60 },
      { date: '23 Sep', expected: 18.10, lower: 17.70, upper: 18.50 },
      { date: '25 Sep', expected: 17.95, lower: 17.40, upper: 18.45 },
      { date: '27 Sep', expected: 17.80, lower: 17.20, upper: 18.35 },
      { date: '28 Sep', expected: 17.70, lower: 17.05, upper: 18.30 },
    ],
    forecast30d: [
      { date: '21 Sep', expected: 18.25, lower: 17.90, upper: 18.60 },
      { date: '28 Sep', expected: 18.05, lower: 17.50, upper: 18.60 },
      { date: '05 Oct', expected: 17.80, lower: 17.10, upper: 18.50 },
      { date: '12 Oct', expected: 17.65, lower: 16.80, upper: 18.45 },
      { date: '19 Oct', expected: 17.60, lower: 16.60, upper: 18.55 },
      { date: '26 Oct', expected: 17.55, lower: 16.50, upper: 18.60 },
    ],
    forecast90d: [
      { date: 'Sep 26', expected: 18.25, lower: 17.80, upper: 18.70 },
      { date: 'Oct 26', expected: 17.60, lower: 16.60, upper: 18.60 },
      { date: 'Nov 26', expected: 17.10, lower: 15.90, upper: 18.30 },
      { date: 'Dec 26', expected: 17.45, lower: 16.00, upper: 18.90 },
    ],
    marketInsight: 'Capesize supply in the Pacific remains abundant; spot chartering window is highly favorable with strong bunker economics.'
  },
  'richardsbay-dhamra': {
    id: 'richardsbay-dhamra',
    name: 'Richards Bay (South Africa) → Dhamra Port (East Coast India)',
    origin: 'Richards Bay, South Africa',
    dest: 'Dhamra Port, India',
    cargo: '85,000 MT Post-Panamax Steam/Coking Coal',
    currentRate: 21.40,
    predictedRate: 22.85,
    deltaPercent: '+6.8%',
    vessel: 'Post-Panamax',
    vesselCapacity: '85,000 MT • 16.5m Draft',
    signal: 'LOCK COA',
    signalWindow: 'Lock Immediately',
    riskScore: 36.2,
    riskLevel: 'Elevated Risk',
    durationDays: 17.2,
    distanceNM: 4450,
    forecast7d: [
      { date: '21 Sep', expected: 21.40, lower: 21.10, upper: 21.70 },
      { date: '23 Sep', expected: 21.80, lower: 21.30, upper: 22.30 },
      { date: '25 Sep', expected: 22.15, lower: 21.50, upper: 22.75 },
      { date: '27 Sep', expected: 22.50, lower: 21.70, upper: 23.20 },
      { date: '28 Sep', expected: 22.70, lower: 21.80, upper: 23.50 },
    ],
    forecast30d: [
      { date: '21 Sep', expected: 21.40, lower: 21.10, upper: 21.70 },
      { date: '28 Sep', expected: 22.10, lower: 21.40, upper: 22.80 },
      { date: '05 Oct', expected: 22.50, lower: 21.70, upper: 23.30 },
      { date: '12 Oct', expected: 22.85, lower: 21.90, upper: 23.80 },
      { date: '19 Oct', expected: 23.10, lower: 22.00, upper: 24.20 },
      { date: '26 Oct', expected: 23.30, lower: 22.10, upper: 24.50 },
    ],
    forecast90d: [
      { date: 'Sep 26', expected: 21.40, lower: 21.00, upper: 21.80 },
      { date: 'Oct 26', expected: 22.85, lower: 21.90, upper: 23.80 },
      { date: 'Nov 26', expected: 23.60, lower: 22.30, upper: 24.90 },
      { date: 'Dec 26', expected: 23.90, lower: 22.40, upper: 25.40 },
    ],
    marketInsight: 'Indian Ocean monsoon swells and rising South African terminal queues suggest locking 3-voyage Contract of Affreightment now.'
  }
};

const SIDEBAR_ITEMS = [
  { id: 'dashboard', label: 'Dashboard', icon: BarChart3, path: '/dashboard' },
  { id: 'forecast', label: 'Freight Forecast', icon: TrendingUp, path: '/forecast' },
  { id: 'market', label: 'Market Intelligence', icon: Activity, path: '/market' },
  { id: 'vessel', label: 'Vessel Optimizer', icon: Ship, path: '/vessel-optimizer' },
  { id: 'ports', label: 'Port Intelligence', icon: MapPin, path: '/port-intelligence' },
  { id: 'routes', label: 'Route Analysis', icon: Compass, path: '/route-analysis' },
  { id: 'contracts', label: 'Contract Intelligence', icon: FileText, path: '/contracts' },
  { id: 'procurement', label: 'Procurement Intelligence', icon: Layers, path: '/procurement' },
  { id: 'scenario', label: 'Scenario Lab', icon: Sliders, path: '/scenario-lab' },
  { id: 'risk', label: 'Risk Monitor', icon: Shield, path: '/risk-monitor' },
  { id: 'ai', label: 'AI Advisor', icon: Sparkles, path: '/ai-advisor' },
];

export const InteractiveCockpitLivePreview: React.FC = () => {
  const [selectedLaneKey, setSelectedLaneKey] = useState<string>('gladstone-paradip');
  const [selectedHorizon, setSelectedHorizon] = useState<'7' | '30' | '90'>('30');
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [liveTimestamp, setLiveTimestamp] = useState<string>('');
  const [liveTickerBDI, setLiveTickerBDI] = useState<number>(1842);
  const [liveTickerVLSFO, setLiveTickerVLSFO] = useState<number>(612);
  const [isSimulatingTwin, setIsSimulatingTwin] = useState<boolean>(false);
  const [twinSavedAmount, setTwinSavedAmount] = useState<string>('$145,000');

  const currentLane = TRADE_LANES[selectedLaneKey] || TRADE_LANES['gladstone-paradip'];

  // Dynamic Clock
  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      const options: Intl.DateTimeFormatOptions = {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        hour12: false,
        timeZone: 'Asia/Kolkata',
      };
      setLiveTimestamp(`${new Intl.DateTimeFormat('en-GB', options).format(now)} IST`);
    };

    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  // Live Micro-ticker simulation
  useEffect(() => {
    const interval = setInterval(() => {
      setLiveTickerBDI((prev) => 1840 + Math.floor(Math.random() * 6));
      setLiveTickerVLSFO((prev) => 610 + Math.floor(Math.random() * 5));
    }, 4000);
    return () => clearInterval(interval);
  }, []);

  const chartData = selectedHorizon === '7'
    ? currentLane.forecast7d
    : selectedHorizon === '30'
      ? currentLane.forecast30d
      : currentLane.forecast90d;

  const handleSimulateTwin = () => {
    setIsSimulatingTwin(true);
    setTimeout(() => {
      setIsSimulatingTwin(false);
      setTwinSavedAmount(selectedLaneKey === 'haypoint-vizag' ? '$230,000' : selectedLaneKey === 'richardsbay-dhamra' ? '$310,000' : '$145,000');
    }, 800);
  };

  return (
    <div className="w-full rounded-2xl overflow-hidden shadow-2xl border border-slate-300/80 bg-white font-sans text-slate-800 select-none flex flex-col text-left">
      
      {/* 1. TOP BROWSER / OS CHROME HEADER */}
      <div className="px-3.5 py-2.5 bg-slate-900 border-b border-slate-800 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-2.5 h-2.5 rounded-full bg-rose-500" />
          <div className="w-2.5 h-2.5 rounded-full bg-[#F8F9FA]0" />
          <div className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
          <div className="h-3 w-px bg-slate-700 mx-1" />
          <span className="text-[11px] font-mono text-slate-300 font-medium flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            PortIN Live Cockpit • v1.0.0
          </span>
        </div>

        <div className="flex items-center gap-2">
          {/* Live Market Ticker pills */}
          <div className="hidden sm:flex items-center gap-2 bg-slate-800/90 px-2.5 py-1 rounded-md text-[10px] text-slate-300 font-mono border border-slate-700">
            <span>BDI: <b className="text-emerald-400">{liveTickerBDI}</b> (+2.1%)</span>
            <span className="text-slate-600">|</span>
            <span>VLSFO: <b className="text-cyan-400">${liveTickerVLSFO}</b></span>
            <span className="text-slate-600">|</span>
            <span>USD/INR: <b className="text-amber-400">₹83.12</b></span>
          </div>

          <span className="text-[9px] font-black px-2 py-0.5 rounded bg-[#E5A93C] text-[#111827] uppercase tracking-wider">
            SAIL LIVE
          </span>
        </div>
      </div>

      {/* 2. MAIN COCKPIT WORKSPACE (Sidebar + Dashboard Grid) */}
      <div className="grid grid-cols-12 bg-slate-100 min-h-[460px] overflow-hidden">
        
        {/* LEFT COMPACT MINI-SIDEBAR */}
        <div className="hidden md:flex col-span-3 lg:col-span-2 bg-[#0B1E36] text-slate-300 flex-col justify-between p-2.5 border-r border-[#162F52]">
          <div className="space-y-3">
            {/* Platform Brand */}
            <div className="flex items-center gap-2 px-1.5 py-1 border-b border-slate-800/80 pb-2">
              <div className="w-5 h-5 rounded bg-[#E5A93C] text-[#111827] font-black flex items-center justify-center text-[10px] shadow-sm">
                P
              </div>
              <div className="leading-tight">
                <div className="text-xs font-black text-white tracking-wider flex items-center gap-1">
                  PortIN
                  <span className="text-[9px] text-[#E5A93C] font-normal">PRO</span>
                </div>
                <div className="text-[8px] text-slate-400">SAIL Maritime Twin</div>
              </div>
            </div>

            {/* Navigation Links */}
            <div className="space-y-0.5">
              {SIDEBAR_ITEMS.slice(0, 7).map((item) => {
                const Icon = item.icon;
                const isSelected = activeTab === item.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => setActiveTab(item.id)}
                    className={`w-full flex items-center gap-2 px-2 py-1.5 rounded-lg text-[11px] font-semibold transition-all cursor-pointer text-left ${
                      isSelected
                        ? 'bg-[#E5A93C] text-[#111827] shadow-sm font-bold'
                        : 'text-slate-300 hover:bg-slate-800/80 hover:text-white'
                    }`}
                  >
                    <Icon className={`w-3.5 h-3.5 shrink-0 ${isSelected ? 'text-[#111827]' : 'text-slate-400'}`} />
                    <span className="truncate">{item.label}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Active Scenario Card at sidebar bottom */}
          <div className="p-2 rounded-lg bg-[#111827] border border-slate-700/80 text-[10px] space-y-1">
            <div className="flex items-center justify-between text-[#E5A93C] font-black text-[9px] uppercase tracking-wider">
              <span>Active Scenario</span>
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
            </div>
            <div className="text-slate-200 font-bold truncate">
              {currentLane.origin.split(',')[0]} → {currentLane.dest.split(' ')[0]}
            </div>
            <div className="text-slate-400 text-[9px] truncate">
              {currentLane.vessel} • {currentLane.cargo.split(' ')[0]}
            </div>
          </div>
        </div>

        {/* RIGHT MAIN COCKPIT VIEW AREA */}
        <div className="col-span-12 md:col-span-9 lg:col-span-10 p-3 sm:p-4 bg-slate-50 overflow-y-auto space-y-3 flex flex-col justify-between">
          
          {/* A. Cockpit Top Bar */}
          <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-200 pb-2.5 bg-white/70 p-2.5 rounded-xl border">
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-xs sm:text-sm font-black text-[#111827]">
                  Executive Maritime Dashboard
                </h3>
                <span className="text-[9px] px-1.5 py-0.5 rounded bg-emerald-100 text-emerald-800 font-bold border border-emerald-300">
                  REAL-TIME SYNC
                </span>
              </div>
              <p className="text-[10px] text-slate-500 font-medium">
                Operational cockpit & live predictive freight analytics for SAIL dry-bulk routes
              </p>
            </div>

            <div className="flex items-center gap-2">
              {/* Lane Selector Dropdown */}
              <div className="relative">
                <select
                  value={selectedLaneKey}
                  onChange={(e) => setSelectedLaneKey(e.target.value)}
                  aria-label="Select Trade Lane"
                  className="text-[10px] font-bold text-slate-800 bg-white border border-slate-300 rounded-lg px-2 py-1 shadow-sm focus:outline-none focus:ring-1 focus:ring-[#E5A93C] cursor-pointer"
                >
                  <option value="gladstone-paradip">Gladstone → Paradip (Panamax 70k)</option>
                  <option value="haypoint-vizag">Hay Point → Vizag (Capesize 150k)</option>
                  <option value="richardsbay-dhamra">Richards Bay → Dhamra (85k Post-Panamax)</option>
                </select>
              </div>

              {/* Live Time Badge */}
              <div className="text-[10px] font-mono text-slate-600 font-semibold bg-slate-100 px-2 py-1 rounded-lg border border-slate-200">
                {liveTimestamp || '21 Sep 2026, 11:00 IST'}
              </div>
            </div>
          </div>

          {/* B. Sub-header Ribbon & Action Button */}
          <div className="flex flex-wrap items-center justify-between gap-2 bg-gradient-to-r from-[#111827] to-[#173A66] text-white p-2.5 rounded-xl shadow-sm">
            <div className="space-y-0.5">
              <div className="flex items-center gap-2 text-[9px] uppercase tracking-wider font-bold text-[#E5A93C]">
                <span>SAIL BULK LOGISTICS COCKPIT</span>
                <span>•</span>
                <span className="text-emerald-300">OFFICIAL STATIC + LIVE AI MODEL</span>
              </div>
              <div className="text-[11px] font-bold text-white">
                {currentLane.name}
              </div>
            </div>

            <button
              type="button"
              onClick={handleSimulateTwin}
              disabled={isSimulatingTwin}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-[10px] font-bold text-[#111827] bg-[#E5A93C] hover:bg-[#D99B2D] transition-all shadow cursor-pointer active:scale-95"
            >
              {isSimulatingTwin ? (
                <>
                  <RefreshCw className="w-3 h-3 animate-spin" />
                  <span>Computing...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-3 h-3" />
                  <span>Launch Decision Twin</span>
                </>
              )}
            </button>
          </div>

          {/* C. 6 Live 3D KPI Metrics Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2">
            
            {/* KPI 1: Current Rate */}
            <div className="bg-white p-2.5 rounded-xl border border-slate-200 shadow-xs hover:border-[#E5A93C] hover:shadow-md transition-all flex flex-col justify-between">
              <div className="flex items-center justify-between">
                <span className="text-[9px] uppercase font-bold text-slate-500">Current Freight</span>
                <Realistic3DBdiChartIcon size={20} />
              </div>
              <div className="text-base font-black text-slate-900 font-mono mt-1">
                ${currentLane.currentRate.toFixed(2)}<span className="text-[9px] font-normal text-slate-500">/MT</span>
              </div>
              <div className="text-[9px] text-slate-500 truncate mt-0.5">
                {currentLane.origin.split(',')[0]}
              </div>
            </div>

            {/* KPI 2: Predicted Rate */}
            <div className="bg-white p-2.5 rounded-xl border border-slate-200 shadow-xs hover:border-[#E5A93C] hover:shadow-md transition-all flex flex-col justify-between">
              <div className="flex items-center justify-between">
                <span className="text-[9px] uppercase font-bold text-slate-500">Predicted Rate</span>
                <Realistic3DAIBrainIcon size={20} />
              </div>
              <div className="text-base font-black text-[#111827] font-mono mt-1">
                ${currentLane.predictedRate.toFixed(2)}<span className="text-[9px] font-normal text-slate-500">/MT</span>
              </div>
              <div className={`text-[9px] font-bold mt-0.5 flex items-center gap-0.5 ${currentLane.deltaPercent.startsWith('-') ? 'text-emerald-600' : 'text-rose-600'}`}>
                {currentLane.deltaPercent.startsWith('-') ? <TrendingDown className="w-2.5 h-2.5" /> : <TrendingUp className="w-2.5 h-2.5" />}
                <span>{currentLane.deltaPercent} vs Spot</span>
              </div>
            </div>

            {/* KPI 3: Recommended Vessel */}
            <div className="bg-white p-2.5 rounded-xl border border-slate-200 shadow-xs hover:border-[#E5A93C] hover:shadow-md transition-all flex flex-col justify-between">
              <div className="flex items-center justify-between">
                <span className="text-[9px] uppercase font-bold text-slate-500">Recommended</span>
                <Realistic3DShipIcon size={20} />
              </div>
              <div className="text-xs font-black text-slate-900 mt-1 truncate">
                {currentLane.vessel}
              </div>
              <div className="text-[8px] text-slate-500 truncate mt-0.5">
                {currentLane.vesselCapacity}
              </div>
            </div>

            {/* KPI 4: Market Signal */}
            <div className="bg-white p-2.5 rounded-xl border border-slate-200 shadow-xs hover:border-[#E5A93C] hover:shadow-md transition-all flex flex-col justify-between">
              <div className="flex items-center justify-between">
                <span className="text-[9px] uppercase font-bold text-slate-500">Market Signal</span>
                <Realistic3DFuelBarrelIcon size={20} />
              </div>
              <div className="mt-1">
                <span className={`text-[10px] font-black px-1.5 py-0.5 rounded ${
                  currentLane.signal === 'BUY SPOT'
                    ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                    : currentLane.signal === 'LOCK COA'
                      ? 'bg-amber-100 text-[#4B5563] border border-[#E5E7EB]'
                      : 'bg-blue-100 text-blue-800 border border-blue-300'
                }`}>
                  {currentLane.signal}
                </span>
              </div>
              <div className="text-[8px] text-slate-500 truncate mt-1">
                {currentLane.signalWindow}
              </div>
            </div>

            {/* KPI 5: Risk Score */}
            <div className="bg-white p-2.5 rounded-xl border border-slate-200 shadow-xs hover:border-[#E5A93C] hover:shadow-md transition-all flex flex-col justify-between">
              <div className="flex items-center justify-between">
                <span className="text-[9px] uppercase font-bold text-slate-500">Risk Score</span>
                <Realistic3DAnchorIcon size={20} />
              </div>
              <div className="text-base font-black text-slate-900 font-mono mt-1">
                {currentLane.riskScore}<span className="text-[9px] font-normal text-slate-400">/100</span>
              </div>
              <div className="text-[8px] font-bold text-emerald-600 mt-0.5">
                {currentLane.riskLevel}
              </div>
            </div>

            {/* KPI 6: Est Voyage Duration */}
            <div className="bg-white p-2.5 rounded-xl border border-slate-200 shadow-xs hover:border-[#E5A93C] hover:shadow-md transition-all flex flex-col justify-between">
              <div className="flex items-center justify-between">
                <span className="text-[9px] uppercase font-bold text-slate-500">Voyage Days</span>
                <Realistic3DCurrencyCoinsIcon size={20} />
              </div>
              <div className="text-base font-black text-slate-900 font-mono mt-1">
                {currentLane.durationDays} <span className="text-[9px] font-normal text-slate-500">Days</span>
              </div>
              <div className="text-[8px] text-slate-500 truncate mt-0.5">
                {currentLane.distanceNM.toLocaleString()} NM Distance
              </div>
            </div>

          </div>

          {/* D. Middle Forecast Curve Chart & Market Intelligence Card */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-2.5">
            
            {/* Left Chart Area */}
            <div className="lg:col-span-8 bg-white p-2.5 sm:p-3 rounded-xl border border-slate-200 shadow-xs space-y-2">
              <div className="flex items-center justify-between flex-wrap gap-2">
                <div>
                  <h4 className="text-[11px] font-black text-[#111827] flex items-center gap-1.5">
                    <TrendingUp className="w-3.5 h-3.5 text-[#E5A93C]" />
                    Freight Rate Forecast & Confidence Band (USD/MT)
                  </h4>
                  <p className="text-[9px] text-slate-500">
                    Probabilistic trajectory with 80% confidence uncertainty interval (p10–p90 quantiles)
                  </p>
                </div>

                {/* Horizon Switcher Tabs */}
                <div className="flex items-center gap-1 bg-slate-100 p-0.5 rounded-lg border border-slate-200">
                  <button
                    type="button"
                    onClick={() => setSelectedHorizon('7')}
                    className={`px-2 py-0.5 text-[9px] font-bold rounded-md transition-all cursor-pointer ${
                      selectedHorizon === '7' ? 'bg-[#111827] text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    7D
                  </button>
                  <button
                    type="button"
                    onClick={() => setSelectedHorizon('30')}
                    className={`px-2 py-0.5 text-[9px] font-bold rounded-md transition-all cursor-pointer ${
                      selectedHorizon === '30' ? 'bg-[#111827] text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    30D
                  </button>
                  <button
                    type="button"
                    onClick={() => setSelectedHorizon('90')}
                    className={`px-2 py-0.5 text-[9px] font-bold rounded-md transition-all cursor-pointer ${
                      selectedHorizon === '90' ? 'bg-[#111827] text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    90D
                  </button>
                </div>
              </div>

              {/* Chart Container */}
              <div className="h-[155px] w-full pt-1">
                <ResponsiveContainer width="100%" height="100%">
                  <ComposedChart data={chartData} margin={{ top: 5, right: 10, left: -25, bottom: 0 }}>
                    <defs>
                      <linearGradient id="liveConfidenceGrad" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#38BDF8" stopOpacity={0.35} />
                        <stop offset="95%" stopColor="#38BDF8" stopOpacity={0.05} />
                      </linearGradient>
                    </defs>
                    <XAxis
                      dataKey="date"
                      tick={{ fontSize: 9, fill: '#64748B' }}
                      axisLine={{ stroke: '#CBD5E1' }}
                      tickLine={false}
                    />
                    <YAxis
                      domain={['auto', 'auto']}
                      tick={{ fontSize: 9, fill: '#64748B' }}
                      axisLine={{ stroke: '#CBD5E1' }}
                      tickLine={false}
                    />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: '#111827',
                        border: 'none',
                        borderRadius: '8px',
                        color: '#FFFFFF',
                        fontSize: '10px',
                        padding: '6px 10px'
                      }}
                      formatter={(value: any, name: any) => [
                        `$${Number(value).toFixed(2)}/MT`,
                        String(name) === 'expected' ? 'Expected Rate' : String(name) === 'upper' ? 'p90 Bound' : 'p10 Bound'
                      ]}
                    />
                    {/* Upper Band */}
                    <Area
                      type="monotone"
                      dataKey="upper"
                      stroke="none"
                      fill="url(#liveConfidenceGrad)"
                    />
                    {/* Lower Band */}
                    <Area
                      type="monotone"
                      dataKey="lower"
                      stroke="none"
                      fill="#FFFFFF"
                    />
                    {/* Expected Rate Line */}
                    <Line
                      type="monotone"
                      dataKey="expected"
                      stroke="#111827"
                      strokeWidth={2.5}
                      dot={{ r: 3, fill: '#E5A93C', stroke: '#111827', strokeWidth: 1.5 }}
                      activeDot={{ r: 5, fill: '#E5A93C' }}
                    />
                  </ComposedChart>
                </ResponsiveContainer>
              </div>

              {/* Chart Legend */}
              <div className="flex items-center justify-between text-[9px] text-slate-500 pt-1 border-t border-slate-100">
                <div className="flex items-center gap-3">
                  <span className="flex items-center gap-1 font-semibold text-slate-700">
                    <span className="w-2.5 h-1 bg-[#111827] rounded-full" />
                    Expected Rate
                  </span>
                  <span className="flex items-center gap-1 font-semibold text-sky-600">
                    <span className="w-2.5 h-2 bg-sky-200 rounded" />
                    80% Confidence Interval
                  </span>
                </div>
                <Link to="/forecast" className="text-[#4B5563] font-bold hover:underline flex items-center gap-0.5">
                  <span>Full Analytics</span>
                  <ChevronRight className="w-2.5 h-2.5" />
                </Link>
              </div>
            </div>

            {/* Right Market Intelligence Box */}
            <div className="lg:col-span-4 bg-white p-2.5 sm:p-3 rounded-xl border border-slate-200 shadow-xs space-y-2 flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-black uppercase tracking-wider text-slate-700">
                    Market Intelligence
                  </span>
                  <span className="text-[8px] font-bold px-1.5 py-0.2 rounded bg-emerald-100 text-emerald-800">
                    {currentLane.signal}
                  </span>
                </div>

                <div className="mt-2 space-y-1.5 text-[10px]">
                  <div className="p-1.5 rounded-lg bg-slate-50 border border-slate-100 flex items-center justify-between">
                    <span className="text-slate-500">Best Booking:</span>
                    <span className="font-bold text-slate-800">{currentLane.signalWindow}</span>
                  </div>
                  <div className="p-1.5 rounded-lg bg-slate-50 border border-slate-100 flex items-center justify-between">
                    <span className="text-slate-500">Rate Trend:</span>
                    <span className="font-bold text-emerald-600">Moderating (-2.9%)</span>
                  </div>
                  <div className="p-1.5 rounded-lg bg-slate-50 border border-slate-100 flex items-center justify-between">
                    <span className="text-slate-500">Bunker Fuel:</span>
                    <span className="font-bold text-slate-800">${liveTickerVLSFO}/MT (Singapore)</span>
                  </div>
                </div>

                <div className="mt-2 p-2 rounded-lg bg-[#F8F9FA] border border-[#E5E7EB] text-[9px] text-[#111827] leading-tight">
                  <b className="font-bold">AI Recommendation:</b> {currentLane.marketInsight}
                </div>
              </div>

              <Link
                to="/market"
                className="inline-flex items-center justify-between text-[9px] font-bold text-[#111827] hover:text-[#4B5563] pt-1"
              >
                <span>View Global Indicators</span>
                <ArrowRight className="w-3 h-3" />
              </Link>
            </div>

          </div>

        </div>

      </div>

      {/* 3. FOOTNOTE BAR (Matching target footer with live status & interactive links) */}
      <div className="p-3 bg-slate-900 border-t border-slate-800 flex flex-wrap items-center justify-between gap-2 text-[11px] text-slate-300">
        <div className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-[#E5A93C] animate-ping" />
          <span className="font-semibold text-[#E5A93C]">
            Decision Twin: Plan A (Best Overall) Recommended — Est. Savings: {twinSavedAmount}
          </span>
        </div>

        <div className="flex items-center gap-3">
          <Link
            to="/dashboard"
            className="text-white hover:text-[#E5A93C] transition-colors flex items-center gap-1 font-bold text-xs"
          >
            <span>Open Full Live Console</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </Link>
        </div>
      </div>

    </div>
  );
};
