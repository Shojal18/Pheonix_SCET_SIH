import React from 'react';

// 1. REALISTIC 3D BALTIC DRY INDEX (BDI) FINANCIAL CHART ICON
export const Realistic3DBdiChartIcon: React.FC<{ size?: number }> = ({ size = 28 }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 48 48"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className="drop-shadow-sm select-none"
  >
    <defs>
      {/* 3D Gold / Amber Linear Gradients */}
      <linearGradient id="bdiBar1Front" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#FBBF24" />
        <stop offset="100%" stopColor="#D97706" />
      </linearGradient>
      <linearGradient id="bdiBar1Top" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#FEF08A" />
        <stop offset="100%" stopColor="#F59E0B" />
      </linearGradient>

      <linearGradient id="bdiBar2Front" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#F59E0B" />
        <stop offset="100%" stopColor="#B45309" />
      </linearGradient>
      <linearGradient id="bdiBar2Top" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#FDE047" />
        <stop offset="100%" stopColor="#D97706" />
      </linearGradient>

      <linearGradient id="bdiBar3Front" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#10B981" />
        <stop offset="100%" stopColor="#047857" />
      </linearGradient>
      <linearGradient id="bdiBar3Top" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#6EE7B7" />
        <stop offset="100%" stopColor="#059669" />
      </linearGradient>

      <linearGradient id="bdiArrowGrad" x1="0%" y1="100%" x2="100%" y2="0%">
        <stop offset="0%" stopColor="#F59E0B" />
        <stop offset="50%" stopColor="#10B981" />
        <stop offset="100%" stopColor="#34D399" />
      </linearGradient>

      {/* 3D Shadow Filter */}
      <filter id="bdiShadow" x="-10%" y="-10%" width="130%" height="130%">
        <feDropShadow dx="1" dy="2" stdDeviation="1.5" floodColor="#0F172A" floodOpacity="0.25" />
      </filter>
    </defs>

    {/* 3D Glass Platform Base */}
    <ellipse cx="24" cy="40" rx="20" ry="5.5" fill="#E2E8F0" />
    <ellipse cx="24" cy="39" rx="19" ry="4.8" fill="url(#bdiBar1Top)" opacity="0.18" />

    {/* Pillar 1 (Left, Lowest) */}
    <g filter="url(#bdiShadow)">
      {/* Front Face */}
      <rect x="7" y="25" width="8" height="13" rx="1.5" fill="url(#bdiBar1Front)" />
      {/* Top Cap */}
      <polygon points="7,25 10,22 18,22 15,25" fill="url(#bdiBar1Top)" />
      {/* Right Side 3D extrusion */}
      <polygon points="15,25 18,22 18,35 15,38" fill="#92400E" opacity="0.6" />
    </g>

    {/* Pillar 2 (Middle) */}
    <g filter="url(#bdiShadow)">
      {/* Front Face */}
      <rect x="19" y="17" width="8.5" height="21" rx="1.5" fill="url(#bdiBar2Front)" />
      {/* Top Cap */}
      <polygon points="19,17 22,14 30.5,14 27.5,17" fill="url(#bdiBar2Top)" />
      {/* Right Side 3D extrusion */}
      <polygon points="27.5,17 30.5,14 30.5,35 27.5,38" fill="#78350F" opacity="0.6" />
    </g>

    {/* Pillar 3 (Right, Highest Rising Trend) */}
    <g filter="url(#bdiShadow)">
      {/* Front Face */}
      <rect x="31" y="9" width="9" height="29" rx="1.5" fill="url(#bdiBar3Front)" />
      {/* Top Cap */}
      <polygon points="31,9 34.5,6 43.5,6 40,9" fill="url(#bdiBar3Top)" />
      {/* Right Side 3D extrusion */}
      <polygon points="40,9 43.5,6 43.5,35 40,38" fill="#064E3B" opacity="0.6" />
    </g>

    {/* 3D Dynamic Rising Trend Arrow Ribbon */}
    <path
      d="M 6 30 Q 20 22 27 15 L 39 5.5"
      stroke="url(#bdiArrowGrad)"
      strokeWidth="3.5"
      strokeLinecap="round"
      fill="none"
    />
    <polygon points="37,4 44,5 42,12" fill="#34D399" />
  </svg>
);

// 2. REALISTIC 3D BULK CARRIER VESSEL ICON
export const Realistic3DShipIcon: React.FC<{ size?: number }> = ({ size = 28 }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 48 48"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className="drop-shadow-sm select-none"
  >
    <defs>
      {/* Realistic Vessel Hull & Deck Gradients */}
      <linearGradient id="shipHullUpper" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#1E293B" />
        <stop offset="60%" stopColor="#0F172A" />
        <stop offset="100%" stopColor="#020617" />
      </linearGradient>
      <linearGradient id="shipHullKeel" x1="0%" y1="0%" x2="0%" y2="100%">
        <stop offset="0%" stopColor="#DC2626" />
        <stop offset="100%" stopColor="#991B1B" />
      </linearGradient>
      <linearGradient id="shipDeckHouse" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#FFFFFF" />
        <stop offset="70%" stopColor="#E2E8F0" />
        <stop offset="100%" stopColor="#CBD5E1" />
      </linearGradient>
      <linearGradient id="shipFunnel" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#F59E0B" />
        <stop offset="100%" stopColor="#B45309" />
      </linearGradient>
      <linearGradient id="shipHatch" x1="0%" y1="0%" x2="0%" y2="100%">
        <stop offset="0%" stopColor="#64748B" />
        <stop offset="100%" stopColor="#334155" />
      </linearGradient>

      {/* Sea Wake Gradient */}
      <linearGradient id="seaWakeGrad" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#38BDF8" stopOpacity="0.8" />
        <stop offset="100%" stopColor="#0284C7" stopOpacity="0.2" />
      </linearGradient>
    </defs>

    {/* Ocean Wave Wake Foam */}
    <ellipse cx="24" cy="41" rx="21" ry="4.5" fill="url(#seaWakeGrad)" />
    <path d="M 3 40 Q 14 43 24 41 Q 34 43 45 40" stroke="#E0F2FE" strokeWidth="1.5" strokeLinecap="round" />

    {/* Lower Red Underwater Hull (Keel / Waterline) */}
    <path
      d="M 6 34 L 10 39 Q 24 41 38 39 L 42 34 Z"
      fill="url(#shipHullKeel)"
    />

    {/* Upper Dark Steel Hull with Bow Flare */}
    <path
      d="M 4 27 L 6 34 L 42 34 L 44 27 Q 24 28.5 4 27 Z"
      fill="url(#shipHullUpper)"
    />

    {/* Gold / White Deck Sheer Line */}
    <line x1="4.5" y1="27" x2="43.5" y2="27" stroke="#F59E0B" strokeWidth="0.8" />

    {/* Cargo Hatches (Dry Bulk Holds) */}
    <g>
      <rect x="14" y="23.5" width="5.5" height="3" rx="0.5" fill="url(#shipHatch)" stroke="#1E293B" strokeWidth="0.5" />
      <rect x="21" y="23.5" width="5.5" height="3" rx="0.5" fill="url(#shipHatch)" stroke="#1E293B" strokeWidth="0.5" />
      <rect x="28" y="23.5" width="5.5" height="3" rx="0.5" fill="url(#shipHatch)" stroke="#1E293B" strokeWidth="0.5" />
    </g>

    {/* Aft Superstructure (Navigation Deckhouse / Bridge) */}
    <path
      d="M 7 17 L 12 17 L 12 27 L 7 27 Z"
      fill="url(#shipDeckHouse)"
      stroke="#94A3B8"
      strokeWidth="0.5"
    />
    {/* Bridge Windows Glass Band */}
    <rect x="7.5" y="18.5" width="4" height="1.5" rx="0.3" fill="#0284C7" />

    {/* Radar Mast & Navigation Antenna */}
    <line x1="9.5" y1="13" x2="9.5" y2="17" stroke="#475569" strokeWidth="1" />
    <line x1="7.5" y1="14" x2="11.5" y2="14" stroke="#475569" strokeWidth="0.8" />
    <circle cx="9.5" cy="12.5" r="1" fill="#F59E0B" />

    {/* Funnel / Exhaust Stack with SAIL Gold livery */}
    <path d="M 6 15 L 7.5 15 L 7.5 21 L 6 21 Z" fill="url(#shipFunnel)" />
    <rect x="6" y="16.5" width="1.5" height="1" fill="#0F172A" />

    {/* Bow Mast (Forepeak) */}
    <line x1="39" y1="21" x2="39" y2="27" stroke="#64748B" strokeWidth="0.8" />
    <circle cx="39" cy="20.5" r="0.8" fill="#EF4444" />
  </svg>
);

// 3. REALISTIC 3D VLSFO BUNKER FUEL BARREL ICON
export const Realistic3DFuelBarrelIcon: React.FC<{ size?: number }> = ({ size = 28 }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 48 48"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className="drop-shadow-sm select-none"
  >
    <defs>
      {/* 3D Metallic Teal / Petrol Cylinder Gradients */}
      <linearGradient id="barrelCylinder" x1="0%" y1="0%" x2="100%" y2="0%">
        <stop offset="0%" stopColor="#0D9488" />
        <stop offset="35%" stopColor="#2DD4BF" />
        <stop offset="65%" stopColor="#14B8A6" />
        <stop offset="100%" stopColor="#0F766E" />
      </linearGradient>
      <linearGradient id="barrelTopRim" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#5EEAD4" />
        <stop offset="50%" stopColor="#14B8A6" />
        <stop offset="100%" stopColor="#042F2E" />
      </linearGradient>
      <linearGradient id="fuelDropGrad" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#A7F3D0" />
        <stop offset="40%" stopColor="#10B981" />
        <stop offset="100%" stopColor="#064E3B" />
      </linearGradient>
      <filter id="barrelShadow" x="-10%" y="-10%" width="130%" height="130%">
        <feDropShadow dx="1" dy="3" stdDeviation="2" floodColor="#042F2E" floodOpacity="0.2" />
      </filter>
    </defs>

    {/* Ground Shadow */}
    <ellipse cx="23" cy="41" rx="14" ry="4" fill="#CBD5E1" opacity="0.6" />

    {/* Main 3D Barrel Body */}
    <g filter="url(#barrelShadow)">
      {/* Cylindrical Extrusion Body */}
      <path
        d="M 12 16 L 12 36 C 12 39.5 34 39.5 34 36 L 34 16 Z"
        fill="url(#barrelCylinder)"
      />

      {/* Embossed Steel Reinforcement Rib 1 (Upper) */}
      <path
        d="M 11.5 22 C 11.5 24 34.5 24 34.5 22 C 34.5 20.8 11.5 20.8 11.5 22 Z"
        fill="#042F2E"
        opacity="0.25"
      />
      <path
        d="M 11.8 22.5 C 11.8 24.2 34.2 24.2 34.2 22.5"
        stroke="#5EEAD4"
        strokeWidth="1.2"
        fill="none"
      />

      {/* Embossed Steel Reinforcement Rib 2 (Lower) */}
      <path
        d="M 11.5 30 C 11.5 32 34.5 32 34.5 30 C 34.5 28.8 11.5 28.8 11.5 30 Z"
        fill="#042F2E"
        opacity="0.25"
      />
      <path
        d="M 11.8 30.5 C 11.8 32.2 34.2 32.2 34.2 30.5"
        stroke="#5EEAD4"
        strokeWidth="1.2"
        fill="none"
      />

      {/* Bottom Rim Bevel */}
      <ellipse cx="23" cy="36" rx="11" ry="3.5" fill="#0F766E" />

      {/* Top Metallic Lid / Chime Rim */}
      <ellipse cx="23" cy="16" rx="11" ry="3.8" fill="url(#barrelTopRim)" stroke="#99F6E4" strokeWidth="0.8" />
      <ellipse cx="23" cy="16" rx="9" ry="2.8" fill="#0F766E" />

      {/* Chrome Bung / Filling Cap */}
      <circle cx="28" cy="15.2" r="1.8" fill="#F8FAFC" stroke="#94A3B8" strokeWidth="0.5" />
    </g>

    {/* Glossy 3D Fuel Droplet on Right */}
    <g transform="translate(26, 4) scale(0.9)">
      <path
        d="M 10 2 C 10 2 3 11 3 16 C 3 19.8 6.1 23 10 23 C 13.9 23 17 19.8 17 16 C 17 11 10 2 10 2 Z"
        fill="url(#fuelDropGrad)"
        stroke="#A7F3D0"
        strokeWidth="0.8"
      />
      {/* Specular Highlight on Drop */}
      <ellipse cx="7.5" cy="13" rx="1.5" ry="3.5" transform="rotate(-30 7.5 13)" fill="#FFFFFF" opacity="0.8" />
    </g>
  </svg>
);

// 4. REALISTIC 3D GOLD CURRENCY COINS (USD / INR) ICON
export const Realistic3DCurrencyCoinsIcon: React.FC<{ size?: number }> = ({ size = 28 }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 48 48"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className="drop-shadow-sm select-none"
  >
    <defs>
      {/* Realistic 24K Gold Coin Gradients */}
      <linearGradient id="goldCoinFace" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#FEF08A" />
        <stop offset="35%" stopColor="#F59E0B" />
        <stop offset="70%" stopColor="#D97706" />
        <stop offset="100%" stopColor="#B45309" />
      </linearGradient>
      <linearGradient id="goldCoinEdge" x1="0%" y1="0%" x2="0%" y2="100%">
        <stop offset="0%" stopColor="#D97706" />
        <stop offset="100%" stopColor="#78350F" />
      </linearGradient>
      <linearGradient id="silverCoinFace" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#FFFFFF" />
        <stop offset="45%" stopColor="#E2E8F0" />
        <stop offset="80%" stopColor="#94A3B8" />
        <stop offset="100%" stopColor="#475569" />
      </linearGradient>
      <filter id="coinShadow" x="-20%" y="-20%" width="140%" height="140%">
        <feDropShadow dx="1.5" dy="3" stdDeviation="2" floodColor="#451A03" floodOpacity="0.28" />
      </filter>
    </defs>

    {/* Ground Shadow */}
    <ellipse cx="24" cy="41" rx="17" ry="4" fill="#CBD5E1" opacity="0.7" />

    {/* Rear Coin 1 ($ USD Coin) */}
    <g filter="url(#coinShadow)" transform="translate(18, 9) scale(0.9)">
      {/* Coin Thickness Edge */}
      <path
        d="M 3 16 C 3 24 23 24 23 16 L 23 20 C 23 28 3 28 3 20 Z"
        fill="url(#goldCoinEdge)"
      />
      {/* Front Face */}
      <ellipse cx="13" cy="16" rx="10" ry="8" fill="url(#silverCoinFace)" stroke="#F8FAFC" strokeWidth="1" />
      {/* Inner Rim */}
      <ellipse cx="13" cy="16" rx="8.5" ry="6.8" fill="none" stroke="#64748B" strokeWidth="0.6" strokeDasharray="1.5 1.5" />
      {/* Embossed Dollar Glyph */}
      <text
        x="13"
        y="19"
        fontFamily="sans-serif"
        fontSize="9"
        fontWeight="900"
        fill="#1E293B"
        textAnchor="middle"
      >
        $
      </text>
    </g>

    {/* Front Master 24K Gold Coin 2 (₹ INR Rupee Coin) */}
    <g filter="url(#coinShadow)">
      {/* Coin Reeded Thickness Edge */}
      <path
        d="M 7 24 C 7 34 31 34 31 24 L 31 28 C 31 38 7 38 7 28 Z"
        fill="url(#goldCoinEdge)"
      />
      {/* Front Coin Face */}
      <ellipse cx="19" cy="24" rx="12" ry="9.5" fill="url(#goldCoinFace)" stroke="#FEF08A" strokeWidth="1.2" />
      {/* Inner Decorative Beaded Rim */}
      <ellipse cx="19" cy="24" rx="10.2" ry="7.8" fill="none" stroke="#FEF3C7" strokeWidth="0.8" strokeDasharray="2 1.5" />
      {/* Embossed Indian Rupee Symbol */}
      <text
        x="19"
        y="28"
        fontFamily="sans-serif"
        fontSize="12"
        fontWeight="900"
        fill="#78350F"
        textAnchor="middle"
      >
        ₹
      </text>
      {/* Glint Light Sheen */}
      <ellipse cx="15" cy="20" rx="3.5" ry="1.8" transform="rotate(-25 15 20)" fill="#FFFFFF" opacity="0.6" />
    </g>
  </svg>
);

// 5. REALISTIC 3D MARITIME ANCHOR & HARBOR CONGESTION ICON
export const Realistic3DAnchorIcon: React.FC<{ size?: number }> = ({ size = 28 }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 48 48"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className="drop-shadow-sm select-none"
  >
    <defs>
      {/* Cast Iron / Steel Gradients */}
      <linearGradient id="anchorSteelGrad" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#94A3B8" />
        <stop offset="40%" stopColor="#475569" />
        <stop offset="80%" stopColor="#334155" />
        <stop offset="100%" stopColor="#0F172A" />
      </linearGradient>
      <linearGradient id="anchorGoldShackle" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#FDE047" />
        <stop offset="50%" stopColor="#D97706" />
        <stop offset="100%" stopColor="#78350F" />
      </linearGradient>
      <linearGradient id="anchorWarningGrad" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#F87171" />
        <stop offset="100%" stopColor="#DC2626" />
      </linearGradient>
      <filter id="anchorShadow" x="-15%" y="-15%" width="130%" height="130%">
        <feDropShadow dx="1" dy="2.5" stdDeviation="1.8" floodColor="#0F172A" floodOpacity="0.25" />
      </filter>
    </defs>

    {/* Ground Shadow */}
    <ellipse cx="24" cy="42" rx="16" ry="3.5" fill="#CBD5E1" opacity="0.6" />

    <g filter="url(#anchorShadow)">
      {/* Top Gold Shackle Ring */}
      <circle cx="24" cy="8" r="4.5" fill="none" stroke="url(#anchorGoldShackle)" strokeWidth="2.2" />
      <circle cx="24" cy="8" r="2.3" fill="#F1F5F9" />

      {/* Horizontal Crossbar (Stock) with 3D end spheres */}
      <rect x="10" y="14" width="28" height="3" rx="1.5" fill="url(#anchorSteelGrad)" stroke="#CBD5E1" strokeWidth="0.5" />
      <circle cx="10" cy="15.5" r="2.2" fill="url(#anchorGoldShackle)" />
      <circle cx="38" cy="15.5" r="2.2" fill="url(#anchorGoldShackle)" />

      {/* Vertical Heavy Steel Shank */}
      <rect x="22" y="10" width="4" height="26" rx="1" fill="url(#anchorSteelGrad)" />
      {/* Center 3D Ridge Highlight */}
      <line x1="23.5" y1="11" x2="23.5" y2="35" stroke="#94A3B8" strokeWidth="0.8" />

      {/* Curved Flukes / Arms */}
      <path
        d="M 8 28 C 8 41 40 41 40 28 C 36 29 35 34 24 34 C 13 34 12 29 8 28 Z"
        fill="url(#anchorSteelGrad)"
        stroke="#64748B"
        strokeWidth="0.6"
      />

      {/* Sharp Left & Right Bill Fluke Palms */}
      <polygon points="6,27 11,24 10,29" fill="url(#anchorSteelGrad)" stroke="#CBD5E1" strokeWidth="0.5" />
      <polygon points="42,27 37,24 38,29" fill="url(#anchorSteelGrad)" stroke="#CBD5E1" strokeWidth="0.5" />

      {/* Center Crown */}
      <circle cx="24" cy="35.5" r="2.8" fill="url(#anchorSteelGrad)" />
    </g>

    {/* Port Congestion Warning Marine Buoy on Upper Right */}
    <g transform="translate(29, 3) scale(0.85)">
      <circle cx="12" cy="12" r="7" fill="url(#anchorWarningGrad)" stroke="#FECACA" strokeWidth="1" />
      <text x="12" y="16" fontFamily="sans-serif" fontSize="10" fontWeight="900" fill="#FFFFFF" textAnchor="middle">!</text>
      <circle cx="12" cy="12" r="9" fill="none" stroke="#EF4444" strokeWidth="1" opacity="0.6" className="animate-ping origin-center" />
    </g>
  </svg>
);

// 6. REALISTIC 3D AI FORECAST NEURAL BRAIN CHIP ICON
export const Realistic3DAIBrainIcon: React.FC<{ size?: number }> = ({ size = 28 }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 48 48"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className="drop-shadow-sm select-none"
  >
    <defs>
      {/* 3D Microchip & Neural Core Gradients */}
      <linearGradient id="aiChipGrad" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#1E293B" />
        <stop offset="60%" stopColor="#0F172A" />
        <stop offset="100%" stopColor="#020617" />
      </linearGradient>
      <linearGradient id="aiBrainGlow" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#FDE047" />
        <stop offset="40%" stopColor="#F59E0B" />
        <stop offset="80%" stopColor="#D97706" />
        <stop offset="100%" stopColor="#B45309" />
      </linearGradient>
      <linearGradient id="aiSynapseCyan" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#67E8F9" />
        <stop offset="100%" stopColor="#06B6D4" />
      </linearGradient>
      <filter id="aiGlowFilter" x="-20%" y="-20%" width="140%" height="140%">
        <feDropShadow dx="0" dy="2" stdDeviation="2.5" floodColor="#F59E0B" floodOpacity="0.4" />
      </filter>
    </defs>

    {/* Outer Microchip Substrate Board */}
    <rect x="7" y="7" width="34" height="34" rx="6" fill="url(#aiChipGrad)" stroke="#475569" strokeWidth="1" />

    {/* Gold Interconnect Contact Pins (Top, Bottom, Left, Right) */}
    <g fill="#F59E0B">
      {/* Top Pins */}
      <rect x="14" y="3" width="2" height="4" rx="0.5" />
      <rect x="20" y="3" width="2" height="4" rx="0.5" />
      <rect x="26" y="3" width="2" height="4" rx="0.5" />
      <rect x="32" y="3" width="2" height="4" rx="0.5" />

      {/* Bottom Pins */}
      <rect x="14" y="41" width="2" height="4" rx="0.5" />
      <rect x="20" y="41" width="2" height="4" rx="0.5" />
      <rect x="26" y="41" width="2" height="4" rx="0.5" />
      <rect x="32" y="41" width="2" height="4" rx="0.5" />

      {/* Left Pins */}
      <rect x="3" y="14" width="4" height="2" rx="0.5" />
      <rect x="3" y="20" width="4" height="2" rx="0.5" />
      <rect x="3" y="26" width="4" height="2" rx="0.5" />
      <rect x="3" y="32" width="4" height="2" rx="0.5" />

      {/* Right Pins */}
      <rect x="41" y="14" width="4" height="2" rx="0.5" />
      <rect x="41" y="20" width="4" height="2" rx="0.5" />
      <rect x="41" y="26" width="4" height="2" rx="0.5" />
      <rect x="41" y="32" width="4" height="2" rx="0.5" />
    </g>

    {/* Motherboard Circuit Optical Traces */}
    <path
      d="M 15 14 L 19 18 L 19 22 M 33 14 L 29 18 L 29 22 M 15 34 L 19 30 M 33 34 L 29 30"
      stroke="#38BDF8"
      strokeWidth="1"
      strokeLinecap="round"
      opacity="0.7"
    />

    {/* Center 3D Floating Glowing Neural Brain Matrix */}
    <g filter="url(#aiGlowFilter)">
      {/* Left Hemisphere */}
      <path
        d="M 23 15 C 18 15 14 18 14 23 C 14 25.5 15.5 27.5 17 29 C 16.5 31 17.5 33 20 33 C 21.5 33 22.5 32 23 31 Z"
        fill="url(#aiBrainGlow)"
        stroke="#FEF08A"
        strokeWidth="0.8"
      />
      {/* Right Hemisphere */}
      <path
        d="M 25 15 C 30 15 34 18 34 23 C 34 25.5 32.5 27.5 31 29 C 31.5 31 30.5 33 28 33 C 26.5 33 25.5 32 25 31 Z"
        fill="url(#aiBrainGlow)"
        stroke="#FEF08A"
        strokeWidth="0.8"
      />
      {/* Center Neural Fissure */}
      <line x1="24" y1="15" x2="24" y2="33" stroke="#0F172A" strokeWidth="1" strokeDasharray="1.5 1.5" />

      {/* Synaptic Nodes Glowing Sparkles */}
      <circle cx="18" cy="20" r="1.5" fill="#FFFFFF" />
      <circle cx="30" cy="20" r="1.5" fill="#FFFFFF" />
      <circle cx="18" cy="27" r="1.2" fill="#67E8F9" />
      <circle cx="30" cy="27" r="1.2" fill="#67E8F9" />
      <circle cx="24" cy="24" r="2" fill="#FEF08A" />
    </g>
  </svg>
);
