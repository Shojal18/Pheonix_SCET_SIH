import React, { useState, useRef } from 'react';

interface Realistic3DKPICardProps {
  title: string;
  subtitle?: string;
  value: string | number;
  unit?: string;
  trend: 'up' | 'down' | 'neutral';
  trendText: string;
  trendPositive?: boolean; // if true, 'up' is green; if false (e.g. congestion), 'up' is red
  icon: React.ReactNode;
  sparklineData: number[];
  sparklineColor?: string;
  accentColor?: 'amber' | 'blue' | 'teal' | 'rose' | 'indigo' | 'emerald';
}

export const Realistic3DKPICard: React.FC<Realistic3DKPICardProps> = ({
  title,
  subtitle,
  value,
  unit,
  trend,
  trendText,
  trendPositive = true,
  icon,
  sparklineData,
  sparklineColor,
  accentColor = 'amber',
}) => {
  const cardRef = useRef<HTMLDivElement>(null);
  const [rotateX, setRotateX] = useState(0);
  const [rotateY, setRotateY] = useState(0);
  const [glarePos, setGlarePos] = useState({ x: 50, y: 50, opacity: 0 });
  const [isHovered, setIsHovered] = useState(false);

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!cardRef.current) return;
    const rect = cardRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    const centerX = rect.width / 2;
    const centerY = rect.height / 2;

    // Calculate smooth 3D tilt angles (max ~14 degrees)
    const rotX = ((y - centerY) / centerY) * -12;
    const rotY = ((x - centerX) / centerX) * 12;

    setRotateX(rotX);
    setRotateY(rotY);
    setGlarePos({
      x: (x / rect.width) * 100,
      y: (y / rect.height) * 100,
      opacity: 0.55,
    });
  };

  const handleMouseEnter = () => {
    setIsHovered(true);
  };

  const handleMouseLeave = () => {
    setIsHovered(false);
    setRotateX(0);
    setRotateY(0);
    setGlarePos((prev) => ({ ...prev, opacity: 0 }));
  };

  // Sparkline calculations
  const min = Math.min(...sparklineData);
  const max = Math.max(...sparklineData);
  const range = max - min || 1;
  const width = 86;
  const height = 34;

  const points = sparklineData
    .map((val, idx) => {
      const x = (idx / (sparklineData.length - 1)) * width;
      const y = height - ((val - min) / range) * (height - 8) - 4;
      return `${x.toFixed(1)},${y.toFixed(1)}`;
    })
    .join(' ');

  const lastPoint = sparklineData.length > 0
    ? {
        x: width,
        y: height - ((sparklineData[sparklineData.length - 1] - min) / range) * (height - 8) - 4,
      }
    : { x: width, y: height / 2 };

  const areaPoints = `0,${height} ${points} ${width},${height}`;

  // Trend color determination
  const isGoodTrend = (trend === 'up' && trendPositive) || (trend === 'down' && !trendPositive);
  const effectiveColor = sparklineColor || (isGoodTrend ? '#10B981' : '#F43F5E');

  // Accent styling mappings
  const accentStyles = {
    amber: {
      iconBg: 'from-amber-400/20 to-amber-600/10 border-[#E5E7EB]/60 text-[#4B5563] shadow-amber-500/15',
      glow: 'rgba(245, 158, 11, 0.12)',
    },
    teal: {
      iconBg: 'from-teal-400/20 to-teal-600/10 border-teal-300/60 text-teal-700 shadow-teal-500/15',
      glow: 'rgba(20, 184, 166, 0.12)',
    },
    blue: {
      iconBg: 'from-blue-400/20 to-blue-600/10 border-blue-300/60 text-blue-700 shadow-blue-500/15',
      glow: 'rgba(59, 130, 246, 0.12)',
    },
    indigo: {
      iconBg: 'from-indigo-400/20 to-indigo-600/10 border-indigo-300/60 text-indigo-700 shadow-indigo-500/15',
      glow: 'rgba(99, 102, 241, 0.12)',
    },
    rose: {
      iconBg: 'from-rose-400/20 to-rose-600/10 border-rose-300/60 text-rose-700 shadow-rose-500/15',
      glow: 'rgba(244, 63, 94, 0.12)',
    },
    emerald: {
      iconBg: 'from-emerald-400/20 to-emerald-600/10 border-emerald-300/60 text-emerald-700 shadow-emerald-500/15',
      glow: 'rgba(16, 185, 129, 0.12)',
    },
  }[accentColor];

  return (
    <div
      style={{ perspective: 1000 }}
      className="w-full h-full select-none"
    >
      <div
        ref={cardRef}
        onMouseMove={handleMouseMove}
        onMouseEnter={handleMouseEnter}
        onMouseLeave={handleMouseLeave}
        style={{
          transform: `rotateX(${rotateX}deg) rotateY(${rotateY}deg) translateZ(${isHovered ? 12 : 0}px)`,
          transition: isHovered ? 'transform 0.08s ease-out, box-shadow 0.2s ease-out' : 'transform 0.5s cubic-bezier(0.2, 0.8, 0.2, 1), box-shadow 0.5s ease-out',
          boxShadow: isHovered
            ? `0 20px 35px -8px rgba(15, 39, 71, 0.14), 0 10px 15px -6px rgba(15, 39, 71, 0.08), 0 0 25px ${accentStyles.glow}, inset 0 1.5px 0 rgba(255, 255, 255, 1), inset 0 -2px 5px rgba(15, 39, 71, 0.04)`
            : '0 8px 20px -4px rgba(15, 39, 71, 0.06), 0 4px 6px -2px rgba(15, 39, 71, 0.03), inset 0 1px 0 rgba(255, 255, 255, 0.9), inset 0 -1px 3px rgba(15, 39, 71, 0.02)',
        }}
        className="relative rounded-2xl p-4 bg-gradient-to-b from-white via-[#FCFCFD] to-[#F7F9FC] border border-slate-200/90 hover:border-slate-300 transition-colors flex flex-col justify-between overflow-hidden cursor-pointer group"
      >
        {/* Specular 3D Glare Lighting Sheen Layer */}
        <div
          aria-hidden="true"
          className="pointer-events-none absolute inset-0 z-10 transition-opacity duration-200"
          style={{
            opacity: glarePos.opacity,
            background: `radial-gradient(circle 140px at ${glarePos.x}% ${glarePos.y}%, rgba(255, 255, 255, 0.75) 0%, rgba(255, 255, 255, 0.15) 45%, transparent 75%)`,
          }}
        />

        {/* Glossy Top Edge Highlight Ribbon */}
        <div className="absolute top-0 inset-x-0 h-1 bg-gradient-to-r from-transparent via-white/80 to-transparent pointer-events-none" />

        {/* 1. Header: 3D Raised Icon + Title */}
        <div
          style={{ transform: 'translateZ(18px)' }}
          className="flex items-center justify-between mb-2 transition-transform duration-200"
        >
          <div className="flex items-center gap-2.5">
            {/* 3D Embossed Icon Container with inset bevel & drop shadow */}
            <div
              className={`p-2 rounded-xl bg-gradient-to-br ${accentStyles.iconBg} border shadow-xs flex items-center justify-center shrink-0 transition-transform duration-300 group-hover:scale-105 group-hover:rotate-3`}
              style={{
                boxShadow: 'inset 0 1px 2px rgba(255, 255, 255, 0.9), 0 3px 6px rgba(15, 39, 71, 0.08)',
              }}
            >
              {icon}
            </div>

            <div>
              <span className="text-[11px] font-extrabold text-slate-700 tracking-tight leading-tight block">
                {title}
              </span>
              {subtitle && (
                <span className="text-[9px] font-semibold text-slate-400 block -mt-0.5">
                  {subtitle}
                </span>
              )}
            </div>
          </div>
        </div>

        {/* 2. Value & Sparkline Row with 3D Depth */}
        <div
          style={{ transform: 'translateZ(24px)' }}
          className="flex items-end justify-between gap-1.5 mt-1 transition-transform duration-200"
        >
          {/* Main Numeric Metric with Depth Drop-Shadow */}
          <div>
            <div
              className="text-xl sm:text-[22px] font-black text-slate-900 font-mono tracking-tight leading-none drop-shadow-xs flex items-baseline gap-0.5"
            >
              <span>{value}</span>
              {unit && <span className="text-[10px] font-bold text-slate-500">{unit}</span>}
            </div>

            {/* Trend Indicator Pill */}
            <div
              className={`text-[11px] font-black flex items-center gap-1 mt-1.5 ${
                isGoodTrend ? 'text-emerald-600' : 'text-rose-600'
              }`}
            >
              <span className={`text-[9px] px-1 py-0.2 rounded-md font-black flex items-center gap-0.5 ${
                isGoodTrend ? 'bg-emerald-50 text-emerald-700 border border-emerald-200/80' : 'bg-rose-50 text-rose-700 border border-rose-200/80'
              }`}>
                <span>{trend === 'up' ? '▲' : trend === 'down' ? '▼' : '●'}</span>
                <span>{trendText}</span>
              </span>
            </div>
          </div>

          {/* 3. 3D Glowing Wave Sparkline */}
          <div
            style={{ transform: 'translateZ(20px)' }}
            className="relative shrink-0 overflow-visible pb-0.5"
          >
            <svg width={width} height={height} className="overflow-visible">
              <defs>
                <linearGradient id={`grad3d-${title.replace(/[^a-zA-Z0-9]/g, '')}`} x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor={effectiveColor} stopOpacity={0.35} />
                  <stop offset="100%" stopColor={effectiveColor} stopOpacity={0.0} />
                </linearGradient>
                <filter id={`glow3d-${title.replace(/[^a-zA-Z0-9]/g, '')}`} x="-20%" y="-20%" width="140%" height="140%">
                  <feDropShadow dx="0" dy="3" stdDeviation="2.5" floodColor={effectiveColor} floodOpacity="0.38" />
                </filter>
              </defs>

              {/* Shaded Area Under Curve */}
              <polygon
                points={areaPoints}
                fill={`url(#grad3d-${title.replace(/[^a-zA-Z0-9]/g, '')})`}
              />

              {/* Glowing 3D Vector Line */}
              <polyline
                fill="none"
                stroke={effectiveColor}
                strokeWidth="2.5"
                strokeLinecap="round"
                strokeLinejoin="round"
                points={points}
                filter={`url(#glow3d-${title.replace(/[^a-zA-Z0-9]/g, '')})`}
              />

              {/* Pulsing Beacon on Latest Data Point */}
              <circle
                cx={lastPoint.x}
                cy={lastPoint.y}
                r="3.5"
                fill="#FFFFFF"
                stroke={effectiveColor}
                strokeWidth="2.5"
              />
              <circle
                cx={lastPoint.x}
                cy={lastPoint.y}
                r="6.5"
                fill="none"
                stroke={effectiveColor}
                strokeWidth="1.5"
                className="animate-ping opacity-75 origin-center"
              />
            </svg>
          </div>
        </div>

        {/* Bottom 3D Ambient Edge */}
        <div className="absolute bottom-0 inset-x-0 h-1 bg-gradient-to-r from-transparent via-slate-200/50 to-transparent pointer-events-none" />
      </div>
    </div>
  );
};
