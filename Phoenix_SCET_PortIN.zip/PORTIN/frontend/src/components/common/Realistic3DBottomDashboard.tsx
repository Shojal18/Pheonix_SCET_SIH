import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import {
  Anchor, Ship, ArrowRight, Sparkles, Bell, ChevronRight,
  TrendingUp, TrendingDown, Activity, AlertTriangle, ShieldCheck,
  CheckCircle2, Waves, Wind, Compass, ExternalLink
} from 'lucide-react';
import { Realistic3DBox } from './Realistic3DMiddleDashboard';
import {
  Realistic3DAnchorIcon,
  Realistic3DShipIcon,
  Realistic3DAIBrainIcon,
  Realistic3DBdiChartIcon,
  Realistic3DFuelBarrelIcon
} from './Realistic3DIcons';

export const Realistic3DBottomDashboard: React.FC = () => {
  // Selected Vessel State
  const [selectedVessel, setSelectedVessel] = useState<'capesize' | 'panamax' | 'supramax'>('capesize');

  // Real-time live port congestion micro-tick
  const [portWaitTimes, setPortWaitTimes] = useState({
    paradip: 1.2,
    dhamra: 2.8,
    vizag: 0.6,
    kakinada: 1.9,
  });

  // Real-time live alerts stream with ticking timestamps
  const [liveAlerts, setLiveAlerts] = useState([
    {
      id: 1,
      type: 'weather',
      icon: '🌊',
      title: 'Cyclone & Sea State Alert',
      desc: 'Bay of Bengal wave heights 3.2m; favorable route via Malacca Strait.',
      time: 'Just now',
      severity: 'warning',
    },
    {
      id: 2,
      type: 'freight',
      icon: '📈',
      title: 'Capesize Spot Rate Surge',
      desc: 'Pacific Capesize index up +3.8% DoD; bunker prices firming.',
      time: '8m ago',
      severity: 'info',
    },
    {
      id: 3,
      type: 'port',
      icon: '⚓',
      title: 'Paradip CQ-1 Berth Update',
      desc: 'Berth draft cleared to 14.5m with quick turnarounds.',
      time: '24m ago',
      severity: 'success',
    },
    {
      id: 4,
      type: 'market',
      icon: '💡',
      title: 'COA Arbitrage Window',
      desc: 'Lock 3-voyage commitment before monsoon rate premium.',
      time: '1h ago',
      severity: 'info',
    },
  ]);

  // Periodic live micro-fluctuation simulation for realism
  useEffect(() => {
    const interval = setInterval(() => {
      setPortWaitTimes({
        paradip: Number((1.2 + (Math.random() * 0.2 - 0.1)).toFixed(1)),
        dhamra: Number((2.8 + (Math.random() * 0.2 - 0.1)).toFixed(1)),
        vizag: Number((0.6 + (Math.random() * 0.1 - 0.05)).toFixed(1)),
        kakinada: Number((1.9 + (Math.random() * 0.2 - 0.1)).toFixed(1)),
      });
    }, 6000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 select-none">
      
      {/* ========================================================================= */}
      {/* CARD 1: 3D PORT & CONGESTION LIVE RADAR (4 Columns) */}
      {/* ========================================================================= */}
      <div className="lg:col-span-4">
        <Realistic3DBox accentGlow="rgba(244, 63, 94, 0.14)" className="space-y-3.5">
          
          {/* Header */}
          <div style={{ transform: 'translateZ(18px)' }} className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="p-2 rounded-xl bg-rose-500/10 border border-rose-400/30 text-rose-700 shadow-xs">
                <Realistic3DAnchorIcon size={20} />
              </div>
              <div>
                <h3 className="text-sm font-extrabold text-[#111827] tracking-tight">
                  Port & Congestion (<span className="text-slate-800">🇮🇳 East Coast</span>)
                </h3>
                <span className="text-[10px] text-slate-500 font-semibold flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-ping" />
                  Live Berth & Lock Queue Feed
                </span>
              </div>
            </div>

            <Link
              to="/port-intelligence"
              className="text-xs font-black text-slate-700 hover:text-[#111827] flex items-center gap-1 hover:underline"
            >
              <span>View All</span>
              <ArrowRight className="w-3.5 h-3.5 text-[#4B5563]" />
            </Link>
          </div>

          {/* 3D Tactile Port Congestion Live Table */}
          <div
            style={{
              transform: 'translateZ(20px)',
              boxShadow: 'inset 0 1px 0 #FFFFFF, 0 4px 12px rgba(15, 39, 71, 0.05)',
            }}
            className="rounded-xl border border-slate-200/90 bg-white overflow-hidden p-2"
          >
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-100 text-[9px] uppercase font-black tracking-wider text-slate-400">
                  <th className="pb-2 pl-1 font-black">Port</th>
                  <th className="pb-2 font-black">Congestion</th>
                  <th className="pb-2 font-black">Wait Time</th>
                  <th className="pb-2 font-black">Weather</th>
                  <th className="pb-2 font-black text-right pr-1">Trend</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100/80 font-semibold">
                
                {/* 1. Paradip */}
                <tr className="hover:bg-[#F8F9FA]/40 transition-colors group cursor-pointer">
                  <td className="py-2.5 pl-1 font-bold text-slate-900">
                    <span className="inline-flex items-center gap-1.5">
                      <span className="text-sm">🇮🇳</span>
                      <span className="group-hover:text-[#4B5563] transition-colors font-extrabold">Paradip</span>
                    </span>
                  </td>
                  <td className="py-2.5">
                    <span className="inline-flex items-center gap-1 text-slate-700 text-[10px] font-bold bg-[#F8F9FA] px-1.5 py-0.5 rounded-md border border-[#E5E7EB]">
                      <span className="w-1.5 h-1.5 rounded-full bg-[#F8F9FA]0" />
                      Moderate
                    </span>
                  </td>
                  <td className="py-2.5 font-mono text-slate-800 font-bold text-[11px]">
                    {portWaitTimes.paradip} days
                  </td>
                  <td className="py-2.5">
                    <span className="inline-flex items-center gap-1 text-emerald-700 font-bold text-[10px] bg-emerald-50 px-1.5 py-0.5 rounded-md border border-emerald-200/60">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                      Low
                    </span>
                  </td>
                  <td className="py-2.5 text-right pr-1 font-bold text-emerald-600">
                    <span className="inline-flex items-center gap-0.5">
                      <TrendingUp className="w-3 h-3 text-emerald-600" />
                      <ChevronRight className="w-3 h-3 text-slate-400 group-hover:translate-x-0.5 transition-transform" />
                    </span>
                  </td>
                </tr>

                {/* 2. Dhamra */}
                <tr className="hover:bg-[#F8F9FA]/40 transition-colors group cursor-pointer">
                  <td className="py-2.5 pl-1 font-bold text-slate-900">
                    <span className="inline-flex items-center gap-1.5">
                      <span className="text-sm">🇮🇳</span>
                      <span className="group-hover:text-[#4B5563] transition-colors font-extrabold">Dhamra</span>
                    </span>
                  </td>
                  <td className="py-2.5">
                    <span className="inline-flex items-center gap-1 text-rose-700 text-[10px] font-bold bg-rose-50 px-1.5 py-0.5 rounded-md border border-rose-200/60">
                      <span className="w-1.5 h-1.5 rounded-full bg-rose-500" />
                      High
                    </span>
                  </td>
                  <td className="py-2.5 font-mono text-slate-800 font-bold text-[11px]">
                    {portWaitTimes.dhamra} days
                  </td>
                  <td className="py-2.5">
                    <span className="inline-flex items-center gap-1 text-[#4B5563] font-bold text-[10px] bg-[#F8F9FA] px-1.5 py-0.5 rounded-md border border-[#E5E7EB]">
                      <span className="w-1.5 h-1.5 rounded-full bg-[#F8F9FA]0" />
                      Moderate
                    </span>
                  </td>
                  <td className="py-2.5 text-right pr-1 font-bold text-amber-600">
                    <span className="inline-flex items-center gap-0.5">
                      <TrendingUp className="w-3 h-3 text-amber-600" />
                      <ChevronRight className="w-3 h-3 text-slate-400 group-hover:translate-x-0.5 transition-transform" />
                    </span>
                  </td>
                </tr>

                {/* 3. Visakhapatnam */}
                <tr className="hover:bg-[#F8F9FA]/40 transition-colors group cursor-pointer">
                  <td className="py-2.5 pl-1 font-bold text-slate-900">
                    <span className="inline-flex items-center gap-1.5">
                      <span className="text-sm">🇮🇳</span>
                      <span className="group-hover:text-[#4B5563] transition-colors font-extrabold">Vizag</span>
                    </span>
                  </td>
                  <td className="py-2.5">
                    <span className="inline-flex items-center gap-1 text-emerald-700 text-[10px] font-bold bg-emerald-50 px-1.5 py-0.5 rounded-md border border-emerald-200/60">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                      Low
                    </span>
                  </td>
                  <td className="py-2.5 font-mono text-slate-800 font-bold text-[11px]">
                    {portWaitTimes.vizag} days
                  </td>
                  <td className="py-2.5">
                    <span className="inline-flex items-center gap-1 text-emerald-700 font-bold text-[10px] bg-emerald-50 px-1.5 py-0.5 rounded-md border border-emerald-200/60">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                      Low
                    </span>
                  </td>
                  <td className="py-2.5 text-right pr-1 font-bold text-emerald-600">
                    <span className="inline-flex items-center gap-0.5">
                      <TrendingDown className="w-3 h-3 text-emerald-600" />
                      <ChevronRight className="w-3 h-3 text-slate-400 group-hover:translate-x-0.5 transition-transform" />
                    </span>
                  </td>
                </tr>

                {/* 4. Kakinada */}
                <tr className="hover:bg-[#F8F9FA]/40 transition-colors group cursor-pointer">
                  <td className="py-2.5 pl-1 font-bold text-slate-900">
                    <span className="inline-flex items-center gap-1.5">
                      <span className="text-sm">🇮🇳</span>
                      <span className="group-hover:text-[#4B5563] transition-colors font-extrabold">Kakinada</span>
                    </span>
                  </td>
                  <td className="py-2.5">
                    <span className="inline-flex items-center gap-1 text-slate-700 text-[10px] font-bold bg-[#F8F9FA] px-1.5 py-0.5 rounded-md border border-[#E5E7EB]">
                      <span className="w-1.5 h-1.5 rounded-full bg-[#F8F9FA]0" />
                      Moderate
                    </span>
                  </td>
                  <td className="py-2.5 font-mono text-slate-800 font-bold text-[11px]">
                    {portWaitTimes.kakinada} days
                  </td>
                  <td className="py-2.5">
                    <span className="inline-flex items-center gap-1 text-[#4B5563] font-bold text-[10px] bg-[#F8F9FA] px-1.5 py-0.5 rounded-md border border-[#E5E7EB]">
                      <span className="w-1.5 h-1.5 rounded-full bg-[#F8F9FA]0" />
                      Moderate
                    </span>
                  </td>
                  <td className="py-2.5 text-right pr-1 font-bold text-amber-600">
                    <span className="inline-flex items-center gap-0.5">
                      <TrendingUp className="w-3 h-3 text-amber-600" />
                      <ChevronRight className="w-3 h-3 text-slate-400 group-hover:translate-x-0.5 transition-transform" />
                    </span>
                  </td>
                </tr>

              </tbody>
            </table>
          </div>

          {/* Quick Berth restriction note */}
          <div
            style={{ transform: 'translateZ(16px)' }}
            className="p-2 rounded-xl bg-slate-50 border border-slate-200 text-[10px] text-slate-600 flex items-center justify-between font-medium"
          >
            <span>Max Permissible Draft: <b>14.5m</b> (Paradip CQ-1/2)</span>
            <span className="text-emerald-700 font-bold bg-emerald-100/80 px-1.5 py-0.2 rounded border border-emerald-300">
              Draft Compliant
            </span>
          </div>

        </Realistic3DBox>
      </div>

      {/* ========================================================================= */}
      {/* CARD 2: 3D VESSEL COMPARISON (5 Columns) */}
      {/* ========================================================================= */}
      <div className="lg:col-span-5">
        <Realistic3DBox accentGlow="rgba(217, 119, 6, 0.16)" className="space-y-3.5">
          
          {/* Header */}
          <div style={{ transform: 'translateZ(18px)' }} className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="p-2 rounded-xl bg-[#F3F4F6] border border-[#E5E7EB] text-[#4B5563] shadow-xs">
                <Realistic3DShipIcon size={20} />
              </div>
              <div>
                <h3 className="text-sm font-extrabold text-[#111827] tracking-tight">
                  Vessel Comparison <span className="text-slate-500 text-xs font-semibold">(🇦🇺 Hay Point ➔ 🇮🇳 Paradip)</span>
                </h3>
                <p className="text-[10px] text-slate-500 font-medium">
                  Select vessel class to inspect real-time TCE & slot economics
                </p>
              </div>
            </div>

            <Link
              to="/vessel-optimizer"
              className="text-xs font-black text-slate-700 hover:text-[#111827] flex items-center gap-1 hover:underline"
            >
              <span>Compare All</span>
              <ArrowRight className="w-3.5 h-3.5 text-[#4B5563]" />
            </Link>
          </div>

          {/* 3 Comparative 3D Physical Metallic Vessel Cards */}
          <div style={{ transform: 'translateZ(22px)' }} className="grid grid-cols-3 gap-2.5">
            
            {/* 1. Capesize (Highlighted & Optimal) */}
            <div
              onClick={() => setSelectedVessel('capesize')}
              style={{
                transform: selectedVessel === 'capesize' ? 'scale(1.02) translateZ(8px)' : 'none',
                boxShadow: selectedVessel === 'capesize'
                  ? '0 12px 25px -4px rgba(217, 119, 6, 0.2), inset 0 1px 0 rgba(255,255,255,0.9)'
                  : '0 2px 6px rgba(15, 39, 71, 0.04)',
              }}
              className={`p-3 rounded-xl flex flex-col justify-between space-y-2.5 cursor-pointer transition-all ${
                selectedVessel === 'capesize'
                  ? 'border-2 border-[#D97706] bg-gradient-to-b from-amber-50/80 via-white to-amber-50/40'
                  : 'border border-slate-200 bg-white hover:border-slate-300'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="text-xs font-black text-[#111827]">Capesize</span>
                <span className="text-[7.5px] font-black uppercase px-1.5 py-0.5 rounded-md bg-[#D97706] text-white shadow-2xs">
                  Most Suitable
                </span>
              </div>
              
              {/* Vessel Image / Graphic */}
              <div className="h-10 flex items-center justify-center overflow-hidden rounded-lg bg-slate-100/60 p-0.5 border border-slate-200/60">
                <img
                  src="/assets/vessels/capesize.jpg"
                  alt="Capesize Vessel"
                  className="max-h-9 w-auto object-cover rounded shadow-2xs transition-transform duration-300 group-hover:scale-105"
                />
              </div>

              {/* Rates */}
              <div className="space-y-1 text-[10px]">
                <div>
                  <span className="text-slate-400 font-bold block uppercase text-[8px]">Daily Rate</span>
                  <span className="font-black text-[#111827] text-xs font-mono">$18,450</span>
                </div>
                <div>
                  <span className="text-slate-400 font-bold block uppercase text-[8px]">Est. TCE</span>
                  <span className="font-bold text-slate-800 font-mono">$16,200</span>
                </div>
                <div>
                  <span className="text-slate-400 font-bold block uppercase text-[8px]">ETA</span>
                  <span className="font-bold text-slate-800">28 days</span>
                </div>
              </div>

              {/* 3D Radial Compatibility Gauge */}
              <div className="pt-1.5 border-t border-[#E5E7EB] flex items-center gap-1.5">
                <div className="w-5 h-5 rounded-full bg-emerald-500 text-white font-black text-[9px] flex items-center justify-center shrink-0 shadow-xs">
                  92%
                </div>
                <span className="text-[9px] font-extrabold text-emerald-700">Optimal Match</span>
              </div>
            </div>

            {/* 2. Panamax */}
            <div
              onClick={() => setSelectedVessel('panamax')}
              style={{
                transform: selectedVessel === 'panamax' ? 'scale(1.02) translateZ(8px)' : 'none',
                boxShadow: selectedVessel === 'panamax'
                  ? '0 12px 25px -4px rgba(15, 39, 71, 0.2), inset 0 1px 0 rgba(255,255,255,0.9)'
                  : '0 2px 6px rgba(15, 39, 71, 0.04)',
              }}
              className={`p-3 rounded-xl flex flex-col justify-between space-y-2.5 cursor-pointer transition-all ${
                selectedVessel === 'panamax'
                  ? 'border-2 border-[#111827] bg-gradient-to-b from-slate-50 via-white to-slate-50'
                  : 'border border-slate-200 bg-white hover:border-slate-300'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="text-xs font-black text-slate-900">Panamax</span>
                <span className="text-[7.5px] font-bold text-slate-500">70k MT</span>
              </div>
              
              <div className="h-10 flex items-center justify-center overflow-hidden rounded-lg bg-slate-100/60 p-0.5 border border-slate-200/60">
                <img
                  src="/assets/vessels/panamax.jpg"
                  alt="Panamax Vessel"
                  className="max-h-9 w-auto object-cover rounded shadow-2xs opacity-90"
                />
              </div>

              <div className="space-y-1 text-[10px]">
                <div>
                  <span className="text-slate-400 font-bold block uppercase text-[8px]">Daily Rate</span>
                  <span className="font-bold text-slate-800 text-xs font-mono">$12,800</span>
                </div>
                <div>
                  <span className="text-slate-400 font-bold block uppercase text-[8px]">Est. TCE</span>
                  <span className="font-semibold text-slate-700 font-mono">$11,100</span>
                </div>
                <div>
                  <span className="text-slate-400 font-bold block uppercase text-[8px]">ETA</span>
                  <span className="font-semibold text-slate-700">32 days</span>
                </div>
              </div>

              <div className="pt-1.5 border-t border-slate-200 flex items-center gap-1.5">
                <div className="w-5 h-5 rounded-full bg-slate-200 text-slate-800 font-black text-[9px] flex items-center justify-center shrink-0">
                  76%
                </div>
                <span className="text-[9px] font-bold text-slate-600">Draft Safe</span>
              </div>
            </div>

            {/* 3. Supramax */}
            <div
              onClick={() => setSelectedVessel('supramax')}
              style={{
                transform: selectedVessel === 'supramax' ? 'scale(1.02) translateZ(8px)' : 'none',
                boxShadow: selectedVessel === 'supramax'
                  ? '0 12px 25px -4px rgba(15, 39, 71, 0.2), inset 0 1px 0 rgba(255,255,255,0.9)'
                  : '0 2px 6px rgba(15, 39, 71, 0.04)',
              }}
              className={`p-3 rounded-xl flex flex-col justify-between space-y-2.5 cursor-pointer transition-all ${
                selectedVessel === 'supramax'
                  ? 'border-2 border-[#111827] bg-gradient-to-b from-slate-50 via-white to-slate-50'
                  : 'border border-slate-200 bg-white hover:border-slate-300'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="text-xs font-black text-slate-900">Supramax</span>
                <span className="text-[7.5px] font-bold text-slate-500">55k MT</span>
              </div>
              
              <div className="h-10 flex items-center justify-center overflow-hidden rounded-lg bg-slate-100/60 p-0.5 border border-slate-200/60">
                <img
                  src="/assets/vessels/supramax.jpg"
                  alt="Supramax Vessel"
                  className="max-h-9 w-auto object-cover rounded shadow-2xs opacity-90"
                />
              </div>

              <div className="space-y-1 text-[10px]">
                <div>
                  <span className="text-slate-400 font-bold block uppercase text-[8px]">Daily Rate</span>
                  <span className="font-bold text-slate-800 text-xs font-mono">$11,250</span>
                </div>
                <div>
                  <span className="text-slate-400 font-bold block uppercase text-[8px]">Est. TCE</span>
                  <span className="font-semibold text-slate-700 font-mono">$9,800</span>
                </div>
                <div>
                  <span className="text-slate-400 font-bold block uppercase text-[8px]">ETA</span>
                  <span className="font-semibold text-slate-700">34 days</span>
                </div>
              </div>

              <div className="pt-1.5 border-t border-slate-200 flex items-center gap-1.5">
                <div className="w-5 h-5 rounded-full bg-slate-200 text-slate-800 font-black text-[9px] flex items-center justify-center shrink-0">
                  68%
                </div>
                <span className="text-[9px] font-bold text-slate-600">Higher $/MT</span>
              </div>
            </div>

          </div>

        </Realistic3DBox>
      </div>

      {/* ========================================================================= */}
      {/* CARD 3: 3D AI RECOMMENDATION & REAL-TIME ALERTS FEED (3 Columns) */}
      {/* ========================================================================= */}
      <div className="lg:col-span-3 space-y-4 flex flex-col justify-between">
        
        {/* Top Box: 3D AI Recommendation */}
        <Realistic3DBox accentGlow="rgba(245, 158, 11, 0.18)" className="space-y-2.5 p-4">
          <div style={{ transform: 'translateZ(18px)' }} className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="p-1.5 rounded-lg bg-[#F3F4F6] border border-[#E5E7EB] text-amber-600">
                <Realistic3DAIBrainIcon size={18} />
              </div>
              <span className="font-black text-xs text-[#111827]">AI Recommendation</span>
            </div>
            <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-black text-[9px] border border-emerald-300">
              High Confidence
            </span>
          </div>

          <div style={{ transform: 'translateZ(22px)' }} className="p-2.5 rounded-xl bg-gradient-to-br bg-[#F8F9FA] border border-[#E5E7EB] space-y-1">
            <div className="text-xs font-black text-[#111827] flex items-center gap-1.5">
              <span>Use Capesize for this route</span>
            </div>
            <div className="text-[11px] font-black text-[#4B5563]">
              ★ Optimal Laycan: 2 – 8 Oct 2026
            </div>
            <p className="text-[10px] text-slate-600 leading-relaxed font-medium pt-0.5">
              <b>15–22% lower freight costs</b> projected compared to post-monsoon surge. Paradip CQ-1 draft clears 14.5m limit comfortably.
            </p>
          </div>
        </Realistic3DBox>

        {/* Bottom Box: Real-Time Live Activity & Marine Alerts */}
        <Realistic3DBox accentGlow="rgba(59, 130, 246, 0.14)" className="space-y-2.5 p-4">
          <div style={{ transform: 'translateZ(18px)' }} className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="p-1.5 rounded-lg bg-blue-500/10 border border-blue-400/30 text-blue-700">
                <Bell className="w-4 h-4 text-blue-600" />
              </div>
              <div>
                <span className="font-black text-xs text-[#111827] block">Live Marine Feed</span>
              </div>
            </div>

            <Link
              to="/reports"
              className="text-[10px] font-black text-[#4B5563] hover:underline flex items-center gap-0.5"
            >
              <span>All Alerts</span>
              <ArrowRight className="w-3 h-3" />
            </Link>
          </div>

          <div style={{ transform: 'translateZ(20px)' }} className="space-y-2">
            {liveAlerts.slice(0, 3).map((alert) => (
              <div
                key={alert.id}
                className="p-2 rounded-xl bg-slate-50/90 border border-slate-200/80 hover:bg-white hover:border-[#E5A93C] transition-all flex items-start justify-between gap-2 text-[10px] group cursor-pointer"
              >
                <div className="flex items-start gap-2">
                  <span className="text-sm shrink-0 drop-shadow-2xs">{alert.icon}</span>
                  <div>
                    <span className="font-extrabold text-slate-900 block leading-tight group-hover:text-[#4B5563] transition-colors">
                      {alert.title}
                    </span>
                    <span className="text-slate-500 text-[9px] line-clamp-1 mt-0.5">
                      {alert.desc}
                    </span>
                  </div>
                </div>
                <span className="text-[8.5px] font-bold text-slate-400 whitespace-nowrap bg-slate-200/60 px-1 py-0.5 rounded">
                  {alert.time}
                </span>
              </div>
            ))}
          </div>
        </Realistic3DBox>

      </div>

    </div>
  );
};
