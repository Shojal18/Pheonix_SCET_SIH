import React from 'react';
import { getCountryFlag } from '../../utils/countryFlags';

interface SimulationParametersBarProps {
  originPort: string;
  cleanDest: string;
  destState: string;
  destRegion: string;
  originCountry: string;
  isDomesticRoute: boolean;
  cargoVolume: number;
  effectiveCargoName: string;
  stowageFactor: number;
  formattedLaycanWindow: string;
  durationScope: string;
  confidenceScore: number;
  activeSubTab: string;
}

export const SimulationParametersBar: React.FC<SimulationParametersBarProps> = ({
  originPort,
  cleanDest,
  destState,
  destRegion,
  originCountry,
  isDomesticRoute,
  cargoVolume,
  effectiveCargoName,
  stowageFactor,
  formattedLaycanWindow,
  durationScope,
  confidenceScore,
  activeSubTab
}) => {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5 sm:gap-4">
      
      {/* ========================================================================= */}
      {/* 1. CORRIDOR CARD WITH 3D REALISTIC GPS NAVIGATION PIN */}
      {/* ========================================================================= */}
      <div className="group relative p-3.5 sm:p-4 rounded-[18px] bg-gradient-to-br from-white via-white to-white border border-slate-200/90 shadow-[0_4px_20px_rgba(0,0,0,0.025)] hover:shadow-md hover:border-slate-300/80 transition-all flex items-center gap-3.5 overflow-hidden">
        {/* Subtle Ambient Background Light */}
        <div className="absolute -top-6 -right-6 w-16 h-16 bg-amber-400/10 rounded-full blur-xl pointer-events-none group-hover:scale-125 transition-transform" />

        {/* 3D Realistic Route Navigation Pin Icon */}
        <div className="relative w-12 h-12 rounded-2xl bg-gradient-to-br bg-[#F3F4F6] border border-[#E5E7EB] flex items-center justify-center shrink-0 shadow-xs group-hover:scale-105 transition-transform">
          <svg viewBox="0 0 48 48" className="w-8 h-8 drop-shadow-[0_4px_6px_rgba(217,119,6,0.25)]">
            <defs>
              <radialGradient id="pin-shadow" cx="50%" cy="50%" r="50%">
                <stop offset="0%" stopColor="#78350F" stopOpacity="0.4" />
                <stop offset="100%" stopColor="#78350F" stopOpacity="0" />
              </radialGradient>
              <linearGradient id="pin-gold-body" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#FDE68A" />
                <stop offset="30%" stopColor="#F59E0B" />
                <stop offset="70%" stopColor="#D97706" />
                <stop offset="100%" stopColor="#B45309" />
              </linearGradient>
              <linearGradient id="pin-glass-inner" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#FFFFFF" />
                <stop offset="100%" stopColor="#FEF3C7" />
              </linearGradient>
              <linearGradient id="pin-core-dot" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#EF4444" />
                <stop offset="100%" stopColor="#991B1B" />
              </linearGradient>
            </defs>
            {/* 3D Drop Shadow on Base */}
            <ellipse cx="24" cy="42" rx="11" ry="3.5" fill="url(#pin-shadow)" />
            {/* Outer Navigation Pin 3D Body */}
            <path
              d="M 24,6 C 15.16,6 8,13.16 8,22 C 8,32 21.5,41.2 23.2,42.3 C 23.7,42.6 24.3,42.6 24.8,42.3 C 26.5,41.2 40,32 40,22 C 40,13.16 32.84,6 24,6 Z"
              fill="url(#pin-gold-body)"
            />
            {/* Front Specular Ridge */}
            <path
              d="M 24,8 C 16.5,8 10.5,14 10.5,21.5 C 10.5,29.5 21,37.5 24,39.8 C 24,39.8 24,8 24,8 Z"
              fill="#FFFFFF"
              fillOpacity="0.28"
            />
            {/* Inner Circular Pearl Face */}
            <circle cx="24" cy="20" r="7" fill="url(#pin-glass-inner)" stroke="#FFFFFF" strokeWidth="1" />
            {/* Center Glowing Target Radar Core */}
            <circle cx="24" cy="20" r="3.2" fill="url(#pin-core-dot)" />
            <circle cx="24" cy="20" r="5" fill="none" stroke="#D97706" strokeWidth="0.8" strokeDasharray="2 1.5" />
          </svg>
        </div>

        {/* Details */}
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-wider text-slate-400">
            <span>CORRIDOR</span>
            <span className="w-1.5 h-1.5 rounded-full bg-[#F8F9FA]0 animate-pulse" />
          </div>
          <div className="text-xs sm:text-[13px] font-black text-[#111827] truncate mt-0.5 flex items-center gap-1">
            {isDomesticRoute ? (
              <span>🇮🇳 {originPort.split(' (')[1]?.replace(')', '') || originPort} &rarr; 🇮🇳 {cleanDest}</span>
            ) : (
              <span>{getCountryFlag(originCountry)} {originCountry} &rarr; 🇮🇳 {cleanDest}</span>
            )}
          </div>
          <div className="text-[10.5px] text-slate-500 font-medium truncate mt-0.5 flex items-center gap-1">
            <span>🇮🇳</span>
            <span>
              {activeSubTab === 'weather'
                ? `${cleanDest} (${destState}), East Coast`
                : activeSubTab === 'congestion'
                ? `${cleanDest} (${destState}), India`
                : isDomesticRoute ? `Coastal Cabotage • ${destRegion}` : `${cleanDest} (${destState}), ${destRegion}`}
            </span>
          </div>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 2. CARGO PARCEL CARD WITH 3D REALISTIC SHIPPING CONTAINER */}
      {/* ========================================================================= */}
      <div className="group relative p-3.5 sm:p-4 rounded-[18px] bg-gradient-to-br from-white via-white to-blue-50/20 border border-slate-200/90 shadow-[0_4px_20px_rgba(0,0,0,0.025)] hover:shadow-md hover:border-blue-300/80 transition-all flex items-center gap-3.5 overflow-hidden">
        {/* Ambient Light */}
        <div className="absolute -top-6 -right-6 w-16 h-16 bg-blue-500/10 rounded-full blur-xl pointer-events-none group-hover:scale-125 transition-transform" />

        {/* 3D Realistic Intermodal Container Icon */}
        <div className="relative w-12 h-12 rounded-2xl bg-gradient-to-br from-blue-50 to-blue-100/70 border border-blue-200/80 flex items-center justify-center shrink-0 shadow-xs group-hover:scale-105 transition-transform">
          <svg viewBox="0 0 48 48" className="w-8 h-8 drop-shadow-[0_4px_6px_rgba(37,99,235,0.25)]">
            <defs>
              <radialGradient id="box-shadow" cx="50%" cy="50%" r="50%">
                <stop offset="0%" stopColor="#1E3A8A" stopOpacity="0.35" />
                <stop offset="100%" stopColor="#1E3A8A" stopOpacity="0" />
              </radialGradient>
              <linearGradient id="cont-top" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#60A5FA" />
                <stop offset="100%" stopColor="#3B82F6" />
              </linearGradient>
              <linearGradient id="cont-front" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#2563EB" />
                <stop offset="100%" stopColor="#1D4ED8" />
              </linearGradient>
              <linearGradient id="cont-side" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stopColor="#1E40AF" />
                <stop offset="100%" stopColor="#172554" />
              </linearGradient>
            </defs>
            {/* Ground Shadow */}
            <ellipse cx="24" cy="42" rx="15" ry="4" fill="url(#box-shadow)" />
            {/* 3D Isometric Container Top Face */}
            <polygon points="24,10 40,18 24,26 8,18" fill="url(#cont-top)" stroke="#93C5FD" strokeWidth="0.8" />
            {/* Corrugated Top Rib Lines */}
            <line x1="13" y1="16" x2="29" y2="24" stroke="#DBEAFE" strokeWidth="0.7" strokeOpacity="0.8" />
            <line x1="19" y1="13" x2="35" y2="21" stroke="#DBEAFE" strokeWidth="0.7" strokeOpacity="0.8" />
            {/* 3D Left / Front Face */}
            <polygon points="8,18 24,26 24,39 8,31" fill="url(#cont-front)" stroke="#1D4ED8" strokeWidth="0.8" />
            {/* Corrugated Vertical Ribs Front */}
            <line x1="12" y1="20" x2="12" y2="33" stroke="#1E40AF" strokeWidth="0.8" />
            <line x1="16" y1="22" x2="16" y2="35" stroke="#1E40AF" strokeWidth="0.8" />
            <line x1="20" y1="24" x2="20" y2="37" stroke="#1E40AF" strokeWidth="0.8" />
            {/* 3D Right / Side Face (Doors) */}
            <polygon points="24,26 40,18 40,31 24,39" fill="url(#cont-side)" stroke="#0F172A" strokeWidth="0.8" />
            {/* Door Joint & Steel Lock Bars */}
            <line x1="32" y1="22" x2="32" y2="35" stroke="#94A3B8" strokeWidth="1" />
            <line x1="28" y1="24" x2="28" y2="37" stroke="#CBD5E1" strokeWidth="0.6" />
            <line x1="36" y1="20" x2="36" y2="33" stroke="#CBD5E1" strokeWidth="0.6" />
          </svg>
        </div>

        {/* Details */}
        <div className="min-w-0 flex-1">
          <div className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
            CARGO PARCEL
          </div>
          <div className="text-xs sm:text-[13px] font-black text-[#111827] font-mono truncate mt-0.5">
            {cargoVolume.toLocaleString()} MT
          </div>
          <div className="flex items-center gap-1.5 mt-0.5 flex-wrap">
            <span className="text-[10.5px] text-slate-600 font-bold truncate">
              {effectiveCargoName}
            </span>
            <span className="px-1.5 py-0.2 rounded text-[9px] font-bold font-mono bg-blue-50 text-[#2563EB] border border-blue-100">
              SF: {stowageFactor} m³/MT
            </span>
          </div>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 3. LAYCAN WINDOW CARD WITH 3D REALISTIC VOYAGE CALENDAR */}
      {/* ========================================================================= */}
      <div className="group relative p-3.5 sm:p-4 rounded-[18px] bg-gradient-to-br from-white via-white to-emerald-50/20 border border-slate-200/90 shadow-[0_4px_20px_rgba(0,0,0,0.025)] hover:shadow-md hover:border-emerald-300/80 transition-all flex items-center gap-3.5 overflow-hidden">
        {/* Ambient Light */}
        <div className="absolute -top-6 -right-6 w-16 h-16 bg-emerald-500/10 rounded-full blur-xl pointer-events-none group-hover:scale-125 transition-transform" />

        {/* 3D Realistic Voyage Calendar Icon */}
        <div className="relative w-12 h-12 rounded-2xl bg-gradient-to-br from-emerald-50 to-emerald-100/70 border border-emerald-200/80 flex items-center justify-center shrink-0 shadow-xs group-hover:scale-105 transition-transform">
          <svg viewBox="0 0 48 48" className="w-8 h-8 drop-shadow-[0_4px_6px_rgba(16,185,129,0.25)]">
            <defs>
              <radialGradient id="cal-shadow" cx="50%" cy="50%" r="50%">
                <stop offset="0%" stopColor="#064E3B" stopOpacity="0.35" />
                <stop offset="100%" stopColor="#064E3B" stopOpacity="0" />
              </radialGradient>
              <linearGradient id="cal-header" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#34D399" />
                <stop offset="50%" stopColor="#10B981" />
                <stop offset="100%" stopColor="#059669" />
              </linearGradient>
              <linearGradient id="cal-sheet" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#FFFFFF" />
                <stop offset="100%" stopColor="#F1F5F9" />
              </linearGradient>
            </defs>
            {/* Ground Shadow */}
            <ellipse cx="24" cy="42" rx="14" ry="3.5" fill="url(#cal-shadow)" />
            {/* Bottom Pages / Stack Depth */}
            <rect x="9" y="13" width="30" height="28" rx="5" fill="#E2E8F0" />
            <rect x="8" y="12" width="32" height="28" rx="5" fill="#CBD5E1" />
            {/* Main Calendar Body Sheet */}
            <rect x="8" y="10" width="32" height="30" rx="5" fill="url(#cal-sheet)" stroke="#E2E8F0" strokeWidth="0.8" />
            {/* Top Emerald Header Strip */}
            <path
              d="M 8,15 C 8,12.24 10.24,10 13,10 L 35,10 C 37.76,10 40,12.24 40,15 L 40,18 L 8,18 Z"
              fill="url(#cal-header)"
            />
            {/* 3D Metallic Binding Rings */}
            <rect x="14" y="6" width="3" height="7" rx="1.5" fill="#F8FAFC" stroke="#047857" strokeWidth="0.8" />
            <rect x="23" y="6" width="3" height="7" rx="1.5" fill="#F8FAFC" stroke="#047857" strokeWidth="0.8" />
            <rect x="31" y="6" width="3" height="7" rx="1.5" fill="#F8FAFC" stroke="#047857" strokeWidth="0.8" />
            {/* Calendar Number Matrix / Checkmark */}
            <circle cx="15" cy="24" r="1.5" fill="#94A3B8" />
            <circle cx="21" cy="24" r="1.5" fill="#94A3B8" />
            <circle cx="27" cy="24" r="1.5" fill="#94A3B8" />
            <circle cx="33" cy="24" r="1.5" fill="#94A3B8" />
            <circle cx="15" cy="30" r="1.5" fill="#94A3B8" />
            {/* Optimal Day Circle */}
            <circle cx="21" cy="30" r="3.2" fill="#10B981" />
            <circle cx="21" cy="30" r="1.2" fill="#FFFFFF" />
            <circle cx="27" cy="30" r="1.5" fill="#94A3B8" />
            <circle cx="33" cy="30" r="1.5" fill="#94A3B8" />
          </svg>
        </div>

        {/* Details */}
        <div className="min-w-0 flex-1">
          <div className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
            LAYCAN WINDOW
          </div>
          <div className="text-xs sm:text-[13px] font-black text-[#111827] font-mono truncate mt-0.5">
            {formattedLaycanWindow}
          </div>
          <div className="text-[10.5px] text-slate-500 font-medium truncate mt-0.5">
            Scope: <strong className="text-emerald-700 font-bold">{durationScope === 'short' ? 'Short-Term (Spot)' : 'Medium-Term'}</strong>
          </div>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 4. MODEL CONFIDENCE CARD WITH 3D REALISTIC NEURAL RADAR CHIP */}
      {/* ========================================================================= */}
      <div className="group relative p-3.5 sm:p-4 rounded-[18px] bg-gradient-to-br from-white via-white to-purple-50/20 border border-slate-200/90 shadow-[0_4px_20px_rgba(0,0,0,0.025)] hover:shadow-md hover:border-purple-300/80 transition-all flex items-center gap-3.5 overflow-hidden">
        {/* Ambient Light */}
        <div className="absolute -top-6 -right-6 w-16 h-16 bg-purple-500/10 rounded-full blur-xl pointer-events-none group-hover:scale-125 transition-transform" />

        {/* 3D Realistic AI Neural Analytics Chip Icon */}
        <div className="relative w-12 h-12 rounded-2xl bg-gradient-to-br from-purple-50 to-purple-100/70 border border-purple-200/80 flex items-center justify-center shrink-0 shadow-xs group-hover:scale-105 transition-transform">
          <svg viewBox="0 0 48 48" className="w-8 h-8 drop-shadow-[0_4px_6px_rgba(124,58,237,0.25)]">
            <defs>
              <radialGradient id="chip-shadow" cx="50%" cy="50%" r="50%">
                <stop offset="0%" stopColor="#4C1D95" stopOpacity="0.35" />
                <stop offset="100%" stopColor="#4C1D95" stopOpacity="0" />
              </radialGradient>
              <linearGradient id="bar-purple-1" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#C084FC" />
                <stop offset="100%" stopColor="#7E22CE" />
              </linearGradient>
              <linearGradient id="bar-purple-2" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#A855F7" />
                <stop offset="100%" stopColor="#6B21A8" />
              </linearGradient>
              <linearGradient id="bar-purple-3" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#E9D5FF" />
                <stop offset="100%" stopColor="#9333EA" />
              </linearGradient>
            </defs>
            {/* Ground Shadow */}
            <ellipse cx="24" cy="42" rx="14" ry="3.5" fill="url(#chip-shadow)" />
            {/* 3D Holographic Platform Base */}
            <polygon points="24,31 40,36 24,41 8,36" fill="#DDD6FE" stroke="#8B5CF6" strokeWidth="0.8" />
            {/* 3D Column 1 (Left / Lowest) */}
            <g transform="translate(11, 22)">
              <polygon points="3,0 6,1.5 3,3 0,1.5" fill="#E9D5FF" />
              <polygon points="0,1.5 3,3 3,13 0,11.5" fill="url(#bar-purple-1)" />
              <polygon points="3,3 6,1.5 6,11.5 3,13" fill="#581C87" />
            </g>
            {/* 3D Column 2 (Middle / Medium) */}
            <g transform="translate(21, 15)">
              <polygon points="3,0 6,1.5 3,3 0,1.5" fill="#E9D5FF" />
              <polygon points="0,1.5 3,3 3,20 0,18.5" fill="url(#bar-purple-2)" />
              <polygon points="3,3 6,1.5 6,18.5 3,20" fill="#581C87" />
            </g>
            {/* 3D Column 3 (Right / Highest Peak) */}
            <g transform="translate(31, 8)">
              <polygon points="3,0 6,1.5 3,3 0,1.5" fill="#FAF5FF" stroke="#FFFFFF" strokeWidth="0.5" />
              <polygon points="0,1.5 3,3 3,27 0,25.5" fill="url(#bar-purple-3)" />
              <polygon points="3,3 6,1.5 6,25.5 3,27" fill="#6B21A8" />
            </g>
            {/* Glowing Peak Spark */}
            <circle cx="34" cy="9" r="1.5" fill="#FDE047" />
          </svg>
        </div>

        {/* Details */}
        <div className="min-w-0 flex-1">
          <div className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
            MODEL CONFIDENCE
          </div>
          <div className="text-xs sm:text-[13px] font-black text-[#111827] font-mono truncate mt-0.5">
            {confidenceScore || 82}% <span className="text-[10.5px] font-bold text-slate-500 font-sans">(MAE 8.3)</span>
          </div>
          <div className="text-[10.5px] text-purple-700 font-bold truncate mt-0.5">
            Quantile Engine • PortIN v2.0
          </div>
        </div>
      </div>

    </div>
  );
};
