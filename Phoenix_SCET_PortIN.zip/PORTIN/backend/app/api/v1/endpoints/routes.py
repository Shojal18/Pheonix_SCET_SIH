from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from typing import List, Dict, Any
from backend.app.database.session import get_db
from backend.app.models.models import Route

router = APIRouter()

from pydantic import BaseModel
from typing import Optional
from backend.app.services.route_analysis_service import MaritimeRouteEngine

class RouteAnalysisRequest(BaseModel):
    origin_port: str = "Balikpapan"
    origin_country: str = "Indonesia"
    destination_port: str = "Paradip"
    vessel_class: str = "Panamax"
    speed_knots: float = 13.0
    bunker_price_vlsfo: float = 620.0

class RouteAIAdvisoryRequest(BaseModel):
    origin_port: str = "Balikpapan"
    destination_port: str = "Paradip"
    vessel_class: str = "Panamax"
    cargo_type: str = "Thermal Coal"
    distance_nm: float = 2420.0
    transit_days: float = 7.8
    api_key: Optional[str] = None

@router.get("")
def get_routes(db: Session = Depends(get_db)):
    routes = db.query(Route).all()
    results = []
    for r in routes:
        results.append({
            "id": r.id,
            "origin_country": r.origin_country,
            "origin_port": r.origin_port,
            "destination_port_id": r.destination_port_id,
            "destination_port_name": r.destination_port.name if r.destination_port else "Unknown",
            "distance_nm": r.distance_nm,
            "typical_days": r.typical_days,
            "weather_risk_level": r.weather_risk_level,
            "origin_lat": r.origin_lat,
            "origin_lng": r.origin_lng,
            "dest_lat": r.destination_port.latitude if r.destination_port else 20.26,
            "dest_lng": r.destination_port.longitude if r.destination_port else 86.67
        })
    return results

@router.post("/analyze")
def analyze_maritime_route(req: RouteAnalysisRequest):
    """
    Computes shortest nautical passage vs alternative deepwater route,
    real sea waypoints, chokepoint restrictions, bunkering ports, and fuel variance.
    """
    return MaritimeRouteEngine.analyze_corridor(
        origin_port_name=req.origin_port,
        destination_port_name=req.destination_port,
        vessel_class=req.vessel_class,
        speed_knots=req.speed_knots,
        vlsfo_price_usd=req.bunker_price_vlsfo
    )

@router.post("/ai-advisory")
def generate_route_ai_advisory(req: RouteAIAdvisoryRequest):
    """
    Generates an executive AI-powered navigation risk and fuel strategy briefing
    using Groq Cloud, Google Gemini, or OpenAI.
    """
    advisory_text = MaritimeRouteEngine.generate_ai_route_advisory(
        origin_port=req.origin_port,
        destination_port=req.destination_port,
        vessel_class=req.vessel_class,
        cargo_type=req.cargo_type,
        shortest_dist=req.distance_nm,
        transit_days=req.transit_days,
        custom_api_key=req.api_key
    )
    return {"advisory": advisory_text}
