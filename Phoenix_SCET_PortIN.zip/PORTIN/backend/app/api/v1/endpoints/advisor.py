from fastapi import APIRouter, Depends
from backend.app.schemas.schemas import AdvisorQueryRequest, AdvisorQueryResponse
from backend.app.services.advisor import DecisionAdvisorService
from backend.app.core.deps import require_government
from backend.app.models.models import User

router = APIRouter()

@router.post("/ask", response_model=AdvisorQueryResponse)
def ask_advisor(req: AdvisorQueryRequest, current_user: User = Depends(require_government)):
    return DecisionAdvisorService.answer_query(req.question, req.context)
