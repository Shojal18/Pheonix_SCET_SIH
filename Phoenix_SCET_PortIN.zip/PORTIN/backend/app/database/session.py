from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base
from backend.app.core.config import settings
import logging

logger = logging.getLogger("portin.database")

Base = declarative_base()

def get_engine():
    import os
    target_url = settings.DATABASE_URL
    # If local portin.db exists and remote postgres isn't explicitly forced, use high-performance local SQLite
    if os.path.exists("portin.db") and os.environ.get("FORCE_POSTGRES", "false").lower() != "true":
        logger.info("Using local high-performance SQLite database (portin.db)")
        return create_engine("sqlite:///./portin.db", connect_args={"check_same_thread": False}, pool_pre_ping=True)

    if target_url.startswith("sqlite"):
        connect_args = {"check_same_thread": False}
    else:
        connect_args = {"connect_timeout": 1}
    try:
        eng = create_engine(
            target_url,
            connect_args=connect_args,
            pool_pre_ping=True
        )
        with eng.connect() as conn:
            pass
        return eng
    except Exception as e:
        logger.warning(f"Database connection to remote failed: {e}. Gracefully falling back to local SQLite.")
        sqlite_url = "sqlite:///./portin.db"
        return create_engine(sqlite_url, connect_args={"check_same_thread": False}, pool_pre_ping=True)

engine = get_engine()

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
